#1/20;

DROP TABLE IF EXISTS app_access_groups;
DROP TABLE IF EXISTS app_access_rules;
DROP TABLE IF EXISTS app_access_rules_fields;
DROP TABLE IF EXISTS app_approved_items;
DROP TABLE IF EXISTS app_attachments;
DROP TABLE IF EXISTS app_comments;
DROP TABLE IF EXISTS app_comments_access;
DROP TABLE IF EXISTS app_comments_forms_tabs;
DROP TABLE IF EXISTS app_comments_history;
DROP TABLE IF EXISTS app_configuration;
DROP TABLE IF EXISTS app_dashboard_pages;
DROP TABLE IF EXISTS app_dashboard_pages_sections;
DROP TABLE IF EXISTS app_emails_on_schedule;
DROP TABLE IF EXISTS app_entities;
DROP TABLE IF EXISTS app_entities_access;
DROP TABLE IF EXISTS app_entities_configuration;
DROP TABLE IF EXISTS app_entities_menu;
DROP TABLE IF EXISTS app_entity_1;
DROP TABLE IF EXISTS app_entity_1_values;
DROP TABLE IF EXISTS app_entity_21;
DROP TABLE IF EXISTS app_entity_21_values;
DROP TABLE IF EXISTS app_entity_22;
DROP TABLE IF EXISTS app_entity_22_values;
DROP TABLE IF EXISTS app_entity_23;
DROP TABLE IF EXISTS app_entity_23_values;
DROP TABLE IF EXISTS app_entity_24;
DROP TABLE IF EXISTS app_entity_24_values;
DROP TABLE IF EXISTS app_entity_29;
DROP TABLE IF EXISTS app_entity_29_values;
DROP TABLE IF EXISTS app_entity_30;
DROP TABLE IF EXISTS app_entity_30_values;
DROP TABLE IF EXISTS app_entity_31;
DROP TABLE IF EXISTS app_entity_31_values;
DROP TABLE IF EXISTS app_entity_32;
DROP TABLE IF EXISTS app_entity_32_values;
DROP TABLE IF EXISTS app_entity_35;
DROP TABLE IF EXISTS app_entity_35_values;
DROP TABLE IF EXISTS app_entity_37;
DROP TABLE IF EXISTS app_entity_37_values;
DROP TABLE IF EXISTS app_entity_46;
DROP TABLE IF EXISTS app_entity_46_values;
DROP TABLE IF EXISTS app_entity_49;
DROP TABLE IF EXISTS app_entity_49_values;
DROP TABLE IF EXISTS app_entity_50;
DROP TABLE IF EXISTS app_entity_50_values;
DROP TABLE IF EXISTS app_entity_52;
DROP TABLE IF EXISTS app_entity_52_values;
DROP TABLE IF EXISTS app_entity_57;
DROP TABLE IF EXISTS app_entity_57_values;
DROP TABLE IF EXISTS app_entity_83;
DROP TABLE IF EXISTS app_entity_83_values;
DROP TABLE IF EXISTS app_entity_84;
DROP TABLE IF EXISTS app_entity_84_values;
DROP TABLE IF EXISTS app_ext_calendar;
DROP TABLE IF EXISTS app_ext_calendar_access;
DROP TABLE IF EXISTS app_ext_calendar_events;
DROP TABLE IF EXISTS app_ext_call_history;
DROP TABLE IF EXISTS app_ext_chat_access;
DROP TABLE IF EXISTS app_ext_chat_conversations;
DROP TABLE IF EXISTS app_ext_chat_conversations_messages;
DROP TABLE IF EXISTS app_ext_chat_messages;
DROP TABLE IF EXISTS app_ext_chat_unread_messages;
DROP TABLE IF EXISTS app_ext_chat_users_online;
DROP TABLE IF EXISTS app_ext_comments_templates;
DROP TABLE IF EXISTS app_ext_comments_templates_fields;
DROP TABLE IF EXISTS app_ext_cryptopro_certificates;
DROP TABLE IF EXISTS app_ext_currencies;
DROP TABLE IF EXISTS app_ext_email_rules;
DROP TABLE IF EXISTS app_ext_entities_templates;
DROP TABLE IF EXISTS app_ext_entities_templates_fields;
DROP TABLE IF EXISTS app_ext_export_templates;
DROP TABLE IF EXISTS app_ext_file_storage_queue;
DROP TABLE IF EXISTS app_ext_file_storage_rules;
DROP TABLE IF EXISTS app_ext_functions;
DROP TABLE IF EXISTS app_ext_funnelchart;
DROP TABLE IF EXISTS app_ext_ganttchart;
DROP TABLE IF EXISTS app_ext_ganttchart_access;
DROP TABLE IF EXISTS app_ext_ganttchart_depends;
DROP TABLE IF EXISTS app_ext_global_search_entities;
DROP TABLE IF EXISTS app_ext_graphicreport;
DROP TABLE IF EXISTS app_ext_image_map;
DROP TABLE IF EXISTS app_ext_import_templates;
DROP TABLE IF EXISTS app_ext_ipages;
DROP TABLE IF EXISTS app_ext_item_pivot_tables;
DROP TABLE IF EXISTS app_ext_item_pivot_tables_calcs;
DROP TABLE IF EXISTS app_ext_items_export_templates_blocks;
DROP TABLE IF EXISTS app_ext_kanban;
DROP TABLE IF EXISTS app_ext_mail;
DROP TABLE IF EXISTS app_ext_mail_accounts;
DROP TABLE IF EXISTS app_ext_mail_accounts_entities;
DROP TABLE IF EXISTS app_ext_mail_accounts_entities_fields;
DROP TABLE IF EXISTS app_ext_mail_accounts_entities_filters;
DROP TABLE IF EXISTS app_ext_mail_accounts_entities_rules;
DROP TABLE IF EXISTS app_ext_mail_accounts_users;
DROP TABLE IF EXISTS app_ext_mail_contacts;
DROP TABLE IF EXISTS app_ext_mail_filters;
DROP TABLE IF EXISTS app_ext_mail_groups;
DROP TABLE IF EXISTS app_ext_mail_groups_from;
DROP TABLE IF EXISTS app_ext_mail_to_items;
DROP TABLE IF EXISTS app_ext_map_reports;
DROP TABLE IF EXISTS app_ext_mind_map;
DROP TABLE IF EXISTS app_ext_modules;
DROP TABLE IF EXISTS app_ext_modules_cfg;
DROP TABLE IF EXISTS app_ext_pivot_calendars;
DROP TABLE IF EXISTS app_ext_pivot_calendars_entities;
DROP TABLE IF EXISTS app_ext_pivot_map_reports;
DROP TABLE IF EXISTS app_ext_pivot_map_reports_entities;
DROP TABLE IF EXISTS app_ext_pivot_tables;
DROP TABLE IF EXISTS app_ext_pivot_tables_fields;
DROP TABLE IF EXISTS app_ext_pivot_tables_settings;
DROP TABLE IF EXISTS app_ext_pivotreports;
DROP TABLE IF EXISTS app_ext_pivotreports_fields;
DROP TABLE IF EXISTS app_ext_pivotreports_settings;
DROP TABLE IF EXISTS app_ext_processes;
DROP TABLE IF EXISTS app_ext_processes_actions;
DROP TABLE IF EXISTS app_ext_processes_actions_fields;
DROP TABLE IF EXISTS app_ext_processes_buttons_groups;
DROP TABLE IF EXISTS app_ext_processes_clone_subitems;
DROP TABLE IF EXISTS app_ext_public_forms;
DROP TABLE IF EXISTS app_ext_recurring_tasks;
DROP TABLE IF EXISTS app_ext_recurring_tasks_fields;
DROP TABLE IF EXISTS app_ext_signed_items;
DROP TABLE IF EXISTS app_ext_signed_items_signatures;
DROP TABLE IF EXISTS app_ext_smart_input_rules;
DROP TABLE IF EXISTS app_ext_sms_rules;
DROP TABLE IF EXISTS app_ext_subscribe_rules;
DROP TABLE IF EXISTS app_ext_timeline_reports;
DROP TABLE IF EXISTS app_ext_timer;
DROP TABLE IF EXISTS app_ext_timer_configuration;
DROP TABLE IF EXISTS app_ext_track_changes;
DROP TABLE IF EXISTS app_ext_track_changes_entities;
DROP TABLE IF EXISTS app_ext_track_changes_log;
DROP TABLE IF EXISTS app_ext_track_changes_log_fields;
DROP TABLE IF EXISTS app_ext_xml_export_templates;
DROP TABLE IF EXISTS app_ext_xml_import_templates;
DROP TABLE IF EXISTS app_fields;
DROP TABLE IF EXISTS app_fields_access;
DROP TABLE IF EXISTS app_fields_choices;
DROP TABLE IF EXISTS app_filters_panels;
DROP TABLE IF EXISTS app_filters_panels_fields;
DROP TABLE IF EXISTS app_forms_fields_rules;
DROP TABLE IF EXISTS app_forms_rows;
DROP TABLE IF EXISTS app_forms_tabs;
DROP TABLE IF EXISTS app_global_lists;
DROP TABLE IF EXISTS app_global_lists_choices;
DROP TABLE IF EXISTS app_help_pages;
DROP TABLE IF EXISTS app_holidays;
DROP TABLE IF EXISTS app_image_map_labels;
DROP TABLE IF EXISTS app_image_map_markers;
DROP TABLE IF EXISTS app_items_export_templates;
DROP TABLE IF EXISTS app_listing_highlight_rules;
DROP TABLE IF EXISTS app_listing_sections;
DROP TABLE IF EXISTS app_listing_types;
DROP TABLE IF EXISTS app_mind_map;
DROP TABLE IF EXISTS app_records_visibility_rules;
DROP TABLE IF EXISTS app_related_items_1_83;
DROP TABLE IF EXISTS app_related_items_83_84;
DROP TABLE IF EXISTS app_reports;
DROP TABLE IF EXISTS app_reports_filters;
DROP TABLE IF EXISTS app_reports_filters_templates;
DROP TABLE IF EXISTS app_reports_groups;
DROP TABLE IF EXISTS app_reports_sections;
DROP TABLE IF EXISTS app_sessions;
DROP TABLE IF EXISTS app_user_filters_values;
DROP TABLE IF EXISTS app_user_roles;
DROP TABLE IF EXISTS app_user_roles_access;
DROP TABLE IF EXISTS app_user_roles_to_items;
DROP TABLE IF EXISTS app_users_alerts;
DROP TABLE IF EXISTS app_users_alerts_viewed;
DROP TABLE IF EXISTS app_users_configuration;
DROP TABLE IF EXISTS app_users_filters;
DROP TABLE IF EXISTS app_users_login_log;
DROP TABLE IF EXISTS app_users_notifications;
DROP TABLE IF EXISTS app_users_search_settings;


CREATE TABLE IF NOT EXISTS `app_access_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `is_ldap_default` tinyint(1) DEFAULT NULL,
  `ldap_filter` text NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_access_groups VALUES
('4','Regional Manager','1','0','','2'),
('5','Case Manager','0','0','','1'),
('6','Client','0','0','','0'),
('12','Director','0','0','','0'),
('13','Child','0','0','','0');

CREATE TABLE IF NOT EXISTS `app_access_rules` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `choices` text NOT NULL,
  `users_groups` text NOT NULL,
  `access_schema` text NOT NULL,
  `fields_view_only_access` text NOT NULL,
  `comments_access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_access_rules_fields` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_approved_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `items_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `users_id` int NOT NULL,
  `signature` text NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_attachments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `form_token` varchar(64) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `date_added` date NOT NULL,
  `container` varchar(16) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_attachments VALUES
('4','967afc89da910622fef82385c47523e3','1611070541_Young_Life_Logo.jpg','2021-01-19','725'),
('5','51cc9f35e798e472d4769d6b43c7c471','1611082108_Young_Life_Logo.jpg','2021-01-19','1071'),
('6','28138fb53046a962aef84b469fffee6a','1611088846_rmarkdown.pdf','2021-01-19','1071');

CREATE TABLE IF NOT EXISTS `app_backups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(64) NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `items_id` int NOT NULL,
  `created_by` int NOT NULL,
  `description` text NOT NULL,
  `attachments` text NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=229 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_comments VALUES
('194','83','5','39','','','1610644761'),
('195','83','5','39','','','1610645441'),
('196','83','14','43','','','1610662424'),
('197','83','5','43','This is a comment by your provider.','','1610729475'),
('198','83','12','43','Changing the name of the milestone.','','1610729556'),
('199','83','14','43','Hello quick comment','','1610729877'),
('201','83','18','43','quick comment','','1610732081'),
('202','83','23','45','','','1610751994'),
('203','83','24','45','Great job.  Here is a link for more information on the associates degrees','','1610767398'),
('204','83','25','45','Great job.  Here is a link for more information on the associates degrees','','1610767398'),
('205','83','25','45','<blockquote>Great job.  Here is a link for more information on the associates degrdfdsfeesdfdf</blockquote>\n','','1610768401'),
('206','83','25','45','','','1610768516'),
('208','83','26','45','Looks good<br />','','1610825494'),
('210','83','23','43','Testing','','1610984118'),
('211','83','26','43','Another quick comment','','1610984230'),
('212','83','26','43','Testing for email notif','','1610984574'),
('213','83','50','43','Did you finish your goal today? - provider','','1610984717'),
('214','83','50','43','Testing for comment','','1610984878'),
('215','83','54','43','Johnny, reminder to update your milestone! ','','1610985454'),
('216','83','54','43','Johnny, this is your provider. Great recurring goals!','','1610985638'),
('217','83','54','43','Hello testing!','','1610985952'),
('218','83','54','43','','','1610986362'),
('219','83','54','43','','','1610986877'),
('220','83','54','43','','','1610987208'),
('221','83','54','43','Yay you completed a milestone!','','1610987375'),
('222','83','50','43','','','1610987625'),
('223','83','5','39','','','1610987984'),
('224','83','12','45','testing this again','','1611007937'),
('225','83','50','43','Hi ','','1611072511'),
('226','83','5','45','<strong><span style=\"background-color:#A52A2A;\">Testing</span></strong>','','1611115698'),
('227','83','5','45','<blockquote><strong><span style=\"background-color:#A52A2A;\">rTestingReplaying</span></strong><br />\n </blockquote>\n','','1611115725'),
('228','83','5','45','testing again<br />','','1611115769');

CREATE TABLE IF NOT EXISTS `app_comments_access` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `access_groups_id` int NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_comments_access VALUES
('4','21','6','view,create'),
('5','21','5','view,create'),
('6','21','4','view,create,update,delete'),
('7','22','5','view,create'),
('8','22','4','view,create,update,delete'),
('9','23','6','view,create'),
('10','23','4','view,create,update,delete'),
('11','24','5','view,create'),
('12','24','4','view,create,update,delete'),
('13','83','6','view'),
('14','83','12','view,create,update,delete'),
('15','83','5','view,create,update,delete'),
('16','83','4','view,create,update,delete');

CREATE TABLE IF NOT EXISTS `app_comments_forms_tabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_comments_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `comments_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `fields_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_comments_id` (`comments_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_comments_history VALUES
('5','194','1008','104'),
('6','195','1008','104'),
('7','196','1008','103'),
('8','196','0','1610662424'),
('9','197','1002','Graduate High School'),
('10','198','1002','Prepare for the SAT'),
('11','202','1008','103'),
('12','202','0','1610751994'),
('13','203','1002','Associate\'s Degree'),
('14','206','1008','103'),
('15','206','0','1610768516'),
('18','218','1008','103'),
('19','218','0','1610986362'),
('20','219','1008','104'),
('21','220','1008','103'),
('22','220','0','1610987207'),
('23','222','1008','103'),
('24','222','0','1610987625'),
('25','223','1008','103'),
('26','223','0','1610987984');

CREATE TABLE IF NOT EXISTS `app_configuration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `configuration_name` varchar(255) NOT NULL,
  `configuration_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=104 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_configuration VALUES
('9','CFG_APP_NAME','Lambent Data - OurREACH'),
('10','CFG_APP_SHORT_NAME','OurREACH'),
('11','CFG_APP_LOGO','app_logo_1609777139.png'),
('12','CFG_EMAIL_USE_NOTIFICATION','1'),
('13','CFG_EMAIL_SUBJECT_LABEL',''),
('14','CFG_EMAIL_AMOUNT_PREVIOUS_COMMENTS','2'),
('15','CFG_EMAIL_COPY_SENDER','0'),
('16','CFG_EMAIL_SEND_FROM_SINGLE','0'),
('17','CFG_EMAIL_ADDRESS_FROM','jrobinson24@gmail.com'),
('18','CFG_EMAIL_NAME_FROM','jrobinson24@gmail.com'),
('19','CFG_EMAIL_USE_SMTP','1'),
('20','CFG_EMAIL_SMTP_SERVER','email-smtp.us-east-2.amazonaws.com'),
('21','CFG_EMAIL_SMTP_PORT','587'),
('22','CFG_EMAIL_SMTP_ENCRYPTION',''),
('23','CFG_EMAIL_SMTP_LOGIN','AKIAZYVI7JMNYRHMF6O3'),
('24','CFG_EMAIL_SMTP_PASSWORD','BKIjh/fV5kaSGiFy09GTCVMJiaO/BhEQnSYiTpvCP98y'),
('25','CFG_LDAP_USE','0'),
('26','CFG_LDAP_SERVER_NAME',''),
('27','CFG_LDAP_SERVER_PORT',''),
('28','CFG_LDAP_BASE_DN',''),
('29','CFG_LDAP_UID',''),
('30','CFG_LDAP_USER',''),
('31','CFG_LDAP_EMAIL_ATTRIBUTE',''),
('32','CFG_LDAP_USER_DN',''),
('33','CFG_LDAP_PASSWORD',''),
('34','CFG_LOGIN_PAGE_HEADING','Login to OurREACH'),
('35','CFG_LOGIN_PAGE_CONTENT',''),
('36','CFG_APP_TIMEZONE','America/New_York'),
('37','CFG_APP_DATE_FORMAT','m/d/Y'),
('38','CFG_APP_DATETIME_FORMAT','m/d/Y H:i'),
('39','CFG_APP_ROWS_PER_PAGE','10'),
('40','CFG_REGISTRATION_EMAIL_SUBJECT',''),
('41','CFG_REGISTRATION_EMAIL_BODY',''),
('42','CFG_PASSWORD_MIN_LENGTH','5'),
('43','CFG_APP_LANGUAGE','english.php'),
('44','CFG_APP_SKIN','default'),
('45','CFG_PUBLIC_USER_PROFILE_FIELDS',''),
('46','CFG_MAINTENANCE_MODE','0'),
('47','CFG_MAINTENANCE_MESSAGE_HEADING',''),
('48','CFG_MAINTENANCE_MESSAGE_CONTENT',''),
('49','CFG_APP_LOGIN_MAINTENANCE_BACKGROUND',''),
('50','CFG_CUSTOM_CSS_TIME','1611092390'),
('51','CFG_PLUGIN_EXT_INSTALLED','1'),
('52','CFG_PLUGIN_EXT_LICENSE_KEY','3498343230363234376236303036369636963036323434323168'),
('53','CFG_ENABLE_CHAT','1'),
('54','CFG_CHAT_SOUND_NOTIFICATION','skype_chat'),
('55','CFG_CHAT_INSTANT_NOTIFICATION','1'),
('56','CFG_CHAT_SEND_ALERTS','0'),
('57','CFG_CHAT_ALERTS_SUBJECT',''),
('58','CFG_MAIL_INTEGRATION','1'),
('59','CFG_MAIL_DISPLAY_IN_HEADER','1'),
('60','CFG_MAIL_DISPLAY_IN_MENU','0'),
('61','CFG_MAIL_ROWS_PER_PAGE','10'),
('62','CFG_MAIL_DATETIME_FORMAT','m/d/Y H:i'),
('63','CFG_NOTIFICATIONS_SCHEDULE','0'),
('64','CFG_SEND_EMAILS_ON_SCHEDULE','0'),
('65','CFG_MAXIMUM_NUMBER_EMAILS','3'),
('66','CFG_APP_LOGIN_PAGE_BACKGROUND','app_bg_1610729957.jpg'),
('67','CFG_LOGIN_PAGE_HIDE_REMEMBER_ME','0'),
('68','CFG_LOGIN_DIGITAL_SIGNATURE_MODULE',''),
('69','CFG_APP_LOGO_URL',''),
('70','CFG_APP_COPYRIGHT_NAME','Lambent Data'),
('71','CFG_APP_NUMBER_FORMAT','2/./*'),
('72','CFG_APP_FIRST_DAY_OF_WEEK','1'),
('73','CFG_DISABLE_CHECK_FOR_UPDATES','0'),
('74','CFG_HIDE_POWERED_BY_TEXT','1'),
('75','CFG_APP_DISPLAY_USER_NAME_ORDER','firstname_lastname'),
('76','CFG_ALLOW_CHANGE_USERNAME','0'),
('77','CFG_ALLOW_REGISTRATION_WITH_THE_SAME_EMAIL','0'),
('78','CFG_INCOMING_CALL_ENTITY','0'),
('79','CFG_ENCRYPT_FILE_NAME','1'),
('80','CFG_RESIZE_IMAGES','1'),
('81','CFG_MAX_IMAGE_WIDTH','1600'),
('82','CFG_MAX_IMAGE_HEIGHT','900'),
('83','CFG_RESIZE_IMAGES_TYPES','1,2,3'),
('84','CFG_SKIP_IMAGE_RESIZE','5000'),
('85','CFG_USE_GLOBAL_SEARCH','1'),
('86','CFG_GLOBAL_SEARCH_DISPLAY_IN_HEADER','1'),
('87','CFG_GLOBAL_SEARCH_DISPLAY_IN_MENU','0'),
('88','CFG_GLOBAL_SEARCH_ALLOWED_GROUPS','0,6,12,5,4'),
('89','CFG_GLOBAL_SEARCH_ROWS_PER_PAGE','10'),
('90','CFG_GLOBAL_SEARCH_INPUT_TOOLTIP','Search'),
('91','CFG_GLOBAL_SEARCH_INPUT_MIN','3'),
('92','CFG_GLOBAL_SEARCH_INPUT_MAX','40'),
('93','CFG_APP_FAVICON',''),
('94','CFG_CREATE_ATTACHMENTS_PREVIEW','0'),
('95','CFG_PUBLIC_CALENDAR_DEFAULT_VIEW','agendaWeek'),
('96','CFG_PUBLIC_CALENDAR_VIEW_MODES','agendaWeek'),
('97','CFG_PUBLIC_CALENDAR_HIGHLIGHTING_WEEKENDS','.fc-mon,.fc-tue,.fc-wed'),
('98','CFG_PUBLIC_CALENDAR_MIN_TIME',''),
('99','CFG_PUBLIC_CALENDAR_MAX_TIME',''),
('100','CFG_PUBLIC_CALENDAR_TIME_SLOT_DURATION','00:30:00'),
('101','CFG_PUBLIC_CALENDAR_SEND_ALERTS','0'),
('102','CFG_PUBLIC_CALENDAR_ALERTS_TIME','00'),
('103','CFG_PUBLIC_CALENDAR_ALERTS_SUBJECT','kevinmcclarren22@gmail.com');

CREATE TABLE IF NOT EXISTS `app_dashboard_pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_by` int NOT NULL,
  `sections_id` int NOT NULL,
  `type` varchar(16) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `icon` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `color` varchar(16) NOT NULL,
  `users_fields` text NOT NULL,
  `users_groups` text NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_sections_id` (`sections_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_dashboard_pages VALUES
('6','27','0','page','1','Welcome','','<div>Welcome to OurREACH! Reach your goals by setting milestones and tracking your progress.</div>\r\n\r\n<div>&nbsp;\r\n<hr /></div>\r\n','default','','0,6','0'),
('7','27','0','page','1','Dashboard','fa-tachometer','This is your dashboard.','default','','0,6','1');

CREATE TABLE IF NOT EXISTS `app_dashboard_pages_sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `grid` tinyint(1) NOT NULL,
  `sort_order` smallint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_emails_on_schedule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `date_added` bigint unsigned NOT NULL,
  `email_to` varchar(255) NOT NULL,
  `email_to_name` varchar(255) NOT NULL,
  `email_subject` varchar(255) NOT NULL,
  `email_body` text NOT NULL,
  `email_from` varchar(255) NOT NULL,
  `email_from_name` varchar(255) NOT NULL,
  `email_attachments` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `notes` text NOT NULL,
  `display_in_menu` tinyint(1) DEFAULT '0',
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=85 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entities VALUES
('1','0','Users','','0','10'),
('35','0','Provider\'s Corner','','0','0'),
('52','0','SMS','Allows for users to send SMS messages to other users (i.e. provider to client and vice versa). Messaging is unidirectional.','0','3'),
('57','0','Email','','0','0'),
('83','0','Milestones','','0','0'),
('84','0','Recurring Goals','','0','0');

CREATE TABLE IF NOT EXISTS `app_entities_access` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `access_groups_id` int NOT NULL,
  `access_schema` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entities_access VALUES
('72','35','12','view,create,update,update_selected,copy,move,delete,delete_creator,export'),
('77','1','12','view,create,update,delete,delete_creator,export,reports'),
('82','35','4','view,create,update,update_selected,copy,move,delete,delete_selected'),
('83','1','4','view,create,update,delete,delete_creator,export,reports'),
('88','35','5','view,create,update,update_selected,copy,move,delete,delete_selected'),
('89','1','5','view,create,update,delete,delete_creator,export,reports'),
('92','35','6','view'),
('100','52','13','view_assigned,create,update,view'),
('101','52','6','view_assigned,create,update,view'),
('102','52','12','view,create,update,delete'),
('103','52','5','view,create,update,delete'),
('104','52','4','view,create,update,delete'),
('105','57','13','view'),
('106','57','6','view'),
('107','57','12','view,create,update,delete'),
('108','57','5','view,create,update,delete'),
('109','57','4','view,create,update,delete'),
('190','84','13',''),
('191','84','6','view_assigned,create,update,update_selected,copy,move,repeat,delete,delete_selected,view'),
('192','84','12','view_assigned,create,update,update_selected,copy,move,repeat,delete,delete_selected,view'),
('193','84','5','view_assigned,create,update,update_selected,copy,move,repeat,delete,delete_selected,view'),
('194','84','4','view_assigned,create,update,update_selected,copy,move,repeat,delete,delete_selected,view'),
('195','83','13',''),
('196','83','6','view_assigned,create,update,update_selected,copy,move,delete,delete_selected,export,view'),
('197','83','12','view_assigned,create,update,update_selected,copy,move,delete,delete_selected,view'),
('198','83','5','view_assigned,create,update,update_selected,copy,move,delete,delete_selected,view'),
('199','83','4','view_assigned,create,update,update_selected,copy,move,delete,delete_selected,view'),
('200','35','13','');

CREATE TABLE IF NOT EXISTS `app_entities_configuration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `configuration_name` varchar(255) NOT NULL,
  `configuration_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=437 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entities_configuration VALUES
('11','1','menu_title','Users'),
('12','1','listing_heading','Users'),
('13','1','window_heading','User Info'),
('14','1','insert_button','Add User'),
('15','1','use_comments','0'),
('57','1','menu_icon',''),
('58','1','reports_hide_insert_button','1'),
('59','1','email_subject_new_item',''),
('60','1','email_subject_updated_item',''),
('61','1','disable_notification','0'),
('62','1','disable_internal_notification','0'),
('63','1','disable_highlight_unread','0'),
('64','1','display_comments_id','1'),
('65','1','display_last_comment_in_listing','1'),
('66','1','use_editor_in_comments','1'),
('67','1','disable_attachments_in_comments','1'),
('68','1','email_subject_new_comment',''),
('69','1','send_notification_to_assigned','0'),
('70','1','redirect_after_adding','info'),
('71','1','redirect_after_click_heading','info'),
('73','1','item_page_columns_size','8-4'),
('74','1','item_page_details_columns','1'),
('75','1','item_page_comments_position','right_column'),
('76','1','item_page_subentity40_position','right_column'),
('77','1','hide_subentity40_if_empty','0'),
('78','1','item_page_subentity40_heading','Child/ren'),
('79','1','hide_subentity40_in_top_menu','0'),
('80','1','item_page_hidden_fields',''),
('81','1','heading_width_based_content','1'),
('85','35','item_page_columns_size','12-12'),
('86','35','item_page_details_columns','one_column_accordion'),
('87','35','item_page_comments_position','left_column'),
('88','35','item_page_subentity36_position','right_column'),
('89','35','hide_subentity36_if_empty','0'),
('90','35','item_page_subentity36_heading',''),
('91','35','hide_subentity36_in_top_menu','0'),
('92','35','item_page_field340_entity38_position','left_column'),
('93','35','hide_item_page_field340_if_empty','0'),
('94','35','item_page_field340_entity38_heading',''),
('95','35','item_page_hidden_fields',''),
('150','52','menu_title','SMS'),
('151','52','menu_icon','fa-comment'),
('152','52','listing_heading',''),
('153','52','window_heading',''),
('154','52','insert_button','New Text'),
('155','52','reports_hide_insert_button','1'),
('156','52','email_subject_new_item',''),
('157','52','email_subject_updated_item',''),
('158','52','disable_notification','0'),
('159','52','disable_internal_notification','0'),
('160','52','disable_highlight_unread','0'),
('161','52','use_comments','0'),
('162','52','display_comments_id','1'),
('163','52','display_last_comment_in_listing','1'),
('164','52','use_editor_in_comments','1'),
('165','52','disable_attachments_in_comments','1'),
('166','52','email_subject_new_comment',''),
('167','52','send_notification_to_assigned','0'),
('168','52','redirect_after_adding','subentity'),
('169','52','redirect_after_click_heading','subentity'),
('230','57','menu_title','Email'),
('231','57','menu_icon','fa-envelope'),
('232','57','listing_heading',''),
('233','57','window_heading',''),
('234','57','insert_button','New Email'),
('235','57','reports_hide_insert_button','1'),
('236','57','email_subject_new_item',''),
('237','57','email_subject_updated_item',''),
('238','57','disable_notification','0'),
('239','57','disable_internal_notification','0'),
('240','57','disable_highlight_unread','0'),
('241','57','use_comments','0'),
('242','57','display_comments_id','1'),
('243','57','display_last_comment_in_listing','1'),
('244','57','use_editor_in_comments','1'),
('245','57','disable_attachments_in_comments','1'),
('246','57','email_subject_new_comment',''),
('247','57','send_notification_to_assigned','0'),
('248','57','redirect_after_adding','subentity'),
('249','57','redirect_after_click_heading','subentity'),
('336','83','javascript_in_from','/*******************************************************************************************************************************/\r\n/* VARIABLES */\r\n/*******************************************************************************************************************************/\r\n\r\n/* Categories dropdowns and divs */\r\nvar category = $(\"#fields_1029_0\");\r\nvar subcategory = $(\"#fields_1029_1\");\r\nvar template = $(\"#fields_1029_2\");\r\n\r\nvar div_category = $(\".form-group-1029:nth-of-type(2)\");\r\nvar div_subcategory = $(\".form-group-1029:nth-of-type(3)\");\r\nvar div_template = $(\".form-group-1029:nth-of-type(4)\");\r\n\r\n/* Measure at start dropdowns and divs */\r\nvar ms_category = \"#fields_1052_0\";\r\nvar ms_subcategory = \"#fields_1052_1\";\r\nvar ms_template = \"#fields_1052_2\";\r\nvar ms_start = \"#fields_1052_3\";\r\n\r\nvar div_ms_category = $(\"div.form-group-1052:nth-child(1)\");\r\nvar div_ms_subcategory = $(\"div.form-group-1052:nth-child(2)\");\r\nvar div_ms_template = $(\"div.form-group-1052:nth-child(3)\");\r\nvar div_ms_start = $(\"div.form-group-1052:nth-child(4)\");\r\n\r\n\r\n/* Measure at end dropdowns and divs */\r\nvar me_category = \"#fields_1053_0\";\r\nvar me_subcategory = \"#fields_1053_1\";\r\nvar me_template = \"#fields_1053_2\";\r\nvar me_end = \"#fields_1053_3\";\r\n\r\nvar div_me_category = $(\"div.form-group-1053:nth-child(1)\");\r\nvar div_me_subcategory = $(\"div.form-group-1053:nth-child(2)\");\r\nvar div_me_template = $(\"div.form-group-1053:nth-child(3)\");\r\nvar div_me_end = $(\"div.form-group-1053:nth-child(4)\");\r\n\r\n/* Default measures and divs */\r\nvar default_start = $(\"#fields_1006\");\r\nvar default_end = $(\"#fields_1007\");\r\n\r\nvar div_default_start = $(\".form-group-1006\");\r\nvar div_default_end = $(\".form-group-1007\");\r\n\r\n/* Form fields that need to be autofilled */\r\nvar milestone_name = $(\"#fields_1002\");\r\nvar recurring_goals = $(\"#fields_997\");\r\nvar nonrecurring_goals = $(\"#fields_1003\");\r\nvar measures_type = $(\"#fields_1056\");\r\n\r\n/* Other fields */\r\nvar div_progress = $(\".form-group-1054\");\r\nvar div_measures_type = $(\".form-group-1056\");\r\n\r\n\r\n\r\n/*******************************************************************************************************************************/\r\n/* FUNCTIONS */\r\n/*******************************************************************************************************************************/\r\n\r\n/* Clears relevant fields in the form */\r\nfunction clear_form() {\r\n    milestone_name.val(\"\");\r\n    nonrecurring_goals.val(\"\");\r\n    recurring_goals.val(\"\");\r\n    div_default_start.val(\"\");\r\n    div_default_end.val(\"\");\r\n}\r\n\r\n/* Inputs relevant fields in the form */\r\nfunction load(milestoneName, recurringGoals, nonrecurringGoals) {\r\n    clear_form();\r\n    milestone_name.val(milestoneName);\r\n    recurring_goals.val(recurringGoals);\r\n    nonrecurring_goals.val(nonrecurringGoals);\r\n}\r\n\r\nfunction no_measures(){\r\n    div_default_start.hide();\r\n    div_default_end.hide();\r\n    div_ms_start.hide();\r\n    div_me_end.hide();\r\n    measures_type.val(\"None\");\r\n}\r\n\r\n/* For templates that set dropdown measures */\r\nfunction dropdown_measures(start, end) {\r\n    div_default_start.hide();\r\n    div_default_end.hide();\r\n    div_ms_start.show();\r\n    div_me_end.show();\r\n    $(ms_start + \" option:contains(\" + start + \")\").prop(\'selected\', true);\r\n    $(me_end + \" option:contains(\" + end + \")\").prop(\'selected\', true);\r\n    measures_type.val(\"Dropdown\");\r\n}\r\n\r\nfunction freeform_measures(start, end) {\r\n    div_ms_start.hide();\r\n    div_me_end.hide();\r\n    div_default_start.show();\r\n    div_default_end.show();\r\n    default_start.val(start);\r\n    default_end.val(end);\r\n    measures_type.val(\"Freeform\");\r\n}\r\n\r\nfunction default_measures(){\r\n    div_ms_start.hide();\r\n    div_me_end.hide();\r\n    div_default_start.show();\r\n    div_default_end.show();\r\n    default_start.val(\"\");\r\n    default_end.val(\"\");\r\n    measures_type.val(\"\");\r\n}\r\n\r\n\r\n\r\n/*******************************************************************************************************************************/\r\n/* EXECUTE */\r\n/*******************************************************************************************************************************/\r\n/* Hide dropdowns - taking note of when you Edit a form */\r\nif (milestone_name.val() == \"\") {\r\n    div_template.hide();\r\n    div_subcategory.hide();\r\n}\r\n\r\nif (measures_type.val() == \"Dropdown\") {\r\n    div_default_start.hide();\r\n    div_default_end.hide();\r\n}\r\n\r\nelse if (measures_type.val() == \"Freeform\" || measures_type.val() == \"\") {\r\n    div_ms_start.hide();\r\n    div_me_end.hide();\r\n}\r\n\r\nelse if (measures_type.val() == \"None\") {\r\n    default_start.hide();\r\n    default_end.hide();\r\n    div_ms_start.hide();\r\n    div_me_end.hide();\r\n}\r\n\r\ndiv_ms_category.hide();\r\ndiv_ms_subcategory.hide();\r\ndiv_ms_template.hide();\r\ndiv_me_category.hide();\r\ndiv_me_subcategory.hide();\r\ndiv_me_template.hide();\r\n\r\ndiv_progress.hide();\r\ndiv_measures_type.hide();\r\n\r\n/* Selectively shows dropdowns when you choose a category */\r\ncategory.change(function(){\r\n    var field_start = ms_category + \" option:contains(\" + $(this).find(\"option:selected\").text() + \")\";\r\n    $(field_start).prop(\'selected\',true);\r\n    $(ms_category).trigger(\'change\'); //trigger a change instead of click\r\n\r\n    var field_end = me_category + \" option:contains(\" + $(this).find(\"option:selected\").text() + \")\";\r\n    $(field_end).prop(\'selected\',true);\r\n    $(me_category).trigger(\'change\'); //trigger a change instead of click\r\n\r\n    div_template.hide();\r\n    if ($(this).find(\"option:selected\").text() == \"Choose a category...\") {\r\n        div_subcategory.hide()\r\n    }\r\n    else {\r\n        div_subcategory.show();\r\n    }\r\n})\r\n\r\n/* Selectively shows dropdowns when you choose a subcategory */\r\nsubcategory.change(function() {\r\n    var field_start = ms_subcategory + \" option:contains(\" + $(this).find(\"option:selected\").text() + \")\";\r\n    $(field_start).prop(\'selected\',true);\r\n    $(ms_subcategory).trigger(\'change\'); //trigger a change instead of click\r\n\r\n    var field_end = me_subcategory + \" option:contains(\" + $(this).find(\"option:selected\").text() + \")\";\r\n    $(field_end).prop(\'selected\',true);\r\n    $(me_subcategory).trigger(\'change\'); //trigger a change instead of click\r\n\r\n\r\n    if ($(this).find(\"option:selected\").text() == \"\") div_template.hide();\r\n    else div_template.show();\r\n})\r\n\r\n/* Determines which template to load in based on user choice */\r\ntemplate.change(function(){\r\n    /* Sync the categories multilevel dropdown, and the measures */\r\n    var field_start = ms_template + \" option:contains(\" + $(this).find(\"option:selected\").text() + \")\";\r\n    $(field_start).prop(\'selected\',true);\r\n    $(ms_template).trigger(\'change\'); //trigger a change instead of click\r\n\r\n    var field_end = me_template + \" option:contains(\" + $(this).find(\"option:selected\").text() + \")\";\r\n    $(field_end).prop(\'selected\',true);\r\n    $(me_template).trigger(\'change\'); //trigger a change instead of click\r\n\r\n    switch($(this).find(\"option:selected\").text()) {\r\n        // EDUCATION\r\n            // College\r\n                case \"Custom Milestone\":\r\n                    clear_form();\r\n                    default_measures();\r\n                    break;\r\n\r\n        // HOUSING\r\n            // Emergency Shelter\r\n                case \"Custom Milestone\":\r\n                    clear_form();\r\n                    default_measures();\r\n                    break;\r\n                case \"Move to shelter through faith congregation\":\r\n                    load(\"Move to shelter through faith congregation\", \"Make a daily account of all my belongings\\nCall friends and family\", \"Gather my belongings to take to the shelter\\nCalculate housing budget\\nCheck Provider\'s Corner for emergency housing options\\nResearch and locate appropriate shelter\\nJoin Facebook housing groups\\nAsk church leaders for support and guidance\\nCall a local help hotline\\nVisit a local food bank\\nTell friends and family where I am\");\r\n                    dropdown_measures(\"Living on street\", \"Faith congregation\");\r\n                    break;\r\n                case \"Move to shelter through other volunteer group\":\r\n                    load(\"Move to shelter through other volunteer group\", \"Make a daily account of all my belongings\\nCall friends and family\", \"Gather my belongings to take to the shelter\\nCalculate housing budget\\nResearch and locate appropriate shelter\\nJoin Facebook housing groups\\nTell friends and family where I am\\nCall a local help hotline\\nVisit a local food bank\");\r\n                    dropdown_measures(\"Living on street\", \"Volunteer group shelter\");\r\n                    break;\r\n                case \"Move to traditional shelter\":\r\n                    load(\"Move to traditional shelter\", \"Make a daily account of all my belongings\\nCall friends and family\", \"Gather my belongings to take to the shelter\\nCalculate my housing budget\\nResearch and locate appropriate shelter\\nJoin Facebook Housing groups\\nVisit a traditional shelter\\nCall a local help hotline\\nVisit a local food bank\");\r\n                    dropdown_measures(\"Living on street\", \"Traditional shelter\");\r\n                    break;\r\n                case \"Move to home through rapid rehousing program\":\r\n                    load(\"Move to home through rapid rehousing program\", \"\", \"Research local rapid rehousing programs\\nCalculate my housing budget\\nVisit a rapid rehousing program office\\nDetermine fees/costs of different programs\\nAsk rapid rehousing program staff for support and guidance\\nApply for rapid rehousing\");\r\n                    dropdown_measures(\"Living on street\", \"Rapid Rehousing program\");\r\n                    break;\r\n\r\n            // Transitional Housing\r\n                case \"Move to transitional housing\":\r\n                    load(\"Move to transitional housing\", \"\", \"Research local transitional housing programs\\nCalculate my housing budget\\nVisit a transitional housing program office\\nDetermine fees/costs of different programs\\nAsk transitional housing program staff for support and guidance\\nApply for transitional housing\");\r\n                    dropdown_measures(\"Living on street\", \"Transitional housing\");\r\n                    break;\r\n\r\n            // Stay in current home\r\n                case \"Receive rental assistance\":\r\n                    load(\"Receive rental assistance\", \"Gather materials needed to apply for rental assistance\", \"Calculate housing budget\\nLook up local, state, and federal resources\\nApply for voucher programs\\nContact public housing agency\\nContact a housing counseling center\\nGet income verification (pay stubs or other pay verification, such as last year\'s tax returns, a letter from employers, invoices, etc)\\nGet proof of hardship (copies of medical bills, etc)\\nResearch local congregations and other organizations who could help with rental payments\\nAttend community meeting on housing issues\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Mediate rent with landlord\":\r\n                    load(\"Mediate rent with landlord\", \"Gather materials needed to engage in landlord mediation\", \"Calculate housing budget\\nContact a tenant\'s rights group\\nArrange for lead paint test - may be important to share with tenant\'s rights group\\nFind a local mediation service\\nGet income verification (pay stubs or otherpau verification, such as last year\'s tax returns, a letter from employer, invoices, etc)\\nGet proof of hardship (copies of medical bills, etc)\\nAttend community meeting on housing issues\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Receive mortgage assistance\":\r\n                    load(\"Receive mortgage assistance\", \"Open and regularly respond to mail from lender\\nStudy mortgage rights\", \"Make appointment with bank\\nContact a housing counselor approved by the US Department of Housing\\nContact lender to discuss difficulty making payments\\nReview budget\\nApply for federal mortgage assistance programs\\nApply for foreclosure mediation programs\\nResearch local congregations and other organizations who could help with mortgage payments\\nGet income verification (pay stubs or other pay verification, such as last year\'s tax returns, a letter from employer, invoices, etc)\\nGet proof of hardship (copies of medical bills, etc)\\nAttend community meeting on housing issues\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Restructure mortgage\":\r\n                    load(\"Restructure mortgage\", \"Open and regularly respond to mail from lender\\nStudy mortgage rights\", \"Review qualifications for mortgage restructuring programs\\nApply for federal restructuring programs\\nGet income verification (pay stubs or other pay verification, such as last year\'s tax returns, a letter from employer, invoices, etc)\\nGet proof of hardship (cpies of medical bills, etc)\\nContact lender to discuss options\\nAttend community meeting on housing issues\");\r\n                    no_measures;\r\n                    break;\r\n\r\n            // Permanent Housing\r\n                case \"Rent a home\":\r\n                    load(\"Rent a home\", \"Search for rental apts/houses online\\nSearch for rental apts/houses in the newspaper\\nApply for apartment\\nRespond to rental listings\\nAsk friends about rental apt/house prices\\nCompare rental apts/houses on real-estate app such as Zillow\\nSearch for rental apts/houses on Facebook Marketplace and Craigslist\\nApply to a different housing development today\", \"Calculate my housing budget\\nJoin Facebook housing groups\\nAsk landlord about reduced rent\\nMake appointment and rental affordable housing program\\nVisit an open house\\nVisit rental apts/houses\\nCheck how far away rental is from work, school, childcare, stores, and family\\nSave for down payment\\nMake appointment with bank\\nCheck for household safety hazards in desired apt/home\\nArrange for lead paint test in desired home\\nAttend community meeting on housing issues\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Buy a home\":\r\n                    load(\"Buy a home\", \"Search online apts/houses for sale\\nSearch in newspaper for apts/houses for sale\\nRespond to housing listings\\nAsk friends about apt/house prices for sale\\nCompare apts/houses on real-estate app\", \"Calculate my housing budget\\nJoin Facebook housing groups\\nVisit an open house\\nCheck my credit score\\nMake appointment with affordable housing purchase program\\nFind a real estate agent\\nMake appointment with bank\\nCheck how far away house is from work, school, childcare, stores, and family\\nCheck for household safety hazards in desired apt/home\\nArrange for lead paint test in desired home\\nArrange for house inspection\\nAttend community meeting on housing issues\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Find permanent supportive housing\":\r\n                    load(\"Find permanent supportive housing\", \"\", \"Research local supportive housing programs\\nCalculate my housing budget\\nVisit a supportive housing program office\\nDetermine fees/costs of different programs\\nAsk supportive housing program staff for support and guidance\\nApply for supportive housing\\nAttend community meeting on supportive housing\");\r\n                    no_measures;\r\n                    break;\r\n\r\n        // MONEY MANAGEMENT\r\n            // Budgeting\r\n                case \"Make a financial plan for the future\":\r\n                    load(\"Make a financial plan for the future\", \"Record my income and expenses for the day\\nDo 30 minutes in trusted online financial literacy course\", \"Make a list of needs & wants\\nBuild my six-month budget\\nTalk to family about budget planning\\nPlan for emergency fund\\nPlan for monthly payment(s) towards debt\\nPlan for saving beyond emergency fund\\nFind a financial advisor (free and trusted program at non-profit org., library, church, etc.)\\nEnroll in trusted online financial literacy program\\nMake budgt spreadsheet\\nUse trusted online budget service (like mint.com) without linking accounts\\nLink accounts with trusted online budget service (like mint.com)\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Create and stick to monthly and weekly budgets\":\r\n                    load(\"Create and stick to monthly and weekly budgets\", \"Record my income and expenses as they occur\\nDo 30 minutes in trusted online financial literacy course\\nComparison shop when buying items\", \"Make a list of needs & wants\\nBuild my monthly budget\\nBuild my weekly budget\\nMake sure to include items that occur less often than monthly\\nTalk to family about budget planning\\nEnroll in trusted online financial literacy program\\nAsk financial advisor (free program at non-profit org., library, church etc.) about budgeting\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Participate in financial child support\":\r\n                    load(\"Participate in financial child support\", \"Communicate with other parent about payment schedule (in-person, through txt, through a lawyer, etc)\\nKeep updated on state\'s child support guidelines\\nMak child support payment\\nCheck that I received child support payment\\nCheck that parent or guardian received child support payment\\nCheck that parent or guardian made child support payment\", \"Include child support in current budget\\nConsider different payment options (Venmo, Zell, etc)\\nChoose best payment option (Venmo, Zell, etc)\\nContact Child support Services or family law attorney for assistance or questions\\nContact Child Support Services or family law attorney if trying to modify child support order\");\r\n                    no_measures;\r\n                    break;\r\n            // Personal Finance\r\n                case \"Plan to reduce debt\":\r\n                    load(\"Plan to reduce debt\", \"Consider credit card interest rate before using card\\nSave enough to pay $10 more than minimum payment on credit card each month\\nTalk to family or friend(s) about reducing debt\\nAvoid payday loans\\nList the interest rates on my credit cards\\nTrack credit card payments\\nPay credit cards on time\\nPay student loans on time\\nAsk financial advisor (free program at non-profit org., library, church, etc.) about reducing debt\\nPay more than minimum on highest rate credit cards\\nBrainstorm with a trusted advisor about creative ways to make more money\\nBrainstorm with a trusted advisor about areas to cut back (stop buying coffee out, switching to a cheaper phone plan, etc), Learn about Dave Ramsey\'s Debt Snowall\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Get out of OverDraft\":\r\n                    load(\"Get out of OverDraft\", \"Refer to list of payments due and income expected\", \"Make list of payments due and income expected (use paper or computer)\\nSet up overdraft protection\\nSchedule appointment at bank\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Establish checking account at bank\":\r\n                    load(\"Establish checking account at bank\", \"\", \"Ask financial advisor (free program at non-profit oorg., library, church, etc.) about banks\\nResearch banks for favorable programs (low-cost checking, available ATMs, etc.)\\nSchedule appointment at bank\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Establish Emergency Fund\":\r\n                    load(\"Establish Emergency Fund\", \"Pay 5% of every paycheck into emergency fund\",\"Open savings account\\nSchedule appointment at bank\\nFind introductory interest-free repayment credit card to use just in emergencies\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Establish good credit\":\r\n                    load(\"Establish good credit\", \"Do 30 minutes in trusted online financial literacy course\\nSave enough too pay $10 more than minimum payment on credit card each month\\nPay student loans on time\\nCheck for credit report errors\", \"Ask financial advisor (free program at non-profit org., library, church, etc.) about building good credit\\nResearch banks for favorable cedit cards with low interest\\nSchedule appointment at bank\\nAvoid payday loans\\nOrganize my credit records\\nApply for secured credit card account(s)\");\r\n                    no_measures;\r\n                    break;\r\n            // Income Programs\r\n                case \"Establish necessary identification documents\":\r\n                    load(\"Establish necessary identification documents\", \"\", \"Identify programs that would match my needs\\nMake a list of each program\'s required identification documents\\nContact program representative with questions\\nOrganize required identification documents\\nSign-up for driving (to get driver\'s license)\\nContact state department of vital records (to get birth certificate)\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Apply for SNAP\":\r\n                    load(\"Apply for SNAP\", \"\", \"Make a budget of current needs and spending\\nMake a list of needs (based on current income, spending, etc)\\nCheck that SNAP matches my needs\\nResearch state eligibility requirements (resource and income limits, etc)\\nCheck that I match state\'s eligibility requirements (resource and income limits, etc)\\nCall state\'s SNAP information hotline with questions\\nVisit state agency\'s website for more information\\nSubmit state\'s SNAP application\\nDo eligibility interview\\nAfter certification period ends, apply to recertify to continue receiving SNAP benefits\\nContact local SNAP office with questions\\nRequest a fair hearing with an official (if I disagree with a decision made on my SNAP case)\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Apply for WIC\":\r\n                    load(\"Apply for WIC\", \"\", \"Make a budget of current needs and spending\\nMake a list of needs (based on current income, spending, etc)\\nCheck that WIC matches my needs\\nContact state or local agency to set up an appointment\\nResearch state eligibility requirements (category, residency, income, nutrition risk, etc)\\nCheck that I match state\'s eligibility requirements (category, residency, income, nutrition risk, etc)\\nBring all required materials to WIC appointment\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Participate in relevant income programs\":\r\n                    load(\"Participate in relevant income programs\", \"\", \"Make a budget of current needs and spending\\nMake a list of needs (based on current income, spending, etc)\\nResearch state and federal programs\\nIdentify programs that would match my needs\\nCheck program eligibility requirements (income level, residency requirements, etc)\\nMake a list of each program\'s required identification documents\\nContact program representative with questions\\nApply to programs that would match my needs\");\r\n                    no_measures;\r\n                    break;\r\n\r\n\r\n        // HEALTH\r\n            // Main\r\n                case \"Custom Milestone\":\r\n                    clear_form();\r\n                    default_measures();\r\n                    break;\r\n                case \"HbA1c\":\r\n                    load(\"Reach target HbA1c level\", \"Plan 5 healthy recipes to cook this week\\nWalk/Exercise for 30 minutes\\nMake weekly shopping list for healthy meals\\nDrink less alcohol\\nGo grocery shopping\\nSleep at least 6 hours total tonight\\nLook up new healthy recipe\\nDo monthly weigh-in\\nTake prescribed medication in AM\\nTake prescribed medication in PM\\nDrink 6 glasses of water\\nEat 6 servings of fruits/vegetables\\nWrite in my gratitude journal\\nMeditate/Do deep breathing\\nCheck blood sugar levels according to doctor\\nCheck feet daily\", \"Ask family or friend(s) to support healthy food choices\\nSign up for nutrition plan\\nSign up for exercise plan\\nResearch places to buy discounted fruits and vegetables\\nTalk with family or friend(s) about diabetes\\nAttend diabetes support group\\nSchedule an eye exam\");\r\n                    freeform_measures(\"___%\", \"___%\");\r\n                    break;\r\n                case \"Preventative Care\":\r\n                    load(\"Preventative care for this calendar year\", \" \", \"Schedule annual physical\\nHave annual physical\\nSchedule dentist visit\\nGo to dentist\\nEnroll in a stop smoking program\\nSchedule mammogram\\nHave mammogram\\nDiscuss contraceptive options with OB\\nTake contraceptive\\nChoose not to smoke today\");\r\n                    no_measures();\r\n                    break;\r\n                case \"Early Morning Fasting Blood Sugar Level\":\r\n                    load(\"Reach target blood sugar level\", \"Plan 5 healthy recipes to cook this week\\nWalk/Exercise for 30 minutes\\nReduce alcohol intake\\nSleep at least 6 hour total tonight\\nLook up new healthy recipe\\nTake prescribed medication in AM\\nDo monthly weigh-in\\nTake prescribed medication in PM\\nEat 6 servings of fruits/vegetables\\nWrite in my Gratitude Journal\\nAttend diabetes support group\\nMeditate/Do deep breathing\\nCheck blood sugar levels according to doctor\\nCheck feet daily\", \"Ask family or friend(s) to support healthy food choices\\nSign up for nutrition plan\\nSign up for exercise plan\\nTalk with family or friends about diabetes\\nSchedule an eye exam\\nGo to eye exam\");\r\n                    freeform_measures(\"___mg/dL\", \"___mg/dL\");\r\n                    break;\r\n                case \"Blood Pressure\":\r\n                    load(\"Reach target blood pressure level\", \"Plan 5 healthy recipes\\nWalk/Exercise for 30 minutes\\nDrink less alcohol\\nSleep for eat least 6 hours total tonight\\nTake prescribed medication in AM\\nDo monthly weigh-in\\nTake prescribed medication in PM\\nEat 6 servings of fruits/vegetables\\nAttend hypertension support group\\nWrite in my Gratitude Journal\\nMeditate/Do deep breathing\\nTake a break from social media\\nTrack whether foot/toe pain wakes me\\nCheck blood pressure level according to doctor\\nTake aspirin as recommended by doctor\", \"Ask family or friend(s) to support healthy food choices\\nSign up for nutrition plan\\nSign up for exercise plan\\nLook up new healthy recipe\\nSchedule an eye exam\\nGo to eye exam\\nTalk with family or friend(s) about having hypertension\");\r\n                    freeform_measures(\"___mmHg\", \"___mmHg\");\r\n                    break;\r\n                case \"Weight\":\r\n                    load(\"Reach target weight level\", \"Plan 5 healthy recipes to cook this week\\nWalk/Exercise for 30 minutes\\nDrink less alcohol\\nLook up new healthy recipe\\nSleep at least 6 hours total tonight\\nDo monthly weigh-in\\nTake prescribed medication in AM\\nTake prescribed medication in PM\\nEat 6 servings of fruits/vegetables\\nWrite in my Gratitude Journal\\nMeditate/Do deep breathing\\nTake a break from social media\\nDrink water instead of soda or juice\\nEat 3 meals a day\", \"Ask family or friend(s) to support healthy food choices\\nSign up for nutrition plan\\nSign up for exercise plan\");\r\n                    freeform_measures(\"___lbs\", \"___lbs\");\r\n                    break;\r\n                case \"Height\":\r\n                    load(\"Track height\", \"\", \"\");\r\n                    freeform_measures(\"___ft\", \"\");\r\n                    break;\r\n                case \"BMI\":\r\n                    load(\"Reach target BMI\", \"Plan 5 healthy recipes to cook this week\\nWalk/Exercise for 30 minutes\\nDrink less alcohol\\nLook up new healthy recipe\\nSleep at least 6 hours total tonight\\nDo monthly weigh-in\\nTake prescribed medication in AM\\nTake prescribed medication in PM\\nEat 6 servings of fruits/vegetables\\nWrite in my Gratitude Journal\\nMeditate/Do deep breathing\\nTake a break from social media\\nDrink water instead of soda or juice\\nEat 3 meals a day\", \"Ask family or friend(s) to support healthy food choices\\nSign up for nutrition plan\\nSign up for exercise plan\");\r\n                    freeform_measures(\"\", \"\");\r\n                    break;\r\n            // Mental Health\r\n                case \"Custom Milestone\":\r\n                    clear_form();\r\n                    default_measures();\r\n                    break;\r\n                case \"Peace Level\":\r\n                    load(\"Reach target peace level\",\"Write in Gratitude Journal\\nMeditate/Do deep breathing for at least 60 seconds\\nPray\\nTake a break from social media\\nTake prescribed mental health medication\\nGo to one-on-one therapy sessions\\nGo to family/couples therapy sessions\\nRead the Bible\\nGo for a walk\\nParticipate in faith congregation services\\nListen to inspiring music\\nListen to worship music\\nRead a chapter of a book by my favorite author\", \"Find a therapist or psychiatrist covered by health insurance\\nAsk family or friend(s) to support mental health choices\\nSet screen time limit on phone for social media\\nAttend group support meetings\\nTalk with a friend or family member about challenges and/or joys\\nPractice handling stressful situation (such as an upcoming difficult conversation)\");\r\n                    no_measures();\r\n                    break;\r\n\r\n        // Jobs\r\n            // Location\r\n                case \"Custom Milestone\":\r\n                    clear_form();\r\n                    default_measures();\r\n                    break;\r\n                case \"Close to home\":\r\n                    load(\"Close to home\", \"Ask friends or family about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSubmit an application to 2 job openings\\nReflect, talk to friends and family\\nPrepare for job interview\", \"Update resume\\nUpdate cover letter\\nPrepare 5 job interview questions\\nAsk friend, family, or mentor to look over the resume and cover letter before sending it out\\nUpload resume and cover letter to job-finding sites\");\r\n                    no_measures();\r\n                    break;\r\n                case \"Close to child/ren\'s school/s\":\r\n                    load(\"Close to child/ren\'s school/s\", \"Ask friends or family about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSubmit an application to 2 job openings\\nReflect, talk to friends and family\\nPrepare for job interview\", \"Update resume\\nUpdate cover letter\\nPrepare 5 job interview questions\\nAsk friend, family, or mentor to look over the resume and cover letter before sending it out\\nUpload resume and cover letter to job-finding sites\");\r\n                    no_measures();\r\n                    break;\r\n                case \"Easy Commute\":\r\n                    load(\"Easy Commute\", \"Ask friends or family about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSubmit an application to 2 job openings\\nReflect, talk to friends and family\\nPrepare for job interview\", \"Get a MetroCard, bus pass, transit pass, etc\\nUpdate resume\\nUpdate cover letter\\nPrepare 5 job interview questions\\nAsk friend, family, or mentor to look over the resume and cover letter before sending it out\\nUpload resume and cover letter to job-finding sites\");\r\n                    no_measures();\r\n                    break;\r\n            // Income & Benefits\r\n                case \"Custom Milestone\":\r\n                    clear_form();\r\n                    default_measures();\r\n                    break;\r\n                case \"Income is enough to support my family\":\r\n                    load(\"Income is enough to support my family\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSpend time networking\\nWork on improving skills\\nSubmit an application to 2 job listings\\nPrepare for job interview\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nLook up employee testimonials on online job sites (such as LinkedIn, Glassdoor, etc)\\nLook over budget\\nDiscuss different job opportunities with family\\nPrepare 5 job interview questions\\nAsk friend, family, or mentor to look over the resume and cover letter before sending it out\\nUpload resume and cover letter to job-finding sites\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Income is enough to live comfortably\":\r\n                    load(\"Income is enough to live comfortably\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSpend time networking\\nWork on improving skills\\nSubmit an application to 2 job listings\\nPrepare for job interview\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nLook up employee testimonials on online job sites (such as LinkedIn, Glassdoor, etc)\\nLook over budget\\nDiscuss different job opportunities with family\\nPrepare 5 job interview questions\\nAsk friend, family, or mentor to look over the resume and cover letter before sending it out\\nUpload resume and cover letter to job-finding sites\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Amount and type of benefits I want\":\r\n                    load(\"Amount and type of benefits I want\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSpend time networking\\nWork on improving skills\\nSubmit an application to 2 job listings\\nPrepare for job interview\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nLook up employee testimonials on online job sites (such as LinkedIn, Glassdoor, etc)\\nTalk to company recruiter\\nResearch more about benefits\\nPrepare 5 interview questions\\nAsk potential employer about benefits after the interview\\nAsk friend, family, or mentor to look over the resume and cover letter before sending it out\\nUpload resume and cover letter to job-finding sites\");\r\n                    no_measures;\r\n                    break;\r\n            // Schedule\r\n                case \"Custom Milestone\":\r\n                    clear_form();\r\n                    default_measures();\r\n                    break;\r\n                case \"Reliable work schedule similar each week\":\r\n                    load(\"Reliable work schedule similar each week\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper\\nSpend time networking\\nWork in improving skills\\nPractice talking with manager to ask for new schedule\\nSubmit an application to 2 job listings for steadier job\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nLook up employee testimonials on online job sites (such as LinkedIn, Glassdoor, etc)\\nTalk to company recruiter\\nMap out schedule I would like\\nMake appointment to talk with manager to ask for new schedule\\nPrepare 5 interview questions\\nPlan childcare\\nResearch work-from-home jobs\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Work hours during time of day/night I want\":\r\n                    load(\"Work hours during time of day/night I want\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper\\nSpend time networking\\nWork on improving skills\\nPractice talking with manager to ask for new schedule\\nSubmit an application to 2 job listings for steadier job\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nLook up employee testimonials to online job sites (such as LinkedIn, Glassdoor, etc)\\nTalk to company recruiter\\nMap out schedule I would like\\nMake appointment to talk with manager to ask about new schedule\\nPrepare 5 interview questions\\nPlan childcare\\nResearch work-from-home jobs\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Number of work hours I want\":\r\n                    load(\"Number of work hours I want\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper\\nSpend time networking\\nWork on improving skills\\nPractice talking with manager to ask for new schedule\\nSubmit an application to 2 job listings with number of hours I want\\nPrepare for job interviews\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nLook up employee testimonials on online job sites (such as LinkedIn, Glassdoor, etc)\\nTalk to company recruiter\\nMap out schedule I would like\\nMake appointment to talk with manager to ask for new schedule\\nPrepare 5 interview questions\");\r\n                    no_measures;\r\n                    break;\r\n\r\n            // Enjoyment\r\n                case \"Custom Milestone\":\r\n                    clear_form();\r\n                    default_measures();\r\n                    break;\r\n                case \"I make a positive difference\":\r\n                    load(\"I make a positive difference\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSpend time networking\\nWork on improving skills\\nSubmit an application to 2 job listings\\nPrepare for job interview\\nReflect, talk to fellow co-workers, friends, and family\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nLook up employee testimonials on online job sites (such as LinkedIn, Glassdoor, etc)\\nPrepare 5 interview questions\");\r\n                    no_measures;\r\n                    break;\r\n                case \"I enjoy my coworkers\":\r\n                    load(\"I enjoy my coworkers\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSpend time networking\\nWork on improving skills\\nSubmit an application to 2 job listings\\nPrepare for job interview\\nReflect, talk to fellow co-workers, friends, and family\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nLook up employee testimonials on online job sites (such as LinkedIn, Glassdoor, etc)\\nPrepare 5 interview questions\");\r\n                    no_measures;\r\n                    break;\r\n                case \"I feel appreciated & valued\":\r\n                    load(\"I feel appreciated & valued\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSpend time networking\\nWork on improving skills\\nSubmit an application to 2 job listings\\nPrepare for job interview\\nReflect, talk to fellow co-workers, friends, and family\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nLook up employee testimonials on online job sites (such as LinkedIn, Glassdoor, etc)\\nSchedule meeting with manager\\nPrepare 5 interview questions\");\r\n                    no_measures;\r\n                    break;\r\n                case \"I love what I do\":\r\n                    load(\"I love what I do\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSpend time networking\\nWork on improving skills\\nSubmit an application to 2 job listings\\nPrepare for job interview\\nReflect, talk to fellow co-workers, friends, and family\\nPractice for meeting with manager about different responsibilities\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nSchedule meeting with manager\\nPrepare 5 interview questions\");\r\n                    no_measures;\r\n                    break;\r\n                case \"It challenges me to grow\":\r\n                    load(\"It challenges me to grow\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSpend time networking\\nWork on improving skills\\nSubmit an application to 2 job listings\\nPrepare for job interview\\nReflect, talk to fellow co-workers, friends, and family\\nPractice for meeting with manager about different responsibilities\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nSchedule meeting with manager\\nPrepare 5 interview questions\");\r\n                    no_measures;\r\n                    break;\r\n                case \"It fits my personality\":\r\n                    load(\"It challenges me to grow\", \"Ask friends about job openings\\nSearch online for jobs\\nCheck the newspaper for jobs\\nSpend time networking\\nWork on improving skills\\nSubmit an application to 2 job listings\\nPrepare for job interview\\nReflect, talk to fellow co-workers, friends, and family\\nPractice for meeting with manager about different responsibilities\", \"Update resume\\nUpdate cover letter\\nPick appropriate attire for interview\\nSchedule meeting with manager\\nPrepare 5 interview questions\");\r\n                    no_measures;\r\n                    break;\r\n\r\n\r\n        // Education\r\n            // Education Level\r\n                case \"Custom Milestone\":\r\n                     clear_form();\r\n                     default_measures();\r\n                     break;\r\n                case \"High school diploma\":\r\n                    load(\"High school diploma\", \"Do study session with friend\\nComplete homework assignments\\nReview homework requirements\\nMak flashcards for test\\nPractice using computer\\nRead for fun for 30 minutes\\nAttend after-school tutoring with my teacher\\nGo to the school library to do homework\", \"Talk with guidance counselor\\nSet up a quiet place in my home to study and do homework\\nFind a study group\\nMake a plan for doing daily homework\\nMake a plan for doing longer projects\\nExplore ways to learn STEM(Science, Tech, Engin, Math)\");\r\n                    dropdown_measures(\"Some high school completed\", \"High school diploma\");\r\n                    break;\r\n                case \"GED\":\r\n                    load(\"GED\", \"Do study session with friend\\nStudy for GED exam for 1 hour\\nPractice using computer\\nRead for fun for 30 minutes\\nMake flashcards for test\", \"Research requirements for GED\\nFind online prep course\\nOrder study materials online\\nMake a plan for studying for GED\\nTake a practice GED exam\\nReview completed practice exam\\nCheck exam locations\\nRegister for GED exam\\nPrepare proper identification for exam\\nCheckout a GED prep book from the library\\nSet a budget for prep courses and the test\");\r\n                    dropdown_measures(\"Some high school completed\", \"GED\");\r\n                    break;\r\n                case \"Associate\'s degree\":\r\n                    load(\"Associate\'s degree\", \"Work on application materials for community college\\nDo homework\\nDo study session with friend\\nWork on application essay\", \"Talk with guidance counselor at school about applying to community college\\nResearch community college\\nApply for community college\\nApply for financial aid and scholarships\\nEnroll at community college\\nTrack degree progress and credit requirements\\nTalk with course advisor at community college\\nFind a study group\\nOrder study materials online\\nCreate flashcards\\nCheck ways to learn STEM (Science, Tech, Engin, Math) in community college\\nMake a plan for doing daily homework\\nMake a plan for doing longer projects\\nAsk teacher or mentor for recommendation letter\\nResearch fields and programs\\nRequest copies of GED/high school transcript\\nAsk guidance counselor for application fee waivers\");\r\n                    dropdown_measures(\"Some high school completed\", \"Associate\'s degree\");\r\n                    break;\r\n                case \"Bachelor\'s degree\":\r\n                    load(\"Bachelor\'s degree\", \"Work on application materials for college/university\\nDo homework\\nDo study session with friend\\nResearch internships\\nWork on application essays\\nAsk guidance counselor to review and edit application essay\\nWork on scholarship application materials/Apply for scholarships\\nStudy for SAT\\nStudy for ACT\\nMake flashcards for test\", \"Talk with guidance counselor at school about applying to college/university\\nResearch colleges/universities (including children-friendly ones)\\nApply for colleges/university\\nApply for financial aid and scholarships\\nEnroll att college/university\\nTrack degree progress and credit requirements\\nTalk with academic advisor at college/university\\nMake a plan for doing daily homework\\nMake a plan for doing longer projects\\nFind a study group\\nOrder study materials online\\nApply for internships\\nGo to tutoring sessions\\nCheck ways to learn STEM (Science, Tech, Engin, Math) in college/university\");\r\n                    dropdown_measures(\"High school diploma\", \"Bachelor\'s degree\");\r\n                    break;\r\n                case \"Military with related training\":\r\n                    load(\"Military with related training\", \"Think about elements involved with military active-duty and reserves\\nTalk with family and friends about military\\nWork on application materials for military\", \"Talk with guidance counselor at school about military\\nResearch programs in military\\nApply for military\\nCheck ways to learn STEM (Science, Tech, Engin, Math) in military\\nResearch commitments before enlisting\\nEnlist in military active-duty\\nEnlist in military reserves\\nKnow schedule for first three months before enlisting\");\r\n                    dropdown_measures(\"High school diploma\", \"Military with related training\");\r\n                    break;\r\n                case \"Trade/technical/vocational training\":\r\n                    load(\"Trade/technical/vocational training\", \"Work on application materials for trade/technical/vocational training\\nDo study session with friend\\nDo homework\\nPractice technical skills\", \"Talk with guidance counselor at school about trade/technical/vocational training\\nStudy for trade school entrance exam\\nApply for financial aid and scholarships\\nApply for apprenticeships\\nJoin a study group\\nCheck ways to learn STEM (Science, Tech, Engin, Math) in trade/technical/vocational training\\nMake a plan for doing daily homework\\nMake a plan for doing longer projects\\nResearch vocational schools in the area\\nResearch childcare options\");\r\n                    dropdown_measures(\"High school diploma\", \"Trade/technical/vocational training\");\r\n                    break;\r\n                case \"Postgraduate degree\":\r\n                    load(\"Postgraduate degree\", \"Work on application materials for graduate program\\nDo homework\\nDo study session with friend\\nMake flashcards for test\", \"Talk with academic advisor at school about applying to graduate programs\\nResearch graduate programs (including children-friendly ones)\\nTake the GRE/other entrance exam(s)\\nAsk for references\\nApply for colleges/universities\\nApply for financial aid and scholarships\\nEnroll at college/university\\nTrack degree programs and credit requirements\\nTalk with academic advisor in grad program\\nFind a study group\\nMake a plan for doing daily homework\\nMake a plan for doing longer projects\");\r\n                    dropdown_measures(\"Bachelor\'s degree\", \"Postgraduate degree\");\r\n                    break;\r\n           // Location\r\n                case \"Custom Milestone\":\r\n                    clear_form();\r\n                    default_measures();\r\n                    break;\r\n                case \"Close to home \":\r\n                    load(\"Close to home\", \"\" , \"Talk with guidance counselor at school\\nCheck locations of courses before enrolling\\nGet a MetroCard, bus pass, transit pass, etc\\nSearch online for degree programs nearby\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Close to child/ren\'s school/s \":\r\n                    load(\"Close to child/ren\'s school/s \", \"\" , \"Talk with guidance counselor at school\\nCheck locations of courses before enrolling\\nGet a MetroCard, bus pass, transit pass, etc\\nSearch online for degree programs nearby\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Easy commute \":\r\n                    load(\"Easy commute \", \"\" , \"Talk with guidance counselor at school\\nCheck locations of courses before enrolling\\nGet a MetroCard, bus pass, transit pass, etc\\nSearch online for degree programs nearby\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Virtual learning that is not self-paced \":\r\n                    load(\"Virtual learning that is not self-paced\", \"Use online scheduling tool (such as Google calendar) to plan courseload\\nPractice using computer\", \"Schedule meeting with academic advisor to learn about online options at current school\\nSearch for online degree programs\\nCompare different virtual learning options\");\r\n                    no_measures;\r\n                    break;\r\n          // Schedule\r\n                case \"Custom Milestone\":\r\n                     clear_form();\r\n                     default_measures();\r\n                     break;\r\n                case \"Classes scheduled during time of day/night I want\":\r\n                    load(\"Classes scheduled during time of day/night I want\", \"Use online scheduling tool (such as Google calendar) to plan courseload\", \"Schedule meeting with academic advisor\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Online courses I can do at my own pace\":\r\n                    load(\"Online courses I can do at my own pace\", \"Use online scheduling tool (such as Google calendar) to plan courseload\\nPractice using computer\", \"Schedule meeting with academic advisor to learn about online options at current school\\nResearch online self-paced courses in my field at various schools\\nSet up a space at home for studying\");\r\n                    no_measures;\r\n                    break;\r\n\r\n          // Enjoyment\r\n                case \"Custom Milestone\":\r\n                     clear_form();\r\n                     default_measures();\r\n                     break;\r\n                case \"Workload somewhat manageable\":\r\n                    load(\"Workload somewhat manageable\", \"Use online scheduling tool (such as Google calendar) to manage workload\\nDo study session with friend\", \"Take with guidance counselor at school\\nDiscuss time management ideas with family and friends\");\r\n                    dropdown_measures(\"Workload not manageable\", \"Workload somewhat manageable\");\r\n                    break;\r\n                case \"Workload fully manageable\":\r\n                    load(\"Workload fully manageable\", \"Use online scheduling tool (such as Google calendar) to manage workload\\nDo study session with friend\", \"Take with guidance counselor at school\\nDiscuss time management ideas with family and friends\");\r\n                    dropdown_measures(\"Workload not manageable\", \"Workload fully manageable\");\r\n                    break;\r\n                case \"Healthy school-rest-of-life balance\":\r\n                    load(\"Healthy school-rest-of-life balance\", \"Use online scheduling tool (such as Google calendar) to manage workload\\nWalk/exercise for 30 minutes\\nSpend some time with friends\\nStudy when baby is napping\", \"Take with guidance counselor at school\\nDiscuss school-rest-of-life balance with family and friends\\nAsk friend or family to babysit once a week so I can study\");\r\n                    no_measures;\r\n                    break;\r\n                case \"I like going to class\":\r\n                    load(\"I like going to class\", \"Reflect on the class: talk to a friend, fellow students, or a family member\\nWrite in my gratitude journal\", \"Talk with guidance counselor at school\");\r\n                    no_measures;\r\n                    break;\r\n                case \"It challenges me to grow \":\r\n                    load(\"It challenges me to grow\", \"Reflect on the class: talk to a friend, fellow students, or a family member\\nWrite in my gratitude journal\", \"Talk with guidance counselor at school\");\r\n                    no_measures;\r\n                    break;\r\n                case \"Class topics genuinely interest me\":\r\n                    load(\"Class topics genuinely interest me\", \"Reflect on the class: talk to a friend, fellow students, or a family member\\nWrite in my gratitude journal\",\"Talk with guidance counselor or academic advisor\\nLook up course descriptions\\nAsk previous students about the material, professors, interests, etc\");\r\n                    no_measures;\r\n                    break;\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n        }\r\n  });\r\n'),
('337','83','javascript_onsubmit','var category = $(\"#fields_1029_0\");\r\nvar subcategory = $(\"#fields_1029_1\");\r\n\r\nif (category.find(\"option:selected\").text() == \"Choose a category...\" \r\n|| subcategory.find(\"option:selected\").text() == \"\") {\r\n    alert(\'Error: Please choose a category and subcategory\');\r\n      \r\n      $(\'.btn-primary-modal-action\').prop(\'disabled\',false);\r\n      return false;\r\n\r\n}'),
('338','83','item_page_columns_size','8-4'),
('339','83','item_page_details_columns','2'),
('340','83','item_page_hidden_fields','988,1053,1052,1049,1056,1065,1066'),
('341','83','item_page_comments_position','left_column'),
('342','83','javascript_in_item_page','var progressbar = document.querySelector(\".progress-bar-info\");\r\nvar textInsideProgress = progressbar.getElementsByTagName(\"span\")[0];\r\nprogressbar.style.width = Math.floor(100 * ([1032] / [1031])) + \"%\";\r\ntextInsideProgress.innerText = Math.floor(100 * ([1032] / [1031])) + \"%\";'),
('343','83','php_in_item_page',''),
('344','83','php_in_item_page_debug_mode','1'),
('345','83','menu_title','Milestones'),
('346','83','menu_icon','fa-star'),
('347','83','listing_heading','Milestones'),
('348','83','window_heading',''),
('349','83','window_width',''),
('350','83','insert_button','Add Milestone'),
('351','83','reports_hide_insert_button','1'),
('352','83','email_subject_new_item',''),
('353','83','email_subject_updated_item',''),
('354','83','disable_notification','0'),
('355','83','disable_internal_notification','0'),
('356','83','disable_highlight_unread','0'),
('357','83','use_comments','1'),
('358','83','display_comments_id','1'),
('359','83','display_last_comment_in_listing','1'),
('360','83','use_editor_in_comments','1'),
('361','83','disable_attachments_in_comments','1'),
('362','83','image_preview_in_comments','0'),
('363','83','email_subject_new_comment','New comment on Milestone:'),
('364','83','send_notification_to_assigned','1'),
('365','83','redirect_after_adding','subentity'),
('366','83','redirect_after_click_heading','subentity'),
('367','83','default_filter_panel_status','0'),
('370','57','window_width',''),
('371','57','image_preview_in_comments','0'),
('372','52','window_width',''),
('373','52','image_preview_in_comments','0'),
('374','84','javascript_in_from','/*******************************************************************************************************************************/\r\n/* VARIABLES */\r\n/*******************************************************************************************************************************/\r\n\r\nvar dropdown = $(\"#fields_1061\");\r\nvar freeform = $(\"#fields_1063\");\r\nvar choose_type = $(\"#fields_1064\");\r\nvar recurring_goal = $(\"#fields_1062\");\r\nvar type = $(\"#fields_1067\");\r\n\r\n\r\nvar div_dropdown = $(\".form-group-1061\");\r\nvar div_freeform = $(\".form-group-1063\");\r\nvar div_recurring_goal = $(\".form-group-1062\");\r\nvar div_type = $(\".form-group-1067\");\r\n\r\n\r\n\r\n\r\n/*******************************************************************************************************************************/\r\n/* EXECUTE */\r\n/*******************************************************************************************************************************/\r\n\r\ndiv_type.hide();\r\ndiv_recurring_goal.hide();\r\ndiv_dropdown.hide();\r\ndiv_freeform.hide();\r\n\r\nif (type.val() == \"Custom\") {\r\n    div_freeform.show();\r\n    div_dropdown.hide();\r\n}\r\nelse if (type.val() == \"Search\") {\r\n    div_freeform.hide();\r\n    div_dropdown.show();\r\n}\r\n\r\nchoose_type.change(function(){\r\n    if (choose_type.find(\"option:selected\").text() == \"Create custom recurring goal\") {\r\n        div_freeform.show();\r\n        div_dropdown.hide();\r\n        type.val(\"Custom\");\r\n        freeform.change(function(){\r\n            recurring_goal.val(freeform.val());\r\n        });\r\n    }\r\n    else {\r\n        div_freeform.hide();\r\n        div_dropdown.show();\r\n        type.val(\"Search\");\r\n        dropdown.change(function(){\r\n            recurring_goal.val(dropdown.find(\"option:selected\").text());\r\n        })\r\n    }\r\n\r\n});'),
('375','84','javascript_onsubmit',''),
('398','35','menu_title',''),
('399','35','menu_icon',''),
('400','35','listing_heading',''),
('401','35','window_heading',''),
('402','35','window_width',''),
('403','35','insert_button',''),
('404','35','reports_hide_insert_button','1'),
('405','35','email_subject_new_item',''),
('406','35','email_subject_updated_item',''),
('407','35','disable_notification','0'),
('408','35','disable_internal_notification','0'),
('409','35','disable_highlight_unread','0'),
('410','35','use_comments','0'),
('411','35','display_comments_id','1'),
('412','35','display_last_comment_in_listing','1'),
('413','35','use_editor_in_comments','1'),
('414','35','disable_attachments_in_comments','1'),
('415','35','image_preview_in_comments','0'),
('416','35','email_subject_new_comment',''),
('417','35','send_notification_to_assigned','0'),
('418','35','redirect_after_adding','subentity'),
('419','35','redirect_after_click_heading','subentity'),
('420','35','javascript_in_item_page','var iFrameElement = $(\'.form-group-1072\');\r\niFrameElement.find(\"th\").css( \"display\", \"none\" );\r\niFrameElement.find(\"td\").css( \"display\", \"block\" );\r\niFrameElement.find(\"td\").css( \"width\", \"250%\" );\r\n\r\n\r\n/* @media only screen and (min-width: 0px) and (max-width: 700px) {\r\n    td {\r\n        display:inline-block;\r\n        padding:5px;\r\n        width:100%;\r\n    }\r\n} */'),
('421','35','php_in_item_page',''),
('422','35','php_in_item_page_debug_mode','1'),
('423','35','item_page_subentity68_position',''),
('424','35','hide_subentity68_if_empty','0'),
('425','35','item_page_subentity68_heading',''),
('426','35','hide_subentity68_in_top_menu','0'),
('430','84','item_page_columns_size','8-4'),
('431','84','item_page_details_columns','2'),
('432','84','item_page_hidden_fields','1064,1063,1061,1067'),
('433','84','item_page_comments_position','left_column'),
('434','84','javascript_in_item_page',''),
('435','84','php_in_item_page',''),
('436','84','php_in_item_page_debug_mode','1');

CREATE TABLE IF NOT EXISTS `app_entities_menu` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `icon` varchar(64) NOT NULL,
  `entities_list` text NOT NULL,
  `reports_list` text NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entities_menu VALUES
('2','0','Communication','fa-comments','52,57','','0');

CREATE TABLE IF NOT EXISTS `app_entity_1` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int NOT NULL DEFAULT '0',
  `parent_item_id` int NOT NULL DEFAULT '0',
  `linked_id` int NOT NULL DEFAULT '0',
  `date_added` bigint NOT NULL DEFAULT '0',
  `date_updated` bigint NOT NULL DEFAULT '0',
  `created_by` int DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `password` varchar(255) NOT NULL,
  `is_email_verified` tinyint(1) NOT NULL DEFAULT '1',
  `field_5` tinyint(1) NOT NULL,
  `field_6` int NOT NULL,
  `field_7` varchar(255) NOT NULL,
  `field_8` varchar(255) NOT NULL,
  `field_9` varchar(255) NOT NULL,
  `field_10` varchar(255) NOT NULL,
  `field_12` varchar(255) NOT NULL,
  `field_13` varchar(64) NOT NULL,
  `field_14` varchar(64) NOT NULL,
  `field_201` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entity_1 VALUES
('1','0','0','0','1606144059','1609362280',NULL,'0','$P$E5HngMBOgG90rfxBDrtml1jZMMYSmH/','1','1','0','John','Robinson','jrobinson24@gmail.com','1609173605_WIN_20200506_14_54_00_Pro.jpg','admin','english.php','blue','1611099527');

CREATE TABLE IF NOT EXISTS `app_entity_1_values` (
  `id` int NOT NULL AUTO_INCREMENT,
  `items_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `value` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_21` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int DEFAULT '0',
  `parent_item_id` int DEFAULT '0',
  `linked_id` int DEFAULT '0',
  `date_added` bigint NOT NULL DEFAULT '0',
  `date_updated` bigint NOT NULL DEFAULT '0',
  `created_by` int DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_156` text NOT NULL,
  `field_157` text NOT NULL,
  `field_158` text NOT NULL,
  `field_159` bigint NOT NULL DEFAULT '0',
  `field_160` text NOT NULL,
  `field_161` text NOT NULL,
  `field_162` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_21_values` (
  `id` int NOT NULL AUTO_INCREMENT,
  `items_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `value` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_22` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int DEFAULT '0',
  `parent_item_id` int DEFAULT '0',
  `linked_id` int DEFAULT '0',
  `date_added` bigint NOT NULL DEFAULT '0',
  `date_updated` bigint NOT NULL DEFAULT '0',
  `created_by` int DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_167` text NOT NULL,
  `field_168` text NOT NULL,
  `field_169` text NOT NULL,
  `field_170` text NOT NULL,
  `field_171` text NOT NULL,
  `field_172` text NOT NULL,
  `field_173` varchar(64) NOT NULL,
  `field_174` varchar(64) NOT NULL,
  `field_175` bigint NOT NULL DEFAULT '0',
  `field_176` bigint NOT NULL DEFAULT '0',
  `field_177` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_22_values` (
  `id` int NOT NULL AUTO_INCREMENT,
  `items_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `value` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_23` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int DEFAULT '0',
  `parent_item_id` int DEFAULT '0',
  `linked_id` int DEFAULT '0',
  `date_added` bigint NOT NULL DEFAULT '0',
  `date_updated` bigint NOT NULL DEFAULT '0',
  `created_by` int DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_182` text NOT NULL,
  `field_183` text NOT NULL,
  `field_184` text NOT NULL,
  `field_185` text NOT NULL,
  `field_186` text NOT NULL,
  `field_194` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_23_values` (
  `id` int NOT NULL AUTO_INCREMENT,
  `items_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `value` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_24` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int DEFAULT '0',
  `parent_item_id` int DEFAULT '0',
  `linked_id` int DEFAULT '0',
  `date_added` bigint NOT NULL DEFAULT '0',
  `date_updated` bigint NOT NULL DEFAULT '0',
  `created_by` int DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_191` text NOT NULL,
  `field_192` text NOT NULL,
  `field_193` text NOT NULL,
  `field_195` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_24_values` (
  `id` int NOT NULL AUTO_INCREMENT,
  `items_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `value` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_29` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_29_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_30` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_30_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_31` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_31_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_32` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_281` int NOT NULL,
  `field_282` varchar(255) NOT NULL,
  `field_283` int NOT NULL,
  `field_284` int NOT NULL,
  `field_285` text NOT NULL,
  `field_286` text NOT NULL,
  `field_287` varchar(64) NOT NULL,
  `field_288` varchar(64) NOT NULL,
  `field_289` bigint NOT NULL,
  `field_290` bigint NOT NULL,
  `field_291` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_field_281` (`field_281`),
  KEY `idx_field_283` (`field_283`),
  KEY `idx_field_284` (`field_284`),
  KEY `idx_field_285` (`field_285`(128))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_32_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_35` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_320` varchar(255) NOT NULL,
  `field_338` text NOT NULL,
  `field_1068` int NOT NULL,
  `field_1070` varchar(255) NOT NULL,
  `field_1071` text NOT NULL,
  `field_1072` text NOT NULL,
  `field_1073` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_field_1068` (`field_1068`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entity_35 VALUES
('13','0','0','0','1611082111','1611082645','43','0','YoungLife Website','Welcome to YoungLife! This resource is a link to our website where on it, you can learn more about our organization, etc.','547','https://www.younglife.org/ForEveryKid/YoungLives/Pages/default.aspx','1611082108_Young_Life_Logo.jpg','https://www.younglife.org/ForEveryKid/YoungLives/Pages/default.aspx',''),
('14','0','0','0','1611082793','1611088847','43','0','Fort Carson Military Camp','The Fort Carson Military Camp is at May 2021. Apply now for early bird discount!','545','https://www.younglife.org/Events/Pages/Military/FortCarsonFamilyCampAtTrailWest.aspx','1611088846_rmarkdown.pdf','https://www.younglife.org/Events/Pages/Military/FortCarsonFamilyCampAtTrailWest.aspx',''),
('15','0','0','0','1611082833','0','43','0','Saranac 50th Celebration','Saranac 50th Celebration. Sign up!','545','https://www.younglife.org/Events/Pages/Saranac-50th-Celebration.aspx','','https://www.younglife.org/Events/Pages/Saranac-50th-Celebration.aspx',''),
('17','0','0','0','1611088989','0','43','0','Lambent Data Webpage','Lambent Data\'s Website. Learn more about us!','550','https://www.lambentdata.com/','','https://www.lambentdata.com/','');

CREATE TABLE IF NOT EXISTS `app_entity_35_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entity_35_values VALUES
('9','13','1068','547'),
('11','15','1068','545'),
('13','14','1068','545'),
('14','17','1068','550');

CREATE TABLE IF NOT EXISTS `app_entity_37` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_349` varchar(255) NOT NULL,
  `field_350` text NOT NULL,
  `field_394` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_field_350` (`field_350`(128)),
  KEY `idx_field_394` (`field_394`(128))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_37_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_46` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_465` bigint NOT NULL,
  `field_466` bigint NOT NULL,
  `field_467` text NOT NULL,
  `field_471` text NOT NULL,
  `field_472` text NOT NULL,
  `field_473` text NOT NULL,
  `field_474` text NOT NULL,
  `field_475` varchar(255) NOT NULL,
  `field_479` text NOT NULL,
  `field_482` int NOT NULL,
  `field_486` varchar(8) NOT NULL,
  `field_489` varchar(255) NOT NULL,
  `field_499` varchar(255) NOT NULL,
  `field_500` varchar(255) NOT NULL,
  `field_510` int NOT NULL,
  `field_520` int NOT NULL,
  `field_523` int NOT NULL,
  `field_524` int NOT NULL,
  `field_525` int NOT NULL,
  `field_527` int NOT NULL,
  `field_539` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_field_482` (`field_482`),
  KEY `idx_field_510` (`field_510`),
  KEY `idx_field_520` (`field_520`),
  KEY `idx_field_523` (`field_523`),
  KEY `idx_field_524` (`field_524`),
  KEY `idx_field_525` (`field_525`),
  KEY `idx_field_527` (`field_527`),
  KEY `idx_field_539` (`field_539`(128))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_46_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=176 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_49` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_509` varchar(255) NOT NULL,
  `field_528` varchar(8) NOT NULL,
  `field_540` text NOT NULL,
  `field_541` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_field_540` (`field_540`(128))
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_49_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_50` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_517` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_50_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_52` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_550` text NOT NULL,
  `field_551` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_field_551` (`field_551`(128))
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_52_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_57` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_592` text NOT NULL,
  `field_593` text NOT NULL,
  `field_594` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_field_593` (`field_593`(128))
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_57_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_entity_83` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_995` bigint NOT NULL,
  `field_996` bigint NOT NULL,
  `field_997` text NOT NULL,
  `field_998` text NOT NULL,
  `field_999` text NOT NULL,
  `field_1000` text NOT NULL,
  `field_1001` text NOT NULL,
  `field_1002` varchar(255) NOT NULL,
  `field_1003` text NOT NULL,
  `field_1004` varchar(8) NOT NULL,
  `field_1005` varchar(255) NOT NULL,
  `field_1006` varchar(255) NOT NULL,
  `field_1007` varchar(255) NOT NULL,
  `field_1008` int NOT NULL,
  `field_1013` text NOT NULL,
  `field_1017` varchar(1) NOT NULL,
  `field_1018` varchar(1) NOT NULL,
  `field_1019` varchar(1) NOT NULL,
  `field_1022` text NOT NULL,
  `field_1029` varchar(255) NOT NULL,
  `field_1030` varchar(1) NOT NULL,
  `field_1031` varchar(1) NOT NULL,
  `field_1032` varchar(1) NOT NULL,
  `field_1033` varchar(1) NOT NULL,
  `field_1041` varchar(1) NOT NULL,
  `field_1049` varchar(1) NOT NULL,
  `field_1052` varchar(255) NOT NULL,
  `field_1053` varchar(255) NOT NULL,
  `field_1054` int NOT NULL,
  `field_1056` varchar(255) NOT NULL,
  `field_1065` varchar(255) NOT NULL,
  `field_1066` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_field_1008` (`field_1008`),
  KEY `idx_field_1022` (`field_1022`(128)),
  KEY `idx_field_1029` (`field_1029`),
  KEY `idx_field_1013` (`field_1013`(128)),
  KEY `idx_field_1052` (`field_1052`),
  KEY `idx_field_1053` (`field_1053`),
  KEY `idx_field_1054` (`field_1054`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entity_83 VALUES
('5','0','0','0','1610588663','1611115725','39','0','1610600400','1610686800','Study','','','','','Graduate High School','*Get a degree\nGPA 3.0','false','1610645370_637272112976170000.jpeg','','','103','','','','','','336,344,348','','','','','','','336,344,348,372','336,344,348,374','0','Dropdown','',''),
('12','0','0','0','1610647241','1611007937','39','0','0','0','Do practice\r\nMemorize vocab','','','','','Prepare for the SAT','*Take a timed test\n*Sign up for tutoring\n*Visit Collegeboard','false','','Don\'t understand material','Mastery','104','39','','','','','336,344,347','','','','','','','336,344,347,375','336,344,347,377','0','Dropdown','',''),
('14','0','0','0','1610652384','1610729174','39','0','0','0','Do practice\r\nMemorize vocab','','','','','Prepare for the SAT','*Take a timed test\nSign up for tutoring\nVisit Collegeboard','false','','','','103','39','','','','','336,344,347','','','','','','','336,344,347,375','336,344,347,377','0','Dropdown','',''),
('16','0','0','0','1610660889','0','43','0','0','0','Meditate\r\nListen to Music','','','','','Mental Health Goals','*Visit psychiatrist','false','','','','104','43','','','','','337,349','','','','','','','','','0','','',''),
('18','0','0','0','1610731860','1610731876','43','0','0','0','','','','','','Health Milestone','','false','','','','104','43','','','','','337,349','','','','','','','337,349','337,349','0','','',''),
('19','0','0','0','1610734226','0','39','0','0','0','Plan 5 healthy recipes to cook this week\r\nWalk/Exercise for 30 minutes\r\nMake weekly shopping list for healthy meals\r\nDrink less alcohol\r\nGo grocery shopping\r\nSleep at least 6 hours total tonight\r\nLook up new healthy recipe\r\nDo monthly weigh-in\r\nTake prescribed medication in AM\r\nTake prescribed medication in PM\r\nDrink 6 glasses of water\r\nEat 6 servings of fruits/vegetables\r\nWrite in my gratitude journal\r\nMeditate/Do deep breathing\r\nCheck blood sugar levels according to doctor\r\nCheck feet daily','','','','','HbA1c','*Ask family or friend(s) to support healthy food choices\nSign up for nutrition plan\nSign up for exercise plan\n*Research places to buy discounted fruits and vegetables\n*Talk with family or friend(s) about diabetes\nAttend diabetes support group\nSchedule an eye exam','false','','___%','____%','104','39','','','','','337,378,379','','','','','','','337,378,379','337,378,379','0','Freeform','',''),
('20','0','0','0','1610748279','1610748427','45','0','1610686800','1611896400','Write in Gratitude Journal\r\nMeditate/Do deep breathing for at least 60 seconds\r\nPray\r\nTake a break from social media\r\nTake prescribed mental health medication\r\nGo to one-on-one therapy sessions\r\nGo to family/couples therapy sessions\r\nRead the Bible\r\nGo for a walk\r\nParticipate in faith congregation services\r\nListen to inspiring music\r\n','','','','','Peace Level','*Find a therapist or psychiatrist covered by health insurance\n*Ask family or friend(s) to support mental health choices\n','false','','','','104','45','','','','','337,349,393','','','','','','','337,349,393','337,349,393','0','None','',''),
('21','0','0','0','1610749944','0','42','0','0','0','Do study session with friend\r\nComplete homework assignments\r\nReview homework requirements\r\nMak flashcards for test\r\nPractice using computer\r\nRead for fun for 30 minutes\r\nAttend after-school tutoring with my teacher\r\nGo to the school library to do homework','','','','','High school diploma','Talk with guidance counselor\r\nSet up a quiet place in my home to study and do homework\r\nFind a study group\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nExplore ways to learn STEM(Science, Tech, Engin, Math)','false','','','','104','42','','','','','336,399,401','','','','','','','336,399,401,403','336,399,401,404','0','Dropdown','',''),
('22','0','0','0','1610750433','1610751337','44','0','0','0','Sleep for eat least 6 hours total tonight\r\nTake prescribed medication in AM\r\nDo monthly weigh-in\r\nTake prescribed medication in PM\r\nEat 6 servings of fruits/vegetables\r\nAttend hypertension support group\r\nWrite in my Gratitude Journal\r\nMeditate/Do deep breathing\r\nTake a break from social media\r\nTrack whether foot/toe pain wakes me\r\nTrack whether foot/toe pain wakes me\r\nCheck blood pressure level according to doctor\r\nTake aspirin as recommended by doctor','','','','','lood Pressure','Ask family or friend(s) to support healthy food choices\r\nSign up for nutrition plan\r\nSign up for exercise plan\r\nLook up new healthy recipe\r\nSchedule an eye exam\r\nGo to eye exam\r\nTalk with family or friend(s) about having hypertension','false','','___mmHg','___mmHg','104','44','','','','','337,378,388','','','','','','','337,378,388','337,378,388','0','Freeform','',''),
('23','0','0','0','1610751187','1610751994','45','0','1610686800','0','Check blood pressure level according to doctor\r\nTake aspirin as recommended by doctor','','','','','Blood pressure 22','Go to eye exam\n*Talk with family or friend(s) about having hypertension','false','','22mmHg','3333mmHg','103','45','','','','','337,378,388','','','','','','','337,378,388','337,378,388','0','Freeform','',''),
('24','0','0','0','1610766559','1610767398','45','0','1610686800','1612501200','Work on application materials for community college\r\nDo homework\r\n','','','','','Associate\'s Degree','Talk with guidance counselor at school about applying to community college\nResearch community college\nApply for community college\n*Apply for financial aid and scholarships\n*Enroll at community college\n*Track degree progress and credit requirements\n*Talk with course advisor at community college\nFind a study group\n*Order study materials online\n*Create flashcards\nCheck ways to learn STEM (Science, Tech, Engin, Math) in community college\nMake a plan for doing daily homework\nMake a plan for doing longer projects\n\n','false','1610766558_providercorner.jpg','','','104','45','','','','','336,399,412','','','','','','','336,399,412,413','336,399,412,417','0','Dropdown','',''),
('25','0','0','0','1610767540','1610917122','45','0','1610686800','1612501200','Work on application materials for community college\r\nDo homework\r\n','great vision and purpose','great vision and purpose','great vision and purpose','great vision and purpose','Associate\'s Degree','*Talk with guidance counselor at school about applying to community college\r\n*Research community college\r\n*Apply for community college\r\n*Apply for financial aid and scholarships\r\n*Enroll at community college\r\n*Track degree progress and credit requirements\r\nTalk with course advisor at community college\r\nFind a study group\r\n*Order study materials online\r\n*Create flashcards\r\nCheck ways to learn STEM (Science, Tech, Engin, \r\n\r\n','false','1610767540_providercorner.jpg','','','103','45','','','','','336,399,412','','','','','','','336,399,412,416','336,399,412,417','0','Dropdown','',''),
('26','0','0','0','1610824235','1610825394','45','0','1610773200','1611982800','Schedule annual physical\r\nHave annual physical\r\nSchedule dentist visit\r\nGo to dentist\r\nEnroll in a stop smoking program\r\n\r\n','','','','','Preventative care for this calendar year','*drink water','false','1610824235_10153011_10202560521068911_5827645421926777321_n.jpg','','','104','45','','','','','337,378,386','','','','','','','337,378,386','337,378,386','0','None','',''),
('27','0','0','0','1610855857','0','45','0','1610773200','1611982800','Trying to get better vision by eating carrots','','','','','Getting 20/20 vision','Goto eye doctor ','false','','Blind','2020 vision','104','45','','','','','337,349,392','','','','','','','337,349,392','337,349,392','0','','',''),
('28','0','0','0','1610856350','0','45','0','1610773200','1611982800','Do study session with friend\r\nComplete homework assignments\r\nReview homework requirements\r\nMak flashcards for test\r\nPractice using computer\r\n','','','','','I want to get MBA','Talk with guidance counselor\r\nSet up a quiet place in my home to study and do homework\r\nFind a study group\r\nExplore ways to learn STEM(Science, Tech, Engin, Math)','false','','','','104','45','','','','','336,399,400','','','','','','','336,399,400','336,399,400','0','Dropdown','',''),
('29','0','0','0','1610856917','0','45','0','1610773200','1611982800','Plan 5 healthy recipes to cook this week\r\nWalk/Exercise for 30 minutes\r\nDrink less alcohol\r\nLook up new healthy recipe\r\nSleep at least 6 hours total tonight\r\nDo monthly weigh-in\r\nTake prescribed medication in AM\r\nTake prescribed medication in PM\r\nEat 6 servings of fruits/vegetables\r\nWrite in my Gratitude Journal\r\nMeditate/Do deep breathing\r\nTake a break from social media\r\nDrink water instead of soda or juice\r\nEat 3 meals a day','','','','','Reach target weight level','Go to weight coach ','false','','230___lbs','205___lbs','104','45','','','','','337,378,389','','','','','','','337,378,389','337,378,389','0','Freeform','',''),
('30','0','0','0','1610858148','0','45','0','1611032400','1625198400','Work on application materials for graduate program\r\nDo homework\r\nDo study session with friend\r\nMake flashcards for test','','','','','Postgraduate degree','Talk with academic advisor at school about applying to graduate programs\r\nResearch graduate programs (including children-friendly ones)\r\nTake the GRE/other entrance exams(s)\r\nAsk for references\r\nApply for colleges/universities\r\nApply for financial aid and scholarships\r\nEnroll at college/university\r\nTrack degree programs and credit requirements\r\nTalk witth academic advisor in grad program\r\nFind a study group\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects','false','1610858147_47EE25BF-C42D-4E09-B2EF-0734144535F4.jpeg','','','104','45','','','','','336,399,446','','','','','','','336,399,446,451','336,399,446,454','0','Dropdown','',''),
('31','0','0','0','1610858320','0','45','0','1610773200','1611896400','Plan 5 healthy recipes to cook this week\r\nWalk/Exercise for 30 minutes\r\nReduce alcohol intake\r\nSleep at least 6 hour total tonight\r\nLook up new healthy recipe\r\nTake prescribed medication in AM\r\nDo monthly weigh-in\r\nTake prescribed medication in PM\r\nEat 6 servings of fruits/vegetables\r\nWrite in my Gratitude Journal\r\nAttend diabetes support group\r\nMeditate/Do deep breathing\r\nCheck blood sugar levels according to doctor\r\nCheck feet daily','','','','','Reach target blood sugar level','Ask family or friend(s) to support healthy food choices\r\nSign up for nutrition plan\r\nSign up for exercise plan\r\nTalk with family or friends about diabetes\r\nSchedule an eye exam\r\nGo to eye exam','false','','100 mg/dL','200___mg/dL','104','45','','','','','337,378,387','','','','','','','337,378,387','337,378,387','0','Freeform','',''),
('34','0','0','0','1610908123','0','44','0','0','0','Plan 5 healthy recipes to cook this week\r\nWalk/Exercise for 30 minutes\r\nReduce alcohol intake\r\nSleep at least 6 hour total tonight\r\nLook up new healthy recipe\r\nTake prescribed medication in AM\r\nDo monthly weigh-in\r\nTake prescribed medication in PM\r\nEat 6 servings of fruits/vegetables\r\nWrite in my Gratitude Journal\r\nAttend diabetes support group\r\nMeditate/Do deep breathing\r\nCheck blood sugar levels according to doctor\r\nCheck feet daily','','','','','Reach target blood sugar level','Ask family or friend(s) to support healthy food choices\nSign up for nutrition plan\nSign up for exercise plan\nTalk with family or friends about diabetes\n*Schedule an eye exam\n*Go to eye exam','false','','___mg/dL','___mg/dL','104','44','','','','','337,378,387','','','','','','','337,378,387','337,378,387','0','Freeform','',''),
('36','0','0','0','1610908921','0','44','0','0','0','Do study session with friend\r\nComplete homework assignments\r\nReview homework requirements\r\nMak flashcards for test\r\nPractice using computer\r\nRead for fun for 30 minutes\r\nAttend after-school tutoring with my teacher\r\nGo to the school library to do homework','','','','','High school diploma','Talk with guidance counselor\r\nSet up a quiet place in my home to study and do homework\r\nFind a study group\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nExplore ways to learn STEM(Science, Tech, Engin, Math)','false','','','','104','44','','','','','336,399,401','','','','','','','336,399,401,403','336,399,401,404','0','Dropdown','',''),
('37','0','0','0','1610908955','0','44','0','0','0','Do study session with friend\r\nComplete homework assignments\r\nReview homework requirements\r\nMak flashcards for test\r\nPractice using computer\r\nRead for fun for 30 minutes\r\nAttend after-school tutoring with my teacher\r\nGo to the school library to do homework','','','','','High school diploma','Talk with guidance counselor\r\nSet up a quiet place in my home to study and do homework\r\nFind a study group\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nExplore ways to learn STEM(Science, Tech, Engin, Math)','false','','','','104','44','','','','','336,399,401','','','','','','','336,399,401,403','336,399,401,404','0','Dropdown','',''),
('38','0','0','0','1610908978','0','44','0','0','0','Do study session with friend\r\nComplete homework assignments\r\nReview homework requirements\r\nMak flashcards for test\r\nPractice using computer\r\nRead for fun for 30 minutes\r\nAttend after-school tutoring with my teacher\r\nGo to the school library to do homework','','','','','High school diploma','Talk with guidance counselor\r\nSet up a quiet place in my home to study and do homework\r\nFind a study group\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nExplore ways to learn STEM(Science, Tech, Engin, Math)','false','','','','104','44','','','','','336,399,401','','','','','','','336,399,401,403','336,399,401,404','0','Dropdown','',''),
('39','0','0','0','1610908994','0','44','0','0','0','Do study session with friend\r\nStudy for GED exam for 1 hour\r\nPractice using computer\r\nRead for fun for 30 minutes\r\nMake flashcards for test','','','','','GED','Research requirements for GED\r\nFind online prep course\r\nOrder study materials online\r\nMake a plan for studying for GED\r\nTake a practice GED exam\r\nReview completed practice exam\r\nCheck exam locations\r\nRegister for GED exam\r\nPrepare proper identification for exam\r\nCheckout a GED prep book from the library\r\nSet a budget for prep courses and the test','false','','','','104','44','','','','','336,399,408','','','','','','','336,399,408,410','336,399,408,411','0','Dropdown','',''),
('41','0','0','0','1610909159','0','44','0','0','0','Work on application materials for community college\r\nDo homework\r\nDo study session with friend\r\nWork on application essay','','','','','Associate\'s degree','Talk with guidance counselor at school about applying to community college\r\nResearch community college\r\nApply for community college\r\nApply for financial aid and scholarships\r\nEnroll at community college\r\nTrack degree progress and credit requirements\r\nTalk with course advisor at community college\r\nFind a study group\r\nOrder study materials online\r\nCreate flashcards\r\nCheck ways to learn STEM (Science, Tech, Engin, Math) in community college\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nAsk teacher or mentor for recommendation letter\r\nResearch fields and programs\r\nRequest copies of GED/high school transcript\r\nAsk guidance counselor for application fee waivers','false','','','','104','44','','','','','336,399,412','','','','','','','336,399,412,414','336,399,412,417','0','Dropdown','',''),
('42','0','0','0','1610909257','0','44','0','0','0','Do study session with friend\r\nStudy for GED exam for 1 hour\r\nPractice using computer\r\nRead for fun for 30 minutes\r\nMake flashcards for test','','','','','GED','Research requirements for GED\r\nFind online prep course\r\nOrder study materials online\r\nMake a plan for studying for GED\r\nTake a practice GED exam\r\nReview completed practice exam\r\nCheck exam locations\r\nRegister for GED exam\r\nPrepare proper identification for exam\r\nCheckout a GED prep book from the library\r\nSet a budget for prep courses and the test','false','','','','104','44','','','','','336,399,408','','','','','','','336,399,408,410','336,399,408,411','0','Dropdown','',''),
('43','0','0','0','1610909362','0','44','0','0','0','Work on application materials for community college\r\nDo homework\r\nDo study session with friend\r\nWork on application essay','','','','','Associate\'s degree','Talk with guidance counselor at school about applying to community college\r\nResearch community college\r\nApply for community college\r\nApply for financial aid and scholarships\r\nEnroll at community college\r\nTrack degree progress and credit requirements\r\nTalk with course advisor at community college\r\nFind a study group\r\nOrder study materials online\r\nCreate flashcards\r\nCheck ways to learn STEM (Science, Tech, Engin, Math) in community college\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nAsk teacher or mentor for recommendation letter\r\nResearch fields and programs\r\nRequest copies of GED/high school transcript\r\nAsk guidance counselor for application fee waivers','false','','','','104','44','','','','','336,399,412','','','','','','','336,399,412,414','336,399,412,417','0','Dropdown','',''),
('44','0','0','0','1610909564','0','44','0','0','0','Work on application materials for college/university\r\nDo homework\r\nDo study session with friend\r\nResearch internships\r\nWork on application essays\r\nAsk guidance counselor to review and edit application essay\r\nWork on scholarship application materials/Apply for scholarships\r\nStudy for SAT\r\nStudy for ACT\r\nMake flashcards for test','','','','','Bachelor\'s degree','Talk with guidance counselor at school about applying to college/university\r\nResearch colleges/universities (including children-friendly ones)\r\nApply for colleges/university\r\nApply for financial aid and scholarships\r\nEnroll att college/university\r\nTrack degree progress and credit requirements\r\nTalk with academic advisor at college/university\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nFind a study group\r\nOrder study materials online\r\nApply for internships\r\nGo to tutoring sessions\r\nCheck ways to learn STEM (Science, Tech, Engin, Math) in college/university','false','','','','104','44','','','','','336,399,419','','','','','','','336,399,419,422','336,399,419,424','0','Dropdown','',''),
('45','0','0','0','1610909651','0','44','0','0','0','Think about elements involved with military active-duty and reserves\r\nTalk with family and friends about military\r\nWork on application materials for military','','','','','Military with related training','Talk with guidance counselor at school about military\r\nResearch programs in military\r\nApply for military\r\nCheck ways to learn STEM (Science, Tech, Engin, Math) in military\r\nResearch commitments before enlisting\r\nEnlist in military active-duty\r\nEnlist in military reserves\r\nKnow schedule for first three months before enlisting','false','','','','104','44','','','','','336,399,428','','','','','','','336,399,428,431','336,399,428,434','0','Dropdown','',''),
('46','0','0','0','1610909801','0','44','0','0','0','Work on application materials for trade/technical/vocational training\r\nDo study session with friend\r\nDo homework\r\nPractice technical skills','','','','','Trade/technical/vocational training','Talk with guidance counselor at school about trade/technical/vocational training\r\nStudy for trade school entrance exam\r\nApply for financial aid and scholarships\r\nApply for financial aid and scholarships\r\nApply for apprenticeships\r\nJoin a study group\r\nCheck ways to learn STEM (Science, Tech, Engin, Math) in trade/technical/vocational training\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projectts\r\nResearch vocational schools in the area\r\nResearch childcare options','false','','','','104','44','','','','','336,399,438','','','','','','','336,399,438,441','336,399,438,445','0','Dropdown','',''),
('47','0','0','0','1610909997','0','44','0','0','0','Work on application materials for graduate program\r\nDo homework\r\nDo study session with friend\r\nMake flashcards for test','','','','','Postgraduate degree','Talk with academic advisor at school about applying to graduate programs\r\nResearch graduate programs (including children-friendly ones)\r\nTake the GRE/other entrance exams(s)\r\nAsk for references\r\nApply for colleges/universities\r\nApply for financial aid and scholarships\r\nEnroll at college/university\r\nTrack degree programs and credit requirements\r\nTalk witth academic advisor in grad program\r\nFind a study group\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects','false','','','','104','44','','','','','336,399,446','','','','','','','336,399,446,451','336,399,446,454','0','Dropdown','',''),
('48','0','0','0','1610918038','0','45','0','0','0','Write in Gratitude Journal\r\nMeditate/Do deep breathing for at least 60 seconds\r\nPray\r\nTake a break from social media\r\nTake prescribed mental health medication\r\nGo to one-on-one therapy sessions\r\nGo to family/couples therapy sessions\r\nRead the Bible\r\nGo for a walk\r\nParticipate in faith congregation services\r\nListen to inspiring music\r\nListen to worship music\r\nRead a chapter of a book by my favorite author','','','','','Reach target peace level','Find a therapist or psychiatrist covered by health insurance\r\nAsk family or friend(s) to support mental health choices\r\nSet screen time limit on phone for social media\r\nAttend group support meetings\r\nTalk with a friend or family member about challenges and/or joys\r\nPractice handling stressful situation (such as an upcoming difficult conversation)','false','','','','104','45','','','','','337,349,393','','','','','','','337,349,393','337,349,393','0','None','',''),
('49','0','0','0','1610919006','0','45','0','1611032400','1611118800','Work on application materials for college/university\r\nDo homework\r\nDo study session with friend\r\nResearch internships\r\nWork on application essays\r\nAsk guidance counselor to review and edit application essay\r\nWork on scholarship application materials/Apply for scholarships\r\nStudy for SAT\r\nStudy for ACT\r\nMake flashcards for test','','','','','Bachelor\'s degree','Talk with guidance counselor at school about applying to college/university\r\nResearch colleges/universities (including children-friendly ones)\r\nApply for colleges/university\r\nApply for financial aid and scholarships\r\nEnroll att college/university\r\nTrack degree progress and credit requirements\r\nTalk with academic advisor at college/university\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nFind a study group\r\nOrder study materials online\r\nApply for internships\r\nGo to tutoring sessions\r\nCheck ways to learn STEM (Science, Tech, Engin, Math) in college/university','false','','___lbs','___lbs','104','45','','','','','336,399,419','','','','','','','336,399,419,422','336,399,419,424','0','Dropdown','',''),
('50','0','0','0','1610984625','1610987625','43','0','0','0','Work on application materials for college/university\r\nDo homework\r\nDo study session with friend\r\nResearch internships\r\nWork on application essays\r\nAsk guidance counselor to review and edit application essay\r\nWork on scholarship application materials/Apply for scholarships\r\nStudy for SAT\r\nStudy for ACT\r\nMake flashcards for test','','','','','Bachelor\'s degree','Talk with guidance counselor at school about applying to college/university\r\nResearch colleges/universities (including children-friendly ones)\r\nApply for colleges/university\r\nApply for financial aid and scholarships\r\nEnroll att college/university\r\nTrack degree progress and credit requirements\r\nTalk with academic advisor at college/university\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nFind a study group\r\nOrder study materials online\r\nApply for internships\r\nGo to tutoring sessions\r\nCheck ways to learn STEM (Science, Tech, Engin, Math) in college/university','false','','','','103','43','','','','','336,399,419','','','','','','','336,399,419,422','336,399,419,424','0','Dropdown','',''),
('52','0','0','0','1610984734','0','44','0','0','0','Ask friends or family about job openings\r\nSearch online for jobs\r\nCheck the newspaper for jbs\r\nSubmit an application to 2 job openings\r\nReflect, talk to friends and family\r\nPrepare for job interview','','','','','Close to child/ren\'s school/s','Update resume\r\nUpdate cover letter\r\nPrepare 5 job interview questions\r\nAsk friend, family, or mentor to look over the resume and cover letter before sending it out\r\nUpload resume and cover letter to job-finding sites','false','','','','104','44','','','','','339,360,396','','','','','','','339,360,396','339,360,396','0','None','',''),
('53','0','0','0','1610985083','0','44','0','0','0','Ask friends or family about job openings\r\nSearch online for jobs\r\nCheck the newspaper for jbs\r\nSubmit an application to 2 job openings\r\nReflect, talk to friends and family\r\nPrepare for job interview','','','','','Close to home','Update resume\r\nUpdate cover letter\r\nPrepare 5 job interview questions\r\nAsk friend, family, or mentor to look over the resume and cover letter before sending it out\r\nUpload resume and cover letter to job-finding sites','false','','','','104','44','','','','','339,360,361','','','','','','','339,360,361','339,360,361','0','None','',''),
('54','0','0','0','1610985134','1610987207','47','0','0','0','Ask friends or family about job openings\r\nSearch online for jobs\r\nCheck the newspaper for jbs\r\nSubmit an application to 2 job openings\r\nReflect, talk to friends and family\r\nPrepare for job interview','','','','','Close to home','Update resume\r\nUpdate cover letter\r\nPrepare 5 job interview questions\r\nAsk friend, family, or mentor to look over the resume and cover letter before sending it out\r\nUpload resume and cover letter to job-finding sites','false','','','','103','47','','','','','339,360,361','','','','','','','339,360,361','339,360,361','0','None','',''),
('55','0','0','0','1610985151','0','44','0','0','0','Ask friends or family about job openings\r\nSearch online for jobs\r\nCheck the newspaper for jbs\r\nSubmit an application to 2 job openings\r\nReflect, talk to friends and family\r\nPrepare for job interview','','','','','Easy Commute','Get a MetroCard, bus pass, transit pass, etc\r\nUpdate resume\r\nUpdate cover letter\r\nPrepare 5 job interview questions\r\nAsk friend, family, or mentor to look over the resume and cover letter before sending it out\r\nUpload resume and cover letter to job-finding sites','false','','','','104','44','','','','','339,360,398','','','','','','','339,360,398','339,360,398','0','None','',''),
('56','0','0','0','1611004709','0','45','0','1610946000','1612587600','Do study session with friend\r\nStudy for GED exam for 1 hour\r\nPractice using computer\r\nRead for fun for 30 minutes\r\nMake flashcards for test','','','','','GED','*Research requirements for GED\nFind online prep course\n*Order study materials online\nMake a plan for studying for GED\nTake a practice GED exam\nReview completed practice exam\nCheck exam locations\nRegister for GED exam\nPrepare proper identification for exam\nCheckout a GED prep book from the library\nSet a budget for prep courses and the test','false','','','','104','45','','','','','336,399,408','','','','','','','336,399,408,410','336,399,408,411','0','Dropdown','',''),
('58','0','0','0','1611008804','0','39','0','0','0','Plan 5 healthy recipes\r\nWalk/Exercise for 30 minutes\r\nDrink less alcohol\r\nSleep for eat least 6 hours total tonight\r\nTake prescribed medication in AM\r\nDo monthly weigh-in\r\nTake prescribed medication in PM\r\nEat 6 servings of fruits/vegetables\r\nAttend hypertension support group\r\nWrite in my Gratitude Journal\r\nMeditate/Do deep breathing\r\nTake a break from social media\r\nTrack whether foot/toe pain wakes me\r\nCheck blood pressure level according to doctor\r\nTake aspirin as recommended by doctor','','','','','Reach target blood pressure level','Ask family or friend(s) to support healthy food choices\r\nSign up for nutrition plan\r\nSign up for exercise plan\r\nLook up new healthy recipe\r\nSchedule an eye exam\r\nGo to eye exam\r\nTalk with family or friend(s) about having hypertension','false','','___mmHg','___mmHg','104','39','','','','','337,378,388','','','','','','','337,378,388','337,378,388','0','Freeform','Health','Main'),
('59','0','0','0','1611009133','0','39','0','0','0','','','','','','Faith','','false','','','','104','39','','','','','338,512,514','','','','','','','338,512,514','338,512,514','0','','Housing','Emergency Shelter'),
('60','0','0','0','1611011909','1611019594','44','0','1610514000','1611118800','Use online scheduling tool (such as Google calender) to manage workload\r\nWalk/exercise for 30 minutes\r\nSpend some time with friends\r\nStudy when baby is napping','','','','','Healthy school-rest-of-life balance','Take with guidance counselor at school\r\nDiscuss school-rest-of-life balance with family and friends\r\nAsk friend or family to babysit one a week so I can study','false','','','','104','44','','','','','336,490,468','','','','','','','336,490,468','336,490,468','0','Dropdown','Education','Enjoyment'),
('61','0','0','0','1611012020','0','44','0','0','0','Reflect on the class: talk to a friend, fellow students, or a family member\r\nWrite in my gratitude journal','','','','','I like going to class','Talk with guidance counselor at school','false','','no','yes','104','44','','','','','336,490,469','','','','','','','336,490,469','336,490,469','0','','Education','Enjoyment'),
('62','0','0','0','1611065119','0','45','0','1611032400','1612587600','Work on application materials for college/university\r\nDo homework\r\nDo study session with friend\r\nResearch internships\r\nWork on application essays\r\nAsk guidance counselor to review and edit application essay\r\nWork on scholarship application materials/Apply for scholarships\r\nStudy for SAT\r\nStudy for ACT\r\nMake flashcards for test','','','','','Bachelor\'s degree','Talk with guidance counselor at school about applying to college/university\r\nResearch colleges/universities (including children-friendly ones)\r\nApply for colleges/university\r\nApply for financial aid and scholarships\r\nEnroll att college/university\r\nTrack degree progress and credit requirements\r\nTalk with academic advisor at college/university\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nFind a study group\r\nOrder study materials online\r\nApply for internships\r\nGo to tutoring sessions\r\nCheck ways to learn STEM (Science, Tech, Engin, Math) in college/university','false','','','','104','45','','','','','336,399,419','','','','','','','336,399,419,422','336,399,419,424','0','Dropdown','Education','Education Level'),
('63','0','0','0','1611072486','0','43','0','0','0','Write in Gratitude Journal\r\nMeditate/Do deep breathing for at least 60 seconds\r\nPray\r\nTake a break from social media\r\nTake prescribed mental health medication\r\nGo to one-on-one therapy sessions\r\nGo to family/couples therapy sessions\r\nRead the Bible\r\nGo for a walk\r\nParticipate in faith congregation services\r\nListen to inspiring music\r\nListen to worship music\r\nRead a chapter of a book by my favorite author','','','','','Reach target peace level','Find a therapist or psychiatrist covered by health insurance\r\nAsk family or friend(s) to support mental health choices\r\nSet screen time limit on phone for social media\r\nAttend group support meetings\r\nTalk with a friend or family member about challenges and/or joys\r\nPractice handling stressful situation (such as an upcoming difficult conversation)','false','','','','104','43','','','','','337,349,393','','','','','','','337,349,393','337,349,393','0','None','Health','Mental Health'),
('64','0','0','0','1611077452','0','44','0','0','0','Ask friends about job openings\r\nSearch online for jobs\r\nCheck the newspaper for jobs\r\nSpend time networking\r\nWork on improving skills\r\nSubmit an application to 2 job listings\r\nPrepare for job interview\r\nPrepare for job interview\r\nReflect, talk to fellow co-workers, friends, and family\r\nPractice for meeting with manager about different responsibilities','','','','','It challenges me to grow','Update resume\r\nUpdate cover letter\r\nPick appropriate attire for interview\r\nSchedule meeting with manager\r\nPrepare 5 interview questions','false','','','','104','44','','','','','339,504,511','','','','','','','339,504,511','339,504,511','0','None','',''),
('65','0','0','0','1611095588','0','44','0','0','0','','','','','','Find permanent supportive housing','Research local supportive housing programs\r\nCalculate my housing budget\r\nVisit a supportive housing program office\r\nDetermine fees/costs of different programs\r\nAsk supportive housing program staff for support and guidance\r\nApply for supportive housing\r\nAttend community meeting on supportive housing','false','','','','104','44','','','','','338,551,554','','','','','','','338,551,554','338,551,554','0','Dropdown','',''),
('66','0','0','0','1611100504','0','45','0','1611032400','1612069200','practice recurrin goal ','','','','','Close to home','Talk with guidance counselor at school\r\nCheck locations of courses before enrolling\r\nGet a MetroCard, bus pass, transit pass, etc\r\nSearch online for degree programs nearby','false','','','','104','45','','','','','336,488,455','','','','','','','336,488,455','336,488,455','0','','',''),
('67','0','0','0','1611100775','0','45','0','0','0','Do study session with friend\r\nComplete homework assignments\r\nReview homework requirements\r\n','','','','','easy commute','Talk with guidance counselor\r\nSet up a quiet place in my home to study and do homework\r\n\r\nMake a plan for doing longer projects\r\nExplore ways to learn STEM(Science, Tech, Engin, Math)','false','','','','104','45','','','','','336,488,457','','','','','','','336,488,457','336,488,457','0','Dropdown','',''),
('68','0','0','0','1611102101','0','1','0','0','0','','','','','','Close to home','Talk with guidance counselor at school\r\nCheck locations of courses before enrolling\r\nGet a MetroCard, bus pass, transit pass, etc\r\nSearch online for degree programs nearby','false','','','','104','1','','','','','336,488,455','','','','','','','336,488,455','336,488,455','0','','',''),
('69','0','0','0','1611102173','0','45','0','0','0','Work on application materials for college/university\r\n','','','','','Bachelor\'s degree','Talk with guidance counselor at school about applying to college/university\r\nResearch colleges/universities (including children-friendly ones)\r\nApply for colleges/university\r\nApply for financial aid and scholarships\r\nEnroll att college/university\r\nTrack degree progress and credit requirements\r\nTalk with academic advisor at college/university\r\nMake a plan for doing daily homework\r\nMake a plan for doing longer projects\r\nFind a study group\r\n','false','','','','104','45','','','','','336,399,419','','','','','','','336,399,419,422','336,399,419,424','0','Dropdown','','');

CREATE TABLE IF NOT EXISTS `app_entity_83_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=956 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entity_83_values VALUES
('85','16','1013','43'),
('86','16','1029','337'),
('87','16','1029','349'),
('88','16','1008','104'),
('121','5','1053','336'),
('122','5','1053','344'),
('123','5','1053','348'),
('124','5','1053','374'),
('125','5','1052','336'),
('126','5','1052','344'),
('127','5','1052','348'),
('128','5','1052','372'),
('129','5','1029','336'),
('130','5','1029','344'),
('131','5','1029','348'),
('133','12','1013','39'),
('134','12','1053','336'),
('135','12','1053','344'),
('136','12','1053','347'),
('137','12','1053','377'),
('138','12','1052','336'),
('139','12','1052','344'),
('140','12','1052','347'),
('141','12','1052','375'),
('142','12','1029','336'),
('143','12','1029','344'),
('144','12','1029','347'),
('145','12','1008','104'),
('146','14','1013','39'),
('147','14','1053','336'),
('148','14','1053','344'),
('149','14','1053','347'),
('150','14','1053','377'),
('151','14','1052','336'),
('152','14','1052','344'),
('153','14','1052','347'),
('154','14','1052','375'),
('155','14','1029','336'),
('156','14','1029','344'),
('157','14','1029','347'),
('158','14','1008','103'),
('167','18','1013','43'),
('168','18','1053','337'),
('169','18','1053','349'),
('170','18','1052','337'),
('171','18','1052','349'),
('172','18','1029','337'),
('173','18','1029','349'),
('174','18','1008','104'),
('175','19','1013','39'),
('176','19','1053','337'),
('177','19','1053','378'),
('178','19','1053','379'),
('179','19','1052','337'),
('180','19','1052','378'),
('181','19','1052','379'),
('182','19','1029','337'),
('183','19','1029','378'),
('184','19','1029','379'),
('185','19','1008','104'),
('208','20','1013','45'),
('209','20','1053','337'),
('210','20','1053','349'),
('211','20','1053','393'),
('212','20','1052','337'),
('213','20','1052','349'),
('214','20','1052','393'),
('215','20','1029','337'),
('216','20','1029','349'),
('217','20','1029','393'),
('218','20','1008','104'),
('219','21','1013','42'),
('220','21','1053','336'),
('221','21','1053','399'),
('222','21','1053','401'),
('223','21','1053','404'),
('224','21','1052','336'),
('225','21','1052','399'),
('226','21','1052','401'),
('227','21','1052','403'),
('228','21','1029','336'),
('229','21','1029','399'),
('230','21','1029','401'),
('231','21','1008','104'),
('254','22','1013','44'),
('255','22','1053','337'),
('256','22','1053','378'),
('257','22','1053','388'),
('258','22','1052','337'),
('259','22','1052','378'),
('260','22','1052','388'),
('261','22','1029','337'),
('262','22','1029','378'),
('263','22','1029','388'),
('264','22','1008','104'),
('276','23','1013','45'),
('277','23','1053','337'),
('278','23','1053','378'),
('279','23','1053','388'),
('280','23','1052','337'),
('281','23','1052','378'),
('282','23','1052','388'),
('283','23','1029','337'),
('284','23','1029','378'),
('285','23','1029','388'),
('287','23','1008','103'),
('301','24','1013','45'),
('302','24','1053','336'),
('303','24','1053','399'),
('304','24','1053','412'),
('305','24','1053','417'),
('306','24','1052','336'),
('307','24','1052','399'),
('308','24','1052','412'),
('309','24','1052','413'),
('310','24','1029','336'),
('311','24','1029','399'),
('312','24','1029','412'),
('313','24','1008','104'),
('398','26','1013','45'),
('399','26','1053','337'),
('400','26','1053','378'),
('401','26','1053','386'),
('402','26','1052','337'),
('403','26','1052','378'),
('404','26','1052','386'),
('405','26','1029','337'),
('406','26','1029','378'),
('407','26','1029','386'),
('408','26','1008','104'),
('409','27','1013','45'),
('410','27','1053','337'),
('411','27','1053','349'),
('412','27','1053','392'),
('413','27','1052','337'),
('414','27','1052','349'),
('415','27','1052','392'),
('416','27','1029','337'),
('417','27','1029','349'),
('418','27','1029','392'),
('419','27','1008','104'),
('420','28','1013','45'),
('421','28','1053','336'),
('422','28','1053','399'),
('423','28','1053','400'),
('424','28','1052','336'),
('425','28','1052','399'),
('426','28','1052','400'),
('427','28','1029','336'),
('428','28','1029','399'),
('429','28','1029','400'),
('430','28','1008','104'),
('431','29','1013','45'),
('432','29','1053','337'),
('433','29','1053','378'),
('434','29','1053','389'),
('435','29','1052','337'),
('436','29','1052','378'),
('437','29','1052','389'),
('438','29','1029','337'),
('439','29','1029','378'),
('440','29','1029','389'),
('441','29','1008','104'),
('442','30','1013','45'),
('443','30','1053','336'),
('444','30','1053','399'),
('445','30','1053','446'),
('446','30','1053','454'),
('447','30','1052','336'),
('448','30','1052','399'),
('449','30','1052','446'),
('450','30','1052','451'),
('451','30','1029','336'),
('452','30','1029','399'),
('453','30','1029','446'),
('454','30','1008','104'),
('455','31','1013','45'),
('456','31','1053','337'),
('457','31','1053','378'),
('458','31','1053','387'),
('459','31','1052','337'),
('460','31','1052','378'),
('461','31','1052','387'),
('462','31','1029','337'),
('463','31','1029','378'),
('464','31','1029','387'),
('465','31','1008','104'),
('489','34','1013','44'),
('490','34','1053','337'),
('491','34','1053','378'),
('492','34','1053','387'),
('493','34','1052','337'),
('494','34','1052','378'),
('495','34','1052','387'),
('496','34','1029','337'),
('497','34','1029','378'),
('498','34','1029','387'),
('499','34','1008','104'),
('511','36','1013','44'),
('512','36','1053','336'),
('513','36','1053','399'),
('514','36','1053','401'),
('515','36','1053','404'),
('516','36','1052','336'),
('517','36','1052','399'),
('518','36','1052','401'),
('519','36','1052','403'),
('520','36','1029','336'),
('521','36','1029','399'),
('522','36','1029','401'),
('523','36','1008','104'),
('524','37','1013','44'),
('525','37','1053','336'),
('526','37','1053','399'),
('527','37','1053','401'),
('528','37','1053','404'),
('529','37','1052','336'),
('530','37','1052','399'),
('531','37','1052','401'),
('532','37','1052','403'),
('533','37','1029','336'),
('534','37','1029','399'),
('535','37','1029','401'),
('536','37','1008','104'),
('537','38','1013','44'),
('538','38','1053','336'),
('539','38','1053','399'),
('540','38','1053','401'),
('541','38','1053','404'),
('542','38','1052','336'),
('543','38','1052','399'),
('544','38','1052','401'),
('545','38','1052','403'),
('546','38','1029','336'),
('547','38','1029','399'),
('548','38','1029','401'),
('549','38','1008','104'),
('550','39','1013','44'),
('551','39','1053','336'),
('552','39','1053','399'),
('553','39','1053','408'),
('554','39','1053','411'),
('555','39','1052','336'),
('556','39','1052','399'),
('557','39','1052','408'),
('558','39','1052','410'),
('559','39','1029','336'),
('560','39','1029','399'),
('561','39','1029','408'),
('562','39','1008','104'),
('574','41','1013','44'),
('575','41','1053','336'),
('576','41','1053','399'),
('577','41','1053','412'),
('578','41','1053','417'),
('579','41','1052','336'),
('580','41','1052','399'),
('581','41','1052','412'),
('582','41','1052','414'),
('583','41','1029','336'),
('584','41','1029','399'),
('585','41','1029','412'),
('586','41','1008','104'),
('587','42','1013','44'),
('588','42','1053','336'),
('589','42','1053','399'),
('590','42','1053','408'),
('591','42','1053','411'),
('592','42','1052','336'),
('593','42','1052','399'),
('594','42','1052','408'),
('595','42','1052','410'),
('596','42','1029','336'),
('597','42','1029','399'),
('598','42','1029','408'),
('599','42','1008','104'),
('600','43','1013','44'),
('601','43','1053','336'),
('602','43','1053','399'),
('603','43','1053','412'),
('604','43','1053','417'),
('605','43','1052','336'),
('606','43','1052','399'),
('607','43','1052','412'),
('608','43','1052','414'),
('609','43','1029','336'),
('610','43','1029','399'),
('611','43','1029','412'),
('612','43','1008','104'),
('613','44','1013','44'),
('614','44','1053','336'),
('615','44','1053','399'),
('616','44','1053','419'),
('617','44','1053','424'),
('618','44','1052','336'),
('619','44','1052','399'),
('620','44','1052','419'),
('621','44','1052','422'),
('622','44','1029','336'),
('623','44','1029','399'),
('624','44','1029','419'),
('625','44','1008','104'),
('626','45','1013','44'),
('627','45','1053','336'),
('628','45','1053','399'),
('629','45','1053','428'),
('630','45','1053','434'),
('631','45','1052','336'),
('632','45','1052','399'),
('633','45','1052','428'),
('634','45','1052','431'),
('635','45','1029','336'),
('636','45','1029','399'),
('637','45','1029','428'),
('638','45','1008','104'),
('639','46','1013','44'),
('640','46','1053','336'),
('641','46','1053','399'),
('642','46','1053','438'),
('643','46','1053','445'),
('644','46','1052','336'),
('645','46','1052','399'),
('646','46','1052','438'),
('647','46','1052','441'),
('648','46','1029','336'),
('649','46','1029','399'),
('650','46','1029','438'),
('651','46','1008','104'),
('652','47','1013','44'),
('653','47','1053','336'),
('654','47','1053','399'),
('655','47','1053','446'),
('656','47','1053','454'),
('657','47','1052','336'),
('658','47','1052','399'),
('659','47','1052','446'),
('660','47','1052','451'),
('661','47','1029','336'),
('662','47','1029','399'),
('663','47','1029','446'),
('664','47','1008','104'),
('665','25','1013','45'),
('666','25','1053','336'),
('667','25','1053','399'),
('668','25','1053','412'),
('669','25','1053','417'),
('670','25','1052','336'),
('671','25','1052','399'),
('672','25','1052','412'),
('673','25','1052','416'),
('674','25','1029','336'),
('675','25','1029','399'),
('676','25','1029','412'),
('677','25','1008','103'),
('678','48','1013','45'),
('679','48','1053','337'),
('680','48','1053','349'),
('681','48','1053','393'),
('682','48','1052','337'),
('683','48','1052','349'),
('684','48','1052','393'),
('685','48','1029','337'),
('686','48','1029','349'),
('687','48','1029','393'),
('688','48','1008','104'),
('689','49','1013','45'),
('690','49','1053','336'),
('691','49','1053','399'),
('692','49','1053','419'),
('693','49','1053','424'),
('694','49','1052','336'),
('695','49','1052','399'),
('696','49','1052','419'),
('697','49','1052','422'),
('698','49','1029','336'),
('699','49','1029','399'),
('700','49','1029','419'),
('701','49','1008','104'),
('702','50','1013','43'),
('703','50','1053','336'),
('704','50','1053','399'),
('705','50','1053','419'),
('706','50','1053','424'),
('707','50','1052','336'),
('708','50','1052','399'),
('709','50','1052','419'),
('710','50','1052','422'),
('711','50','1029','336'),
('712','50','1029','399'),
('713','50','1029','419'),
('726','52','1013','44'),
('727','52','1053','339'),
('728','52','1053','360'),
('729','52','1053','396'),
('730','52','1052','339'),
('731','52','1052','360'),
('732','52','1052','396'),
('733','52','1029','339'),
('734','52','1029','360'),
('735','52','1029','396'),
('736','52','1008','104'),
('737','53','1013','44'),
('738','53','1053','339'),
('739','53','1053','360'),
('740','53','1053','361'),
('741','53','1052','339'),
('742','53','1052','360'),
('743','53','1052','361'),
('744','53','1029','339'),
('745','53','1029','360'),
('746','53','1029','361'),
('747','53','1008','104'),
('759','55','1013','44'),
('760','55','1053','339'),
('761','55','1053','360'),
('762','55','1053','398'),
('763','55','1052','339'),
('764','55','1052','360'),
('765','55','1052','398'),
('766','55','1029','339'),
('767','55','1029','360'),
('768','55','1029','398'),
('769','55','1008','104'),
('771','54','1013','47'),
('772','54','1053','339'),
('773','54','1053','360'),
('774','54','1053','361'),
('775','54','1052','339'),
('776','54','1052','360'),
('777','54','1052','361'),
('778','54','1029','339'),
('779','54','1029','360'),
('780','54','1029','361'),
('782','54','1008','103'),
('783','50','1008','103'),
('784','5','1008','103'),
('785','56','1013','45'),
('786','56','1053','336'),
('787','56','1053','399'),
('788','56','1053','408'),
('789','56','1053','411'),
('790','56','1052','336'),
('791','56','1052','399'),
('792','56','1052','408'),
('793','56','1052','410'),
('794','56','1029','336'),
('795','56','1029','399'),
('796','56','1029','408'),
('797','56','1008','104'),
('809','58','1013','39'),
('810','58','1053','337'),
('811','58','1053','378'),
('812','58','1053','388'),
('813','58','1052','337'),
('814','58','1052','378'),
('815','58','1052','388'),
('816','58','1029','337'),
('817','58','1029','378'),
('818','58','1029','388'),
('819','58','1008','104'),
('820','59','1013','39'),
('821','59','1053','338'),
('822','59','1053','512'),
('823','59','1053','514'),
('824','59','1052','338'),
('825','59','1052','512'),
('826','59','1052','514'),
('827','59','1029','338'),
('828','59','1029','512'),
('829','59','1029','514'),
('830','59','1008','104'),
('842','61','1013','44'),
('843','61','1053','336'),
('844','61','1053','490'),
('845','61','1053','469'),
('846','61','1052','336'),
('847','61','1052','490'),
('848','61','1052','469'),
('849','61','1029','336'),
('850','61','1029','490'),
('851','61','1029','469'),
('852','61','1008','104'),
('853','60','1013','44'),
('854','60','1053','336'),
('855','60','1053','490'),
('856','60','1053','468'),
('857','60','1052','336'),
('858','60','1052','490'),
('859','60','1052','468'),
('860','60','1029','336'),
('861','60','1029','490'),
('862','60','1029','468'),
('863','60','1008','104'),
('864','62','1013','45'),
('865','62','1053','336'),
('866','62','1053','399'),
('867','62','1053','419'),
('868','62','1053','424'),
('869','62','1052','336'),
('870','62','1052','399'),
('871','62','1052','419'),
('872','62','1052','422'),
('873','62','1029','336'),
('874','62','1029','399'),
('875','62','1029','419'),
('876','62','1008','104'),
('877','63','1013','43'),
('878','63','1053','337'),
('879','63','1053','349'),
('880','63','1053','393'),
('881','63','1052','337'),
('882','63','1052','349'),
('883','63','1052','393'),
('884','63','1029','337'),
('885','63','1029','349'),
('886','63','1029','393'),
('887','63','1008','104'),
('888','64','1013','44'),
('889','64','1053','339'),
('890','64','1053','504'),
('891','64','1053','511'),
('892','64','1052','339'),
('893','64','1052','504'),
('894','64','1052','511'),
('895','64','1029','339'),
('896','64','1029','504'),
('897','64','1029','511'),
('898','64','1008','104'),
('899','65','1013','44'),
('900','65','1053','338'),
('901','65','1053','551'),
('902','65','1053','554'),
('903','65','1052','338'),
('904','65','1052','551'),
('905','65','1052','554'),
('906','65','1029','338'),
('907','65','1029','551'),
('908','65','1029','554'),
('909','65','1008','104'),
('910','66','1013','45'),
('911','66','1053','336'),
('912','66','1053','488'),
('913','66','1053','455'),
('914','66','1052','336'),
('915','66','1052','488'),
('916','66','1052','455'),
('917','66','1029','336'),
('918','66','1029','488'),
('919','66','1029','455'),
('920','66','1008','104'),
('921','67','1013','45'),
('922','67','1053','336'),
('923','67','1053','488'),
('924','67','1053','457'),
('925','67','1052','336'),
('926','67','1052','488'),
('927','67','1052','457'),
('928','67','1029','336'),
('929','67','1029','488'),
('930','67','1029','457'),
('931','67','1008','104'),
('932','68','1013','1'),
('933','68','1053','336'),
('934','68','1053','488'),
('935','68','1053','455'),
('936','68','1052','336'),
('937','68','1052','488'),
('938','68','1052','455'),
('939','68','1029','336'),
('940','68','1029','488'),
('941','68','1029','455'),
('942','68','1008','104'),
('943','69','1013','45'),
('944','69','1053','336'),
('945','69','1053','399'),
('946','69','1053','419'),
('947','69','1053','424'),
('948','69','1052','336'),
('949','69','1052','399'),
('950','69','1052','419'),
('951','69','1052','422'),
('952','69','1029','336'),
('953','69','1029','399'),
('954','69','1029','419'),
('955','69','1008','104');

CREATE TABLE IF NOT EXISTS `app_entity_84` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int unsigned DEFAULT '0',
  `parent_item_id` int unsigned DEFAULT '0',
  `linked_id` int unsigned DEFAULT '0',
  `date_added` bigint DEFAULT '0',
  `date_updated` bigint DEFAULT '0',
  `created_by` int unsigned DEFAULT NULL,
  `sort_order` int DEFAULT '0',
  `field_1043` varchar(8) NOT NULL,
  `field_1044` varchar(1) NOT NULL,
  `field_1045` text NOT NULL,
  `field_1047` text NOT NULL,
  `field_1048` varchar(1) NOT NULL,
  `field_1061` int NOT NULL,
  `field_1062` varchar(255) NOT NULL,
  `field_1063` varchar(255) NOT NULL,
  `field_1064` int NOT NULL,
  `field_1067` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_field_1047` (`field_1047`(128)),
  KEY `idx_field_1045` (`field_1045`(128)),
  KEY `idx_field_1061` (`field_1061`),
  KEY `idx_field_1064` (`field_1064`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entity_84 VALUES
('28','0','0','0','1611000426','1611025774','39','0','true','','39','','','0','This is a custom goal','This is a custom goal','105',''),
('29','0','0','0','1611000446','1611025774','39','0','true','','39','','','476','Look up new healthy recipe','','106',''),
('31','0','0','0','1611004873','0','45','0','false','','45','','','0','Creating my own custom recuring goal','Creating my own custom recuring goal','105',''),
('32','0','0','0','1611005309','0','45','0','false','','45','','','484','Check blood sugar levels according to doctor','','106',''),
('33','0','0','0','1611024887','1611025162','45','0','true','','45','','','480','Drink 6 glasses of water','','106',''),
('34','0','0','0','1611026374','0','45','0','false','','45','','','485','Check feet daily','','106',''),
('35','0','0','0','1611065213','1611065299','45','0','false','','45','','','485','Check feet daily','my own custom goal','0',''),
('36','0','0','0','1611068007','0','45','0','false','','45','','','485','Check feet daily','','106',''),
('38','0','0','0','1611074493','0','39','0','false','','39','','','477','Do monthly weigh-in','','106',''),
('39','0','0','0','1611074573','0','39','0','false','','39','','','0','Testing edit','Testing edit','105','Custom'),
('40','0','0','0','1611074597','0','39','0','false','','39','','','482','Write in my gratitude journal','','106','Search'),
('41','0','0','0','1611102229','0','45','0','false','','45','','','485','Check feet daily','','106','Search'),
('42','0','0','0','1611105227','0','45','0','false','','45','','','484','Check blood sugar levels according to doctor','','106','Search');

CREATE TABLE IF NOT EXISTS `app_entity_84_values` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `items_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_items_fields_id` (`items_id`,`fields_id`),
  KEY `idx_value_id` (`value`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_entity_84_values VALUES
('31','28','1064','105'),
('32','28','1045','39'),
('33','29','1064','106'),
('34','29','1061','476'),
('35','29','1045','39'),
('39','31','1064','105'),
('40','31','1045','45'),
('41','32','1064','106'),
('42','32','1061','484'),
('43','32','1045','45'),
('50','33','1064','106'),
('51','33','1061','480'),
('52','33','1045','45'),
('53','34','1064','106'),
('54','34','1061','485'),
('55','34','1045','45'),
('58','35','1061','485'),
('59','35','1045','45'),
('60','36','1064','106'),
('61','36','1061','485'),
('62','36','1045','45'),
('65','38','1064','106'),
('66','38','1061','477'),
('67','38','1045','39'),
('68','39','1064','105'),
('69','39','1045','39'),
('70','40','1064','106'),
('71','40','1061','482'),
('72','40','1045','39'),
('73','41','1064','106'),
('74','41','1061','485'),
('75','41','1045','45'),
('76','42','1064','106'),
('77','42','1061','484'),
('78','42','1045','45');

CREATE TABLE IF NOT EXISTS `app_ext_calendar` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `in_menu` tinyint unsigned NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL,
  `default_view` varchar(16) NOT NULL,
  `view_modes` varchar(255) NOT NULL,
  `event_limit` smallint NOT NULL,
  `highlighting_weekends` varchar(64) NOT NULL,
  `min_time` varchar(5) NOT NULL,
  `max_time` varchar(5) NOT NULL,
  `time_slot_duration` varchar(8) NOT NULL,
  `start_date` int NOT NULL,
  `end_date` int NOT NULL,
  `heading_template` varchar(64) NOT NULL,
  `use_background` int NOT NULL,
  `fields_in_popup` text NOT NULL,
  `filters_panel` varchar(16) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_calendar VALUES
('3','83','0','Milestone events ','agendaWeek','agendaWeek','6','','09:00','15:00','00:30:00','995','996','[1002]','1008','1003,1018','default');

CREATE TABLE IF NOT EXISTS `app_ext_calendar_access` (
  `id` int NOT NULL AUTO_INCREMENT,
  `calendar_id` int DEFAULT NULL,
  `calendar_type` varchar(16) NOT NULL,
  `access_groups_id` int NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_calendar_id` (`calendar_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_calendar_access VALUES
('26','3','report','6','view'),
('27','3','report','12','view'),
('28','3','report','5','view');

CREATE TABLE IF NOT EXISTS `app_ext_calendar_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `start_date` bigint unsigned NOT NULL,
  `end_date` bigint NOT NULL,
  `event_type` varchar(16) NOT NULL,
  `is_public` tinyint(1) DEFAULT NULL,
  `bg_color` varchar(16) NOT NULL,
  `repeat_type` varchar(16) NOT NULL,
  `repeat_interval` int DEFAULT NULL,
  `repeat_days` varchar(16) NOT NULL,
  `repeat_end` int DEFAULT NULL,
  `repeat_limit` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_calendar_events VALUES
('15','45','water the plants','','1610514000','1610514000','public',NULL,'#3a87ad','daily','1','','1611810000','0'),
('16','45','Kevin\'s custom report','testing','1610514000','1610514000','personal','1','#3a87ad','','1','','0','0'),
('17','45','','','1610427600','1610427600','personal','0','#3a87ad','daily','1','','0','0');

CREATE TABLE IF NOT EXISTS `app_ext_call_history` (
  `id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(16) NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  `direction` varchar(16) NOT NULL,
  `phone` varchar(16) NOT NULL,
  `duration` int NOT NULL,
  `sms_text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_chat_access` (
  `id` int NOT NULL AUTO_INCREMENT,
  `access_groups_id` int NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_chat_access VALUES
('38','0','0,13,6,12,5,4'),
('39','13','0,6,5'),
('40','6','0,13,5'),
('41','12','0,12,5,4'),
('42','5','0,13,6,12,5,4'),
('43','4','0,12,5,4');

CREATE TABLE IF NOT EXISTS `app_ext_chat_conversations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `menu_icon` varchar(64) NOT NULL,
  `menu_icon_color` varchar(16) NOT NULL,
  `assigned_to` text NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_chat_conversations_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `conversations_id` int NOT NULL,
  `users_id` int NOT NULL,
  `message` text NOT NULL,
  `attachments` text NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_conversations_id` (`conversations_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_chat_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `assigned_to` int NOT NULL,
  `message` text NOT NULL,
  `attachments` text NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_users_assigned` (`users_id`,`assigned_to`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_chat_messages VALUES
('89','45','40','https://54.197.88.140/ourreach/index.php?module=ext/ipages/view&amp;id=7','','1610765182'),
('90','40','45','hmm interesting. I didn\'t get an error going into the system. Did you get that error just for the \"terms of use\" page or every time you try and log on?','','1610985103'),
('91','45','40','not sure where this is coming from','','1610996799'),
('92','45','40','that was just a sample test regarding the link','','1610996836');

CREATE TABLE IF NOT EXISTS `app_ext_chat_unread_messages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `assigned_to` int NOT NULL,
  `messages_id` int NOT NULL,
  `conversations_id` int NOT NULL,
  `notification_status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_assigned_to` (`assigned_to`),
  KEY `idx_messages_id` (`messages_id`),
  KEY `idx_conversations_id` (`conversations_id`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_chat_unread_messages VALUES
('92','45','40','91','0','0'),
('93','45','40','92','0','0');

CREATE TABLE IF NOT EXISTS `app_ext_chat_users_online` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `date_check` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_chat_users_online VALUES
('14','1','1611149836'),
('15','43','1611095193'),
('16','39','1611092520'),
('17','45','1611148736'),
('18','42','1611103731'),
('19','44','1611095780'),
('20','40','1611127013'),
('21','47','1610985583');

CREATE TABLE IF NOT EXISTS `app_ext_comments_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_comments_templates_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `templates_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_templates_id` (`templates_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_cryptopro_certificates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `thumbprint` varchar(64) NOT NULL,
  `certbase64` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `users_id` (`users_id`),
  KEY `thumbprint` (`thumbprint`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_currencies` (
  `id` int NOT NULL AUTO_INCREMENT,
  `is_default` tinyint(1) NOT NULL,
  `title` varchar(64) NOT NULL,
  `code` varchar(16) NOT NULL,
  `symbol` varchar(16) NOT NULL,
  `value` float(13,8) NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_email_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `action_type` varchar(64) NOT NULL,
  `send_to_users` text NOT NULL,
  `send_to_assigned_users` text NOT NULL,
  `send_to_email` text NOT NULL,
  `send_to_assigned_email` text NOT NULL,
  `monitor_fields_id` int NOT NULL,
  `monitor_choices` text NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `attach_attachments` tinyint(1) NOT NULL,
  `attach_template` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_monitor_fields_id` (`monitor_fields_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_email_rules VALUES
('1','57','insert_send_to_assigned_users','','593','','','0','','[594]','[592]','1','0',''),
('3','59','edit_send_to_assigned_users','','643','','','638','89','Congrats! You completed your milestone: [631]','<h3><img alt=\"\" src=\" https://i.pinimg.com/originals/83/bd/37/83bd37fe1bb51a53b2b60b9e8a2533d5.jpg\" style=\"float:left; height:275px; margin-right:10px; width:325px\" />Congratulations [current_user_name], you have just completed your milestone [631]!</h3>\r\n\r\n<p>As a way of showing our appreciation for your hard work, we wanted to&nbsp;give you&nbsp;a&nbsp;reward.<br />\r\n<br />\r\nThis is a big step towards the ultimate goal of staying happy and healthy. Keep up the good work!<br />\r\n<br />\r\nWarmly,<br />\r\n[675]</p>\r\n','1','1',''),
('4','59','edit_send_to_assigned_users','','675','','','638','89','Your client [643] just completed a milestone!','Great news!&nbsp;[643] just completed the milestone&nbsp;[631].','0','0',''),
('5','83','edit_send_to_assigned_users','','1013','','','1008','103','Hello ','Hello','0','0',''),
('6','83','comment_send_to_assigned_users','','1013','','','0','','You recieved a comment on Milestone: [1002] from [1022]','[comment]','0','1',''),
('7','83','edit_send_to_assigned_users','','1022','','','1008','103','Your client [1013] just completed a milestone!','Great news!&nbsp;[1013] just completed the milestone [1002].','1','0',''),
('8','83','edit_send_to_assigned_users','','1013','','','1008','103','Congrats!','Congratulations [1013], you have just completed your milestone [1002]!<br />\r\nAs a way of showing our appreciation for your hard work, we wanted to&nbsp;give you&nbsp;a&nbsp;reward.<br />\r\n<br />\r\nThis is a big step towards the ultimate goal of staying happy and healthy. Keep up the good work!<br />\r\n<br />\r\nWarmly,<br />\r\n[1022]','1','1','');

CREATE TABLE IF NOT EXISTS `app_ext_entities_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_entities_templates VALUES
('3','46','Education - Money - Save Money','0,6,12,5,4','','0','1'),
('4','47','Education - Money - Save Money - 401k','0,6,12,5,4','','0','1'),
('5','38','Increase Education','0,6,12,5,4','','0','1'),
('6','47','Education - Money - Save Money - Bank Account','0,6,12,5,4','','0','1'),
('7','46','Health -  Mental Health - Peace Level','0,6,12,5,4','','0','1'),
('8','46','Health - Prenatal - Healthy Baby','0,6,12,5,4','','0','1'),
('10','46','Education - Education Level','0,13,6,12,5,4','','0','1'),
('11','49','Education - Money - Save Money','0,13,6,12,5,4','','0','1'),
('12','46','Health - Main - HbA1c','0,6,12,5,4','','0','1'),
('15','58','follow my diet according to care plan','','','0','1'),
('17','59','HbA1c','0,6,12,5,4','','0','1'),
('18','72','High School','0,6,12,5,4','','0','1'),
('19','82','Quit Smoking','0,13,6,12,5,4','','0','1');

CREATE TABLE IF NOT EXISTS `app_ext_entities_templates_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `templates_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_templates_id` (`templates_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_entities_templates_fields VALUES
('8','5','343','Read for 20 minutes\r\nDo Assigned Schoolwork'),
('9','5','347','I\'ll get my high school diploma so I can get a better job.'),
('10','3','475','Save Money'),
('11','3','467','Put change in change jar\r\nCheck your bank transactions'),
('12','3','474','Read Money World blog for helpful tips'),
('13','4','476','Open 401k Account'),
('14','6','476','Open Bank Account'),
('15','7','475','Increase level of Peace'),
('16','7','467','Sleep at least 6 hours/night\r\nTake proper medications\r\nWrite in gratitude journal\r\nMediate/do deep breathing\r\nPing a friend\r\nWalk/Exercise for 30 minutes'),
('17','7','479','Sign up for therapy\r\nJoin a support group\r\n'),
('18','8','475','Have a healthy pregnancy'),
('19','8','467','Take prenatal vitamin\r\nGet required daily intake of folic acid\r\nPractice deep breathing\r\nPing a friend'),
('20','8','479','Eliminate alcohol and other non-prescribed drugs\r\nEnroll in \"stop smoking\" plan for pregnancy\r\nMake sure I\'m up to date on my immunizations\r\nSet up pre-natal medical appointments\r\nRegister for childbirth class\r\nRegister for breastfeeding class\r\nRegister for prenatal yoga class\r\nLearn about family health history with partner'),
('21','8','481','273'),
('22','8','482','281'),
('23','3','482','278'),
('24','10','482','305'),
('25','10','479','Sign up for classes\r\nSave up for costs\r\nPurchase laptop'),
('26','10','471','To increase my level of education so I can get a better job.'),
('27','7','482','283'),
('28','11','509','Set up Access permissions'),
('29','12','479','Ask family to support healthy food choices\r\nSign up for nutrition plan\r\nSign up for exercise plan\r\nLearn about healthy recipes\r\nDo 30 day weigh in\r\nTalk with family about having diabetes\r\nAttend diabetes support group\r\nSchedule an eye exam'),
('30','12','482','280'),
('31','12','475','Maintain desired HbA1c level'),
('34','12','467','follow my diet according to care plan'),
('37','17','632','This is a test\r\nTo see how it would look\r\ncapitalized or not'),
('38','17','626','Another test\r\nlooking at capitals'),
('39','17','631','HbA1c'),
('40','17','727','280'),
('41','18','785','Get a high school diploma'),
('42','18','786','Take SAT\r\nPass APs\r\nApply to college'),
('43','19','850','Quit Smoking');

CREATE TABLE IF NOT EXISTS `app_ext_export_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `type` varchar(16) NOT NULL DEFAULT 'html',
  `label_size` varchar(16) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `button_title` varchar(64) NOT NULL,
  `button_position` varchar(64) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `template_filename` varchar(255) NOT NULL,
  `template_css` text NOT NULL,
  `page_orientation` varchar(16) NOT NULL,
  `split_into_pages` tinyint(1) NOT NULL DEFAULT '1',
  `template_header` text NOT NULL,
  `template_footer` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_file_storage_queue` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modules_id` int NOT NULL,
  `filename` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_modules_id` (`modules_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_file_storage_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `modules_id` int NOT NULL,
  `fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_modules_id` (`modules_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_functions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `reports_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `notes` text NOT NULL,
  `functions_name` varchar(32) NOT NULL,
  `functions_formula` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_reports_id` (`reports_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_functions VALUES
('6','46','294','Count milestones','','COUNT',''),
('7','49','295','Count goals','','COUNT',''),
('8','49','296','Completed Goals','','COUNT',''),
('10','46','304','Completed milestones','','COUNT',''),
('15','83','725','Count Completed Milestones','','COUNT',''),
('16','83','726','Total Milestones','','COUNT','');

CREATE TABLE IF NOT EXISTS `app_ext_funnelchart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `type` varchar(16) NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `group_by_field` int NOT NULL,
  `hide_zero_values` tinyint(1) NOT NULL,
  `exclude_choices` text NOT NULL,
  `sum_by_field` text NOT NULL,
  `users_groups` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_ganttchart` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `start_date` int NOT NULL,
  `end_date` int NOT NULL,
  `weekends` varchar(16) NOT NULL,
  `gantt_date_format` varchar(16) NOT NULL,
  `progress` int DEFAULT NULL,
  `fields_in_listing` text NOT NULL,
  `use_background` int NOT NULL DEFAULT '0',
  `default_fields_in_listing` varchar(64) NOT NULL,
  `grid_width` smallint NOT NULL,
  `default_view` varchar(16) NOT NULL,
  `skin` varchar(32) NOT NULL,
  `auto_scheduling` tinyint(1) NOT NULL,
  `highlight_critical_path` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_ganttchart_access` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ganttchart_id` int NOT NULL,
  `access_groups_id` int NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_ganttchart_id` (`ganttchart_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_ganttchart_depends` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ganttchart_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `item_id` int NOT NULL,
  `depends_id` int NOT NULL,
  `type` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_item_id` (`item_id`),
  KEY `idx_depends_id` (`depends_id`),
  KEY `idx_ganttchart_id` (`ganttchart_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_global_search_entities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `fields_for_search` text NOT NULL,
  `fields_in_listing` text NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_global_search_entities VALUES
('1','37','349','349,350,583','0'),
('2','46','475','475,611,482,479','0');

CREATE TABLE IF NOT EXISTS `app_ext_graphicreport` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `xaxis` int NOT NULL,
  `yaxis` varchar(255) NOT NULL,
  `allowed_groups` text NOT NULL,
  `chart_type` varchar(16) NOT NULL,
  `period` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_image_map` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `fields_id` int NOT NULL,
  `users_groups` text NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `scale` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_import_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `multilevel_import` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `import_fields` text NOT NULL,
  `users_groups` text NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_ipages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `short_name` varchar(64) NOT NULL,
  `menu_icon` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `html_code` text NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_menu` tinyint(1) NOT NULL DEFAULT '0',
  `attachments` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_ipages VALUES
('3','0','Help','','fa-question-circle','','','0,13,6,12,5,4','','1','1',''),
('4','3','Frequently Asked Questions','FAQ','fa-info-circle','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>FAQ Page</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n   \r\n</head>\r\n\r\n<body>\r\n\r\n    <h4 class=\"faq-h4\">Welcome to the Frequently Asked Questions Page!</h4>\r\n\r\n    <hr />\r\n    <div>\r\n        <div class=\"panel-group\" id=\"accordion\">\r\n            <div class=\"faqHeader\">General questions</div>\r\n            <div class=\"panel panel-default\">\r\n                <div class=\"panel-heading\">\r\n                    <h4 class=\"panel-title\">\r\n                        <a class=\"accordion-toggle collapsed\" data-toggle=\"collapse\" data-parent=\"#accordion\"\r\n                            href=\"#collapseOne\">What is OurREACH™?\r\n                        </a>\r\n                    </h4>\r\n                </div>\r\n                <div id=\"collapseOne\" class=\"panel-collapse collapse\">\r\n                    <div class=\"panel-body\">\r\n                        OurREACH™ is a collaboration platform and app, with data analytics, built to equip, empower, and align healthcare and social service providers and the families they serve. The tool also enables employers to support their employees\' wellness.\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"panel panel-default\">\r\n                <div class=\"panel-heading\">\r\n                    <h4 class=\"panel-title\">\r\n                        <a class=\"accordion-toggle collapsed\" data-toggle=\"collapse\" data-parent=\"#accordion\"\r\n                            href=\"#collapseTen\">This is FAQ2. </a>\r\n                    </h4>\r\n                </div>\r\n                <div id=\"collapseTen\" class=\"panel-collapse collapse\">\r\n                    <div class=\"panel-body\">\r\n                        This is an answer to FAQ2.\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"panel panel-default\">\r\n                <div class=\"panel-heading\">\r\n                    <h4 class=\"panel-title\">\r\n                        <a class=\"accordion-toggle collapsed\" data-toggle=\"collapse\" data-parent=\"#accordion\"\r\n                            href=\"#collapseEleven\">This is FAQ3.</a>\r\n                    </h4>\r\n                </div>\r\n                <div id=\"collapseEleven\" class=\"panel-collapse collapse\">\r\n                    <div class=\"panel-body\">\r\n                        This is an answer to FAQ3.\r\n                    </div>\r\n                </div>\r\n            </div>\r\n\r\n            <div class=\"faqHeader\">Another category</div>\r\n            <div class=\"panel panel-default\">\r\n                <div class=\"panel-heading\">\r\n                    <h4 class=\"panel-title\">\r\n                        <a class=\"accordion-toggle collapsed\" data-toggle=\"collapse\" data-parent=\"#accordion\"\r\n                            href=\"#collapseTwo\">This is another FAQ. </a>\r\n                    </h4>\r\n                </div>\r\n                <div id=\"collapseTwo\" class=\"panel-collapse collapse\">\r\n                    <div class=\"panel-body\">\r\n                        This is a FAQ\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"panel panel-default\">\r\n                <div class=\"panel-heading\">\r\n                    <h4 class=\"panel-title\">\r\n                        <a class=\"accordion-toggle collapsed\" data-toggle=\"collapse\" data-parent=\"#accordion\"\r\n                            href=\"#collapseThree\">I have more questions.</a>\r\n                    </h4>\r\n                </div>\r\n                <div id=\"collapseThree\" class=\"panel-collapse collapse\">\r\n                    <div class=\"panel-body\">\r\n                        Here is an answer with bullets.\r\n                        <ul>\r\n                            <li>Bullet 1</li>\r\n                            <li>Bullet 2</li>\r\n                            <li>Bullet 3</li>\r\n                            <li>Bullet 4</li>\r\n                        </ul>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"panel panel-default\">\r\n                <div class=\"panel-heading\">\r\n                    <h4 class=\"panel-title\">\r\n                        <a class=\"accordion-toggle collapsed\" data-toggle=\"collapse\" data-parent=\"#accordion\"\r\n                            href=\"#collapseFive\">Yet another question</a>\r\n                    </h4>\r\n                </div>\r\n                <div id=\"collapseFive\" class=\"panel-collapse collapse\">\r\n                    <div class=\"panel-body\">\r\n                        Here is your answer\r\n                        <br />\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"panel panel-default\">\r\n                <div class=\"panel-heading\">\r\n                    <h4 class=\"panel-title\">\r\n                        <a class=\"accordion-toggle collapsed\" data-toggle=\"collapse\" data-parent=\"#accordion\"\r\n                            href=\"#collapseSix\">?</a>\r\n                    </h4>\r\n                </div>\r\n                <div id=\"collapseSix\" class=\"panel-collapse collapse\">\r\n                    <div class=\"panel-body\">\r\n                        Answer.\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <style>\r\n        .faqHeader {\r\n            font-size: 27px;\r\n            margin: 20px;\r\n        }\r\n\r\n        .panel-heading [data-toggle=\"collapse\"]:after {\r\n        font-family: \'Font Awesome 5 Free\';\r\n        font-weight: 900;\r\n        content: \"\\f106\"; /* \"up\" icon */\r\n        float: right;\r\n        color: #F58723;\r\n        font-size: 18px;\r\n        line-height: 22px;\r\n        }\r\n\r\n        .panel-heading [data-toggle=\"collapse\"].collapsed:after {\r\n            -webkit-transform: rotate(180deg);\r\n            -moz-transform: rotate(180deg);\r\n            -ms-transform: rotate(180deg);\r\n            -o-transform: rotate(180deg);\r\n            transform: rotate(180deg);\r\n            color: #454444;\r\n        }\r\n\r\n    </style>\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>\r\n\r\n','0,13,6,12,5,4','','2','0',''),
('6','3','User Instructions','User Instructions','fa-compass','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>FAQ Page</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n  \r\n</head>\r\n\r\n<body>\r\n\r\n    <h4 class=\"faq-h4\">Welcome to OurREACH!</h4>\r\n\r\n    <hr />\r\n    <div>\r\n        <div class=\"panel-group\" id=\"accordion\">\r\n            <div class=\"panel panel-default\">\r\n                <div class=\"panel-heading\">\r\n                    <h4 class=\"panel-title\">\r\n                        <a class=\"accordion-toggle collapsed\" data-toggle=\"collapse\" data-parent=\"#accordion\"\r\n                            href=\"#collapseOne\">Milestones\r\n                        </a>\r\n                    </h4>\r\n                </div>\r\n                <div id=\"collapseOne\" class=\"panel-collapse collapse\">\r\n                    <div class=\"panel-body\">\r\n                        Here\'s everything about milestones.\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"panel panel-default\">\r\n                <div class=\"panel-heading\">\r\n                    <h4 class=\"panel-title\">\r\n                        <a class=\"accordion-toggle collapsed\" data-toggle=\"collapse\" data-parent=\"#accordion\"\r\n                            href=\"#collapseTen\">Settings</a>\r\n                    </h4>\r\n                </div>\r\n                <div id=\"collapseTen\" class=\"panel-collapse collapse\">\r\n                    <div class=\"panel-body\">\r\n                        Here\'s everything about settings.\r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <div class=\"panel panel-default\">\r\n                <div class=\"panel-heading\">\r\n                    <h4 class=\"panel-title\">\r\n                        <a class=\"accordion-toggle collapsed\" data-toggle=\"collapse\" data-parent=\"#accordion\"\r\n                            href=\"#collapseEleven\">Profile</a>\r\n                    </h4>\r\n                </div>\r\n                <div id=\"collapseEleven\" class=\"panel-collapse collapse\">\r\n                    <div class=\"panel-body\">\r\n                        Here\'s everything about profile.\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n\r\n    <style>\r\n        .faqHeader {\r\n            font-size: 27px;\r\n            margin: 20px;\r\n        }\r\n\r\n        .panel-heading [data-toggle=\"collapse\"]:after {\r\n            font-family: \'Glyphicons Halflings\';\r\n            /* content: \"e072\";  \"play\" icon */\r\n            float: right;\r\n            color: #F58723;\r\n            font-size: 18px;\r\n            line-height: 22px;\r\n        }\r\n\r\n        i.fas.fa-angle-down {\r\n            float: right;\r\n        }\r\n\r\n        .panel-heading [data-toggle=\"collapse\"]:after {\r\n        font-family: \'Font Awesome 5 Free\';\r\n        font-weight: 900;\r\n        content: \"\\f106\"; /* \"up\" icon */\r\n        float: right;\r\n        color: #F58723;\r\n        font-size: 18px;\r\n        line-height: 22px;\r\n        }\r\n\r\n        .panel-heading [data-toggle=\"collapse\"].collapsed:after {\r\n            -webkit-transform: rotate(180deg);\r\n            -moz-transform: rotate(180deg);\r\n            -ms-transform: rotate(180deg);\r\n            -o-transform: rotate(180deg);\r\n            transform: rotate(180deg);\r\n            color: #454444;\r\n        }\r\n\r\n    </style>\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,13,6,12,5,4','','3','0',''),
('7','0','Terms of Use','Terms of Use','fa-file','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>Terms of Use</title>\r\n</head>\r\n\r\n<body>\r\n    <hr />\r\n    <div class=\"\">\r\n        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Cras sed felis eget velit aliquet sagittis id consectetur. Quis enim lobortis scelerisque fermentum dui faucibus in ornare quam. Semper feugiat nibh sed pulvinar. Dui accumsan sit amet nulla facilisi morbi tempus iaculis. Habitant morbi tristique senectus et. Sit amet nulla facilisi morbi tempus iaculis urna id volutpat. Tellus pellentesque eu tincidunt tortor. Ut ornare lectus sit amet est placerat. Metus aliquam eleifend mi in nulla posuere sollicitudin aliquam. Sit amet nisl purus in mollis. Et tortor at risus viverra adipiscing. Pellentesque id nibh tortor id aliquet lectus proin nibh nisl.</p>\r\n        <p>Varius quam quisque id diam vel quam elementum pulvinar etiam. Vel fringilla est ullamcorper eget nulla facilisi etiam dignissim. Felis eget nunc lobortis mattis aliquam. Sed faucibus turpis in eu mi bibendum neque. Quam vulputate dignissim suspendisse in est ante in. Blandit massa enim nec dui. Vestibulum mattis ullamcorper velit sed ullamcorper morbi tincidunt ornare. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Velit dignissim sodales ut eu sem integer vitae. Consectetur purus ut faucibus pulvinar elementum integer enim neque volutpat. Ac turpis egestas integer eget aliquet. Ut placerat orci nulla pellentesque. In arcu cursus euismod quis viverra nibh. Adipiscing elit pellentesque habitant morbi tristique senectus et netus et. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum arcu.</p>\r\n        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Cras sed felis eget velit aliquet sagittis id consectetur. Quis enim lobortis scelerisque fermentum dui faucibus in ornare quam. Semper feugiat nibh sed pulvinar. Dui accumsan sit amet nulla facilisi morbi tempus iaculis. Habitant morbi tristique senectus et. Sit amet nulla facilisi morbi tempus iaculis urna id volutpat. Tellus pellentesque eu tincidunt tortor. Ut ornare lectus sit amet est placerat. Metus aliquam eleifend mi in nulla posuere sollicitudin aliquam. Sit amet nisl purus in mollis. Et tortor at risus viverra adipiscing. Pellentesque id nibh tortor id aliquet lectus proin nibh nisl.</p>\r\n        <p>Varius quam quisque id diam vel quam elementum pulvinar etiam. Vel fringilla est ullamcorper eget nulla facilisi etiam dignissim. Felis eget nunc lobortis mattis aliquam. Sed faucibus turpis in eu mi bibendum neque. Quam vulputate dignissim suspendisse in est ante in. Blandit massa enim nec dui. Vestibulum mattis ullamcorper velit sed ullamcorper morbi tincidunt ornare. Penatibus et magnis dis parturient montes nascetur ridiculus mus. Velit dignissim sodales ut eu sem integer vitae. Consectetur purus ut faucibus pulvinar elementum integer enim neque volutpat. Ac turpis egestas integer eget aliquet. Ut placerat orci nulla pellentesque. In arcu cursus euismod quis viverra nibh. Adipiscing elit pellentesque habitant morbi tristique senectus et netus et. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum arcu.</p>\r\n    </div>\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,13,6,12,5,4','','4','0',''),
('10','11','Resources','','','','<!DOCTYPE html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>Resources</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n\r\n</head>\r\n\r\n<body>\r\n    <hr>\r\n    <div class=\"category-wrapper\">\r\n        <ul class=\"resource-grid\">\r\n            <li>\r\n                <a\r\n                    href=\"index.php?module=ext/ipages/view&id=18\">\r\n                    <h4>Health</h4>\r\n                    <img class=\"resource-thumb\"\r\n                    src=\"https://i.ibb.co/4YHmhhr/health2.jpg\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a\r\n                    href=\"index.php?module=ext/ipages/view&id=13\">\r\n                    <h4>Education</h4>\r\n                    <img class=\"resource-thumb\"\r\n                    src=\"https://i.ibb.co/v4Hrtgd/education.jpg\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a\r\n                    href=\"index.php?module=ext/ipages/view&id=14\">\r\n                    <h4>Housing</h4>\r\n                    <img class=\"resource-thumb\"\r\n                    src=\"https://i.ibb.co/PTDzZ1v/housing.jpg\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a\r\n                    href=\"index.php?module=ext/ipages/view&id=15\">\r\n                    <h4>Jobs</h4>\r\n                    <img class=\"resource-thumb\"\r\n                        src=\"https://i.ibb.co/fqpk9pr/jobs.jpg\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a\r\n                    href=\"index.php?module=ext/ipages/view&id=16\">\r\n                    <h4>Tips For Goals & Support</h4>\r\n                    <img class=\"resource-thumb\"\r\n                    src=\"https://i.ibb.co/FW8YTGb/goals.jpg\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a\r\n                    href=\"index.php?module=items/items&path=35\">\r\n                    <h4>Provider\'s Corner</h4>\r\n                    <img class=\"resource-thumb\"\r\n                    src=\"https://i.ibb.co/wsbXc5N/younglives.jpg\">\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','-1','0',''),
('11','0','Resources (Revamp)','','fa-folder','','','0,6,12,5,4','','0','1',''),
('13','29','Education','','','','<!DOCTYPE html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>Education</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n        href=\"index.php?module=ext/ipages/view&id=10\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr>\r\n    <div class=\"category-wrapper\">\r\n        <ul class=\"resource-grid\">\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=33\">\r\n                    <h4>My School</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=40\">\r\n                    <h4>Money</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=35\">\r\n                    <h4>Children\'s Learning</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('14','23','Housing','','','','<!DOCTYPE html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>Housing</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n        href=\"index.php?module=ext/ipages/view&id=10\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr>\r\n    <div class=\"category-wrapper\">\r\n        <ul class=\"resource-grid\">\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=24\">\r\n                    <h4>Emergency Shelter/Transitional Housing</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=27\">\r\n                    <h4>Rental</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=30\">\r\n                    <h4>Home Ownership</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=42\">\r\n                    <h4>Fair Housing Laws</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('15','11','Jobs','','','','','0,6,12,5,4','','0','0',''),
('16','11','Tips for Goals & Support','','','','','0,6,12,5,4','','0','0',''),
('18','19','Health','','','','<!DOCTYPE html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>Resources</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n        href=\"index.php?module=ext/ipages/view&id=10\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr>\r\n    <div class=\"category-wrapper\">\r\n        <ul class=\"resource-grid\">\r\n            <li>\r\n                <a href=\"#\">\r\n                    <h4>Nutrition</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"#\">\r\n                    <h4>Exercise & Sleep</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"#\">\r\n                    <h4>Focus on Diabetes & Hypertension</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=22\">\r\n                    <h4>Mental Health</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"#\">\r\n                    <h4>Vaccines & Other Safety</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a\r\n                    href=\"index.php?module=ext/ipages/view&id=20\">\r\n                    <h4>Focus on COVID-19</h4>\r\n                    <img class=\"resource-thumb\"\r\n                        src=\"https://images.unsplash.com/photo-1584634731339-252c581abfc5?ixid=MXwxMjA3fDB8MHxzZWFyY2h8MXx8bWFza3xlbnwwfHwwfA%3D%3D&ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=60\">\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('19','11','Health','','fa-folder-o','','','0,6,12,5,4','','0','1',''),
('20','19','COVID','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n    <title>Terms of Use</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n        href=\"index.php?module=ext/ipages/view&id=18\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 First Point Header</a>\r\n                    <ul>\r\n                        <li><a href=\"#First_Sub_Point_1\">1.1 First Sub Point 1</a></li>\r\n                        <li><a href=\"#First_Sub_Point_2\">1.2 First Sub Point 2</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li><a href=\"#Second_Point_Header\">2 Second Point Header</a></li>\r\n                <li><a href=\"#Third_Point_Header\">3 Third Point Header</a></li>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n\r\n        <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n        <h5>Importance of Mental Health</h5>\r\n        <p>Overall, well-being involves having a healthy body and a\r\n        healthy state of mind. Taking care of your mental health can\r\n        lead to less feelings of anxiety and stress and higher levels of\r\n        self-esteem and confidence. Allowing yourself to feel what you\r\n        feel, actively choosing healthy foods over less healthy\r\n        alternatives, and sleeping well are some strategies that can\r\n        help you feel better and improve your state of mind. Below are a\r\n        few more strategies that could also improve your mental health\r\n        and reduce stress. \r\n        </p>\r\n\r\n        <div id=\"First_Sub_Point_1\" class=\"anchor\"></div>\r\n        <div class=\"subheading\">\r\n        <h5>1.1 First Sub Point 1</h5>\r\n        <p>Varius quam quisque id diam vel quam elementum pulvinar etiam. Vel fringilla est ullamcorper eget nulla\r\n            facilisi etiam dignissim. Felis eget nunc lobortis mattis aliquam. Sed faucibus turpis in eu mi bibendum\r\n            neque. Quam vulputate dignissim suspendisse in est ante in. Blandit massa enim nec dui. Vestibulum mattis\r\n            ullamcorper velit sed ullamcorper morbi tincidunt ornare. Penatibus et magnis dis parturient montes nascetur\r\n            ridiculus mus. Velit dignissim sodales ut eu sem integer vitae. Consectetur purus ut faucibus pulvinar\r\n            elementum integer enim neque volutpat. Ac turpis egestas integer eget aliquet. Ut placerat orci nulla\r\n            pellentesque. In arcu cursus euismod quis viverra nibh. Adipiscing elit pellentesque habitant morbi\r\n            tristique senectus et netus et. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum arcu.\r\n        </p>\r\n        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore\r\n            magna aliqua. Cras sed felis eget velit aliquet sagittis id consectetur. Quis enim lobortis scelerisque\r\n            fermentum dui faucibus in ornare quam. Semper feugiat nibh sed pulvinar. Dui accumsan sit amet nulla\r\n            facilisi morbi tempus iaculis. Habitant morbi tristique senectus et. Sit amet nulla facilisi morbi tempus\r\n            iaculis urna id volutpat. Tellus pellentesque eu tincidunt tortor. Ut ornare lectus sit amet est placerat.\r\n            Metus aliquam eleifend mi in nulla posuere sollicitudin aliquam. Sit amet nisl purus in mollis. Et tortor at\r\n            risus viverra adipiscing. Pellentesque id nibh tortor id aliquet lectus proin nibh nisl.</p>\r\n\r\n        <div id=\"First_Sub_Point_2\" class=\"anchor\"></div>\r\n        <h5>1.2 First Sub Point 2</h5>\r\n        <p>Varius quam quisque id diam vel quam elementum pulvinar etiam. Vel fringilla est ullamcorper eget nulla\r\n            facilisi etiam dignissim. Felis eget nunc lobortis mattis aliquam. Sed faucibus turpis in eu mi bibendum\r\n            neque. Quam vulputate dignissim suspendisse in est ante in. Blandit massa enim nec dui. Vestibulum mattis\r\n            ullamcorper velit sed ullamcorper morbi tincidunt ornare. Penatibus et magnis dis parturient montes nascetur\r\n            ridiculus mus. Velit dignissim sodales ut eu sem integer vitae. Consectetur purus ut faucibus pulvinar\r\n            elementum integer enim neque volutpat. Ac turpis egestas integer eget aliquet. Ut placerat orci nulla\r\n            pellentesque. In arcu cursus euismod quis viverra nibh. Adipiscing elit pellentesque habitant morbi\r\n            tristique senectus et netus et. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum arcu.\r\n        </p>\r\n        </div>\r\n\r\n        <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n        <h5>2 Second Point Header</h5>\r\n        <p>Varius quam quisque id diam vel quam elementum pulvinar etiam. Vel fringilla est ullamcorper eget nulla\r\n            facilisi etiam dignissim. Felis eget nunc lobortis mattis aliquam. Sed faucibus turpis in eu mi bibendum\r\n            neque. Quam vulputate dignissim suspendisse in est ante in. Blandit massa enim nec dui. Vestibulum mattis\r\n            ullamcorper velit sed ullamcorper morbi tincidunt ornare. Penatibus et magnis dis parturient montes nascetur\r\n            ridiculus mus. Velit dignissim sodales ut eu sem integer vitae. Consectetur purus ut faucibus pulvinar\r\n            elementum integer enim neque volutpat. Ac turpis egestas integer eget aliquet. Ut placerat orci nulla\r\n            pellentesque. In arcu cursus euismod quis viverra nibh. Adipiscing elit pellentesque habitant morbi\r\n            tristique senectus et netus et. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum arcu.\r\n        </p>\r\n        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore\r\n            magna aliqua. Cras sed felis eget velit aliquet sagittis id consectetur. Quis enim lobortis scelerisque\r\n            fermentum dui faucibus in ornare quam. Semper feugiat nibh sed pulvinar. Dui accumsan sit amet nulla\r\n            facilisi morbi tempus iaculis. Habitant morbi tristique senectus et. Sit amet nulla facilisi morbi tempus\r\n            iaculis urna id volutpat. Tellus pellentesque eu tincidunt tortor. Ut ornare lectus sit amet est placerat.\r\n            Metus aliquam eleifend mi in nulla posuere sollicitudin aliquam. Sit amet nisl purus in mollis. Et tortor at\r\n            risus viverra adipiscing. Pellentesque id nibh tortor id aliquet lectus proin nibh nisl.</p>\r\n\r\n        <div id=\"Third_Point_Header\" class=\"anchor\"></div>\r\n        <h5>3 Third Point Header</h5>\r\n        <p>Varius quam quisque id diam vel quam elementum pulvinar etiam. Vel fringilla est ullamcorper eget nulla\r\n            facilisi etiam dignissim. Felis eget nunc lobortis mattis aliquam. Sed faucibus turpis in eu mi bibendum\r\n            neque. Quam vulputate dignissim suspendisse in est ante in. Blandit massa enim nec dui. Vestibulum mattis\r\n            ullamcorper velit sed ullamcorper morbi tincidunt ornare. Penatibus et magnis dis parturient montes nascetur\r\n            ridiculus mus. Velit dignissim sodales ut eu sem integer vitae. Consectetur purus ut faucibus pulvinar\r\n            elementum integer enim neque volutpat. Ac turpis egestas integer eget aliquet. Ut placerat orci nulla\r\n            pellentesque. In arcu cursus euismod quis viverra nibh. Adipiscing elit pellentesque habitant morbi\r\n            tristique senectus et netus et. Donec pretium vulputate sapien nec sagittis aliquam malesuada bibendum arcu.\r\n        </p>\r\n        <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore\r\n            magna aliqua. Cras sed felis eget velit aliquet sagittis id consectetur. Quis enim lobortis scelerisque\r\n            fermentum dui faucibus in ornare quam. Semper feugiat nibh sed pulvinar. Dui accumsan sit amet nulla\r\n            facilisi morbi tempus iaculis. Habitant morbi tristique senectus et. Sit amet nulla facilisi morbi tempus\r\n            iaculis urna id volutpat. Tellus pellentesque eu tincidunt tortor. Ut ornare lectus sit amet est placerat.\r\n            Metus aliquam eleifend mi in nulla posuere sollicitudin aliquam. Sit amet nisl purus in mollis. Et tortor at\r\n            risus viverra adipiscing. Pellentesque id nibh tortor id aliquet lectus proin nibh nisl.</p>\r\n\r\n    </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('21','19','Teens & Young Adults','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Teens & Young Adults</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=22\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 Importance of Mental\r\n                Health</a>\r\n                <li><a href=\"#Second_Point_Header\">2 Self-Care\r\n                Strategies</a>\r\n                    <ul>\r\n                        <li><a href=\"#Second_Sub_Point_1\">2.1 Getting\r\n                        the right amount of sleep</a></li>\r\n                        <li><a href=\"#Second_Sub_Point_2\">2.2 Getting\r\n                        the right kind of nutrition</a></li>\r\n                        <li><a href=\"#Second_Sub_Point_3\">2.3\r\n                        Exercising</a></li>\r\n                        <li><a href=\"#Second_Sub_Point_4\">2.4 Living a\r\n                        Balanced Life</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li><a href=\"#Third_Point_Header\">3 Mindfulness\r\n                Strategies</a>\r\n                    <ul>\r\n                        <li><a href=\"#Third_Sub_Point_1\">3.1 Breathing\r\n                        exercises</a></li>\r\n                        <li><a href=\"#Third_Sub_Point_2\">3.2 Move\r\n                        around</a></li>\r\n                        <li><a href=\"#Third_Sub_Point_3\">3.3 Let\r\n                        yourself feel what you feel</a></li>\r\n                        <li><a href=\"#Third_Sub_Point_4\">3.4 List things\r\n                        you’re grateful for</a></li>\r\n                        <li><a href=\"#Third_Sub_Point_5\">3.5 Make lists\r\n                        and schedules to prioritize activities</a></li>\r\n                        <li><a href=\"#Third_Sub_Point_6\">3.6\r\n                        Meditate</a></li>\r\n                        <li><a href=\"#Third_Sub_Point_7\">3.7 Talk to a\r\n                        trusted friend, family member, or\r\n                        professional</a></li>\r\n                        <li><a href=\"#Third_Sub_Point_8\">3.8 Call a\r\n                        National Suicide Prevention Lifeline</a></li>\r\n\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n\r\n            <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Importance of Mental Health</h5>\r\n            <p>Taking care of your body is an important part of taking\r\n            care of your mental health. Not getting the right amount of\r\n            nutrition, sleep, or exercise can lead to feelings of\r\n            fatigue, irritability, stress, less efficiency, numbness, or\r\n            even apathy. Below are a few more strategies that could\r\n            improve your physical health, improve your mental health,\r\n            and reduce your stress. \r\n            </p>\r\n\r\n            <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Self-Care Strategies</h5>\r\n            <p>Overall, well-being involves having a healthy body and a\r\n            healthy state of mind. Taking care of your mental health can\r\n            lead to less feelings of anxiety and stress and higher\r\n            levels of self-esteem and confidence. Allowing yourself to\r\n            feel what you feel, actively choosing healthy foods over\r\n            less healthy alternatives, and sleeping well are some\r\n            strategies that can help you feel better and improve your\r\n            state of mind. Below are a few more strategies that could\r\n            also improve your mental health and reduce stress. \r\n            </p>\r\n\r\n                <div class=\"subheading\">\r\n\r\n                    <div id=\"Second_Sub_Point_1\" class=\"anchor\"></div>\r\n                    <h5>1) Getting the right amount of sleep</h5>\r\n                    <p>It is recommended that you get between 9 to 9.5\r\n                    hours of sleep every night. Depending on your body\r\n                    and your circumstances, that number might vary\r\n                    slightly. What matters most is that you’re sleeping\r\n                    enough without waking up with feelings of fatigue,\r\n                    headaches, or general tiredness. Getting enough\r\n                    sleep for you will improve your learning,\r\n                    concentration, memory, mood, attitude, energy,\r\n                    digestion, and heart health. \r\n                    </p>\r\n                    \r\n                    <div id=\"Second_Sub_Point_2\" class=\"anchor\"></div>\r\n                    <h5>2) Getting the right kind of nutrition</h5>\r\n                    <p>Getting the right kind and amount of nutrition\r\n                    for your body can lead to improved physical and\r\n                    emotional health. The best nutrition for you depends\r\n                    on your body and lifestyle. Exercise often? You may\r\n                    benefit from a diet with more protein. Vegetarian or\r\n                    vegan? You may benefit from foods supplemented with\r\n                    nutrients vegetarians or vegans find harder to get\r\n                    (such as vitamin B12 and vitamin D). Regardless of\r\n                    your lifestyle and circumstances, all diets benefit\r\n                    from finding balance: getting good amounts of\r\n                    fruits, veggies, and protein while limiting caffeine\r\n                    and sugar. \r\n                    <br>\r\n                    <a href=\"#insertnutrition\" target=\"_blank\">Hyperlink\r\n                    to more nutrition resources</a>\r\n                    </p>\r\n                    \r\n                    <div id=\"Second_Sub_Point_3\" class=\"anchor\"></div>\r\n                    <h5>3) Exercise</h5>\r\n                    <p>Just like your body needs rest and relaxation to\r\n                    repair itself, your body also needs to be used\r\n                    regularly to work as efficiently as it can.\r\n                    Exercising works your muscles, your heart, and your\r\n                    lungs when you do it for a period of time (known as\r\n                    “cardio”). Exercising can also strengthen your\r\n                    bones, make your brain work more efficiently, and\r\n                    improve your energy levels and stamina. By releasing\r\n                    “feel good” hormones known as endorphins, exercise\r\n                    can improve your mood, reduce stress, and take your\r\n                    mind off of your problems. Working out as many\r\n                    different parts of your body regularly and\r\n                    consistently (for 20-30 minutes several times every\r\n                    week), can help you feel the benefits of exercising\r\n                    for your physical and mental health.\r\n                    </p>\r\n\r\n                    <div id=\"Second_Sub_Point_4\" class=\"anchor\"></div>\r\n                    <h5>4) Living a Balanced Life</h5>\r\n                    <p>If you’re feeling overwhelmed by a particular\r\n                    aspect of your life (whether that’s school, work, or\r\n                    anything in between), it can be helpful to find\r\n                    balance. Making time for yourself, whether that’s\r\n                    through a hobby, an activity, or simply relaxing,\r\n                    can help reduce your stress. Being productive is\r\n                    important, but taking care of yourself and your\r\n                    needs is important as well. It could be helpful to\r\n                    schedule a section of your day or week as “me-time”,\r\n                    taking a few naps when tired, or safely spending\r\n                    time with friends and family. Find what brings you\r\n                    joy and pursue it every so often. Using an online\r\n                    scheduling platform (such as Google Calendar), can\r\n                    help you organize all your activities and\r\n                    responsibilities as well.\r\n                    </p>\r\n\r\n                </div>\r\n\r\n            <div id=\"Third_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Mindfulness Strategies</h5>\r\n            <p>The following strategies can help reduce your stress,\r\n            feel less overwhelmed, and improve your mental health.\r\n            </p>\r\n            <div class=\"subheading\">\r\n            <div id=\"Third_Sub_Point_1\" class=\"anchor\"></div>\r\n                    <h5>1) Breathing exercises </h5>\r\n                    <p>Studies have shown that slowing our breathing or\r\n                    doing breathing exercises in times of stress can\r\n                    help you relax, cope with stress, and make more\r\n                    thoughtful, rational decisions. Start by stepping\r\n                    away from the situation and taking a deep breath\r\n                    when you feel anxious or overwhelmed. Begin with a\r\n                    normal breath. Then try a deep breath. Breathe in\r\n                    slowly through your nose, letting your chest and\r\n                    lower belly rise as you fill your lungs and letting\r\n                    your abdomen expand fully. Now breathe slowly\r\n                    through your mouth or nose, whichever feels more\r\n                    comfortable for you. Focus your thoughts and energy\r\n                    on your breathing instead of what’s stressing you\r\n                    out. You can do this by timing your breathing\r\n                    (counting to 3 every time you breathe in and to 3\r\n                    every time you breathe out). Focus on your counting\r\n                    until you feel less overwhelmed by the situation.\r\n                    Don’t rush yourself, and allow yourself to feel what\r\n                    you feel. Sometimes you’ll feel less stressed in a\r\n                    few seconds, other times it can take minutes.\r\n                    Everybody’s stress is different and equally valid. \r\n                    </p>\r\n\r\n                    <div id=\"Third_Sub_Point_2\" class=\"anchor\"></div>\r\n                    <h5>2) Move around</h5>\r\n                    <p>The simple acts of getting up, getting out, and\r\n                    moving your body around has been scientifically\r\n                    proven to reduce stress and improve our perspective.\r\n                    In a moment of anxiety, stress, or anger, it can be\r\n                    hard to think clearly. Physically removing yourself\r\n                    from the stressful situation, maybe by going for a\r\n                    walk, can help you breathe, collect your thoughts,\r\n                    and reduce feelings of anxiety. While you move\r\n                    around, you can try counting (counting to 3 every\r\n                    time you breathe in and to 3 every time you breathe\r\n                    out), to help you shift your energy and thoughts\r\n                    away from the stressful circumstance. \r\n                    </p>\r\n\r\n                    <div id=\"Third_Sub_Point_3\" class=\"anchor\"></div>\r\n                    <h5>3) Let yourself feel what you feel</h5>\r\n                    <p>Allow yourself to feel whatever you’re feeling,\r\n                    whether that’s sadness or frustration. Your feelings\r\n                    are valid, even when they seem irrational. Let\r\n                    yourself cry or mourn, and don’t let your feelings\r\n                    bottle up inside. If you feel safe doing so, you can\r\n                    try talking about your feelings with a trusted\r\n                    friend, family member, or even a professional. Talk\r\n                    through your emotions, your experiences, and your\r\n                    worries. If you don’t feel comfortable sharing your\r\n                    emotions, don’t rush yourself. Everybody’s mental\r\n                    health journey is different. You could try writing\r\n                    what you’re feeling in a private journal, or\r\n                    expressing yourself indirectly through art, poetry,\r\n                    or creativity. Find an outlet that lets you express\r\n                    your emotions in a safe, healthy, and supportive\r\n                    way. \r\n                    </p>\r\n\r\n                    <div id=\"Third_Sub_Point_4\" class=\"anchor\"></div>\r\n                    <h5>4) List things you\'re grateful for</h5>\r\n                    <p>Remembering things you’re grateful for can help\r\n                    shift your thoughts from what’s stressing you out to\r\n                    what brings you joy. An easy way to get started is\r\n                    to keep a Gratitude Journal. You can use an actual\r\n                    journal, a writing pad, or the notes app in your\r\n                    phone or tablet. If you’re feeling stressed or\r\n                    overwhelmed, pull out your list of things that\r\n                    you’re grateful for to remind yourself of the joy in\r\n                    your life. \r\n                    </p>\r\n\r\n                    <div id=\"Third_Sub_Point_5\" class=\"anchor\"></div>\r\n                    <h5>5) Make lists and schedules to prioritize\r\n                    activities</h5>\r\n                    <p>If you’re feeling overwhelmed or like you have a\r\n                    lot of things to do, it can be helpful to visualize\r\n                    your tasks and write them down in a concrete list.\r\n                    You can use an agenda or an online scheduling tool\r\n                    (such as Google Calendar). Making a list of the\r\n                    things you need to do for the day, or keeping track\r\n                    of tasks in a concrete schedule, can help reduce\r\n                    feelings of panic or anxiety. If thoughts of panic\r\n                    and anxiety start to swirl around, and the things\r\n                    you have to do start to seem impossible, look at\r\n                    your list and focus on what’s written down. Thoughts\r\n                    can sometimes make even simple tasks seem\r\n                    complicated. \r\n                    </p>\r\n                \r\n                    <div id=\"Third_Sub_Point_6\" class=\"anchor\"></div>\r\n                    <h5>6) Meditate</h5>\r\n                    <ol>\r\n                        <li>Find a spot to sit (or lie) comfortably</li>\r\n                        <li>Close your eyes</li>\r\n                        <li>Breathe naturally. Try not to control your\r\n                        breathing.</li>\r\n                        <li>Spend 3-5 minutes focusing on your breath\r\n                        and how your body moves as you inhale and\r\n                        exhale.</li>\r\n                        <li>If you mind wanders, return your focus back\r\n                        to your breath/body movements.</li>\r\n                    </ol>\r\n\r\n                    <div id=\"Third_Sub_Point_7\" class=\"anchor\"></div>\r\n                    <h5>7) Talk to a trusted friend, family member, or\r\n                    professional\r\n                    </h5>\r\n                    <p>Anxiety, stress, and frustration can make you\r\n                    feel alone or isolated. In times of loneliness, it\r\n                    can be helpful to talk about your feelings with a\r\n                    trusted friend, family member, or a licensed\r\n                    professional. Doing so can give you a new\r\n                    perspective on the situation and help you feel less\r\n                    lonely. In any conversation you have, make sure your\r\n                    feelings are respected, understood, and heard. Your\r\n                    feelings are not “your fault” or the result of any\r\n                    of your actions, and it’s important that your\r\n                    conversation reflects that, that you feel safe,\r\n                    supported, and understood. \r\n                    </p>\r\n\r\n                    <div id=\"Third_Sub_Point_8\" class=\"anchor\"></div>\r\n                    <h5>8) Call a National Suicide Prevention Lifeline\r\n                    </h5>\r\n                    <ul>\r\n                        <li>If you’re thinking about suicide, are\r\n                        worried about a friend or loved one, or would\r\n                        like somebody to talk to about your emotions and\r\n                        experiences, it might be helpful to call the\r\n                        Lifeline network (available 24/7 across the\r\n                        United States at 1-800-272-8255). These\r\n                        lifelines are a good option if you don’t feel\r\n                        comfortable sharing your emotions with friends\r\n                        or family members. </li>\r\n                        <li>In any conversation you have, make sure your\r\n                        feelings are respected, understood, and heard.\r\n                        Your feelings are not “your fault” or the result\r\n                        of any of your actions, and it’s important that\r\n                        your conversation reflects that. It’s important\r\n                        that you feel safe, supported, and understood. \r\n                        </li>\r\n                        <li>Every call is answered by a different\r\n                        volunteer, so if one call doesn’t go well,\r\n                        another one might be more fulfilling. \r\n                        </li>\r\n                    </ul>\r\n                </div>\r\n                <p>Information from:\r\n                <br>\r\n                <a\r\n                href=\"https://www.commonlit.org/en/texts/self-care\">https://www.commonlit.org/en/texts/self-care</a>\r\n                <br>\r\n                <a\r\n                href=\"https://www.jedfoundatin.org/covid-19-resource-guide-for-students-teens-young-adults/\">https://www.jedfoundatin.org/covid-19-resource-guide-for-students-teens-young-adults/</a></p>\r\n                   \r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('22','19','Mental Health','','','','<!DOCTYPE html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>Mental Health</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n        href=\"index.php?module=ext/ipages/view&id=18\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr>\r\n    <div class=\"category-wrapper\">\r\n        <ul class=\"resource-grid\">\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=21\">\r\n                    <h4>Teens & Young Adults</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=25\">\r\n                    <h4>Other Adults</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"#\">\r\n                    <h4>Children</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('23','11','Housing','','fa-folder-o','','','0,6,12,5,4','','0','1',''),
('24','23','Emergency Shelter/Transitional Housing','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Emergency</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=14\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 Examples of\r\n                Emergency Shelters</a>\r\n                    <ul>\r\n                        <li><a href=\"#First_Sub_Point_1\">1.1\r\n                        Congregations</a></li>\r\n                        <li><a href=\"#First_Sub_Point_2\">1.2 Volunteer\r\n                        Groups</a></li>\r\n                        <li><a href=\"#First_Sub_Point_3\">1.3 Traditional\r\n                        Shelter</a></li>\r\n                    </ul>\r\n                <li><a href=\"#Second_Point_Header\">2 Transitional\r\n                Housing</a>\r\n                    \r\n                </li>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n\r\n        <p>In times of natural disaster, economic stress, or job\r\n        insecurity, there are several, supportive resources you can use\r\n        to find emergency shelter for you and your family.</p>\r\n\r\n        <p>Whichever shelter you choose depends on your needs, your\r\n        location, and the organization’s availability. Look through the\r\n        different kinds of emergency shelters and transitional housing\r\n        options before making a final residency decision. To find out\r\n        about the availability of a specific group, many volunteer\r\n        groups have crisis and support hotlines readily available on\r\n        their websites.\r\n        </p>\r\n\r\n            <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Examples of Emergency Shelters</h5>\r\n            <div class=\"subheading\">\r\n\r\n                <div id=\"First_Sub_Point_1\" class=\"anchor\"></div>\r\n                <h5>Congregations</h5>\r\n                <p>Churches often open their doors to families and\r\n                individuals seeking emergency shelter through\r\n                congregations. Several congregations focus their\r\n                programs on helping people transition from homelessness\r\n                to permanent housing. Many programs also offer access to\r\n                mentors, ministers, and counselors for advice on seeking\r\n                employment, resume coaching, or financial management.\r\n                Most congregations don’t require you to have any\r\n                particular religious affiliation.\r\n                </p>\r\n                \r\n                <div id=\"First_Sub_Point_2\" class=\"anchor\"></div>\r\n                <h5>Volunteer Groups</h5>\r\n                <p>There are several non-profit organizations that offer\r\n                emergency shelter for those in need. Some groups even\r\n                offer additional services, such as soup kitchens,\r\n                counseling services, rehab, and more. Some groups focus\r\n                on the needs of particular groups, such as children or\r\n                veterans. \r\n                </p>\r\n                \r\n                <div id=\"First_Sub_Point_3\" class=\"anchor\"></div>\r\n                <h5>Traditional Shelter</h5>\r\n                <p>Traditional shelters often provide emergency shelter,\r\n                along with services such as rehab, soup kitchens, and\r\n                alcohol treatment. Some of these shelters are government\r\n                run, while others are run by volunteer groups. \r\n                </p>\r\n\r\n            </div>\r\n       \r\n            <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Transitional Housing</h5>\r\n            <ul>\r\n                <li>Transitional housing facilities provide housing for\r\n                those transitioning out of homelessness. Oftentimes,\r\n                it’s the step between the more short-term emergency\r\n                shelter options described above and permanent housing. \r\n                </li>\r\n                <li>Many transitional housing programs are time-limited;\r\n                for example, some only provide shelter for 1 or 2 years.\r\n                In this time, these programs often require you to either\r\n                find permanent housing or some form of permanent\r\n                employment. \r\n                </li>\r\n                <li>These programs can charge a boarding fee, which is\r\n                oftentimes fully refunded after you find a permanent\r\n                place to live. </li>\r\n                <li>Many transitional housing facilities offer support,\r\n                rehab, educational programs, life skill training, and\r\n                other services to help you find permanent housing.</li>\r\n            </ul>\r\n            </div>\r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('25','19','Other Adults','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha684-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d6Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Mental Health (Adults)</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=22\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 What is mental illness?\r\n                </a>\r\n                <li><a href=\"#Second_Point_Header\">2 What causes mental illness?\r\n                </a>\r\n                <li><a href=\"#Third_Point_Header\">3 How common is mental illness?\r\n                </a>\r\n                <li><a href=\"#Fourth_Point_Header\">4 Importance of Mental Health\r\n                </a>\r\n                <li><a href=\"#Fifth_Point_Header\">5 Self-Care\r\n                Strategies</a>\r\n                    <ul>\r\n                        <li><a href=\"#Fifth_Sub_Point_1\">5.1 Getting\r\n                        the right amount of sleep</a></li>\r\n                        <li><a href=\"#Fifth_Sub_Point_2\">5.2 Getting\r\n                        the right kind of nutrition</a></li>\r\n                        <li><a href=\"#Fifth_Sub_Point_3\">5.3\r\n                        Exercising</a></li>\r\n                        <li><a href=\"#Fifth_Sub_Point_4\">5.4 Looking after your health</a></li>\r\n                        <li><a href=\"#Fifth_Sub_Point_5\">5.5 Living a Balanced Life</a></li>\r\n                    </ul>\r\n                </li>\r\n                <li><a href=\"#Sixth_Point_Header\">6 Mindfulness\r\n                Strategies</a>\r\n                    <ul>\r\n                        <li><a href=\"#Sixth_Sub_Point_1\">6.1 Breathing\r\n                        exercises</a></li>\r\n                        <li><a href=\"#Sixth_Sub_Point_2\">6.2 Move\r\n                        around</a></li>\r\n                        <li><a href=\"#Sixth_Sub_Point_3\">6.3 Let\r\n                        yourself feel what you feel</a></li>\r\n                        <li><a href=\"#Sixth_Sub_Point_4\">6.4 List things\r\n                        you’re grateful for</a></li>\r\n                        <li><a href=\"#Sixth_Sub_Point_5\">6.5 Make lists\r\n                        and schedules to prioritize activities</a></li>\r\n                        <li><a href=\"#Sixth_Sub_Point_6\">6.6\r\n                        Meditate</a></li>\r\n                        <li><a href=\"#Sixth_Sub_Point_7\">6.7 Talk to a\r\n                        trusted friend, family member, or\r\n                        professional</a></li>\r\n                        <li><a href=\"#Sixth_Sub_Point_8\">6.8 Call a\r\n                        National Suicide Prevention Lifeline</a></li>\r\n\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n        <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n        <h5>What is mental illness?</h5>\r\n        <p>Mental illnesses are conditions that affect a person’s\r\n        thinking, feeling, mood or behavior. Examples of mental\r\n        illnesses include depression, anxiety, bipolar disorder,\r\n        schizophrenia, etc. Such conditions may be non-recurring or more\r\n        long-lasting (chronic), and they can affect a person’s ability\r\n        to relate to others, handle stress, and make healthy decisions\r\n        about their life and well-being. \r\n        </p>\r\n\r\n        <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n        <h5>What causes mental illness?</h5>\r\n        <p>There is no single cause for mental illness. A number of\r\n        factors can increase the risk of having a mental illness,\r\n        including but not limited to\r\n            <ul>   \r\n                <li>Early adverse life experiences, such as trauma or a\r\n                history of abuse (for example, child abuse, sexual\r\n                assault, witnessing violence, etc) </li>\r\n                <li>Experiences related to other ongoing (chronic)\r\n                medical conditions, such as cancer or diabetes. \r\n                </li>\r\n                <li>Biological factors, such as genes or chemical\r\n                imbalances in the brain\r\n                </li>\r\n                <li>Use of alcohol or recreational drugs\r\n                </li>\r\n                <li>Feelings of loneliness or isolation</li>\r\n                </ul>\r\n        </p>\r\n\r\n            <div id=\"Third_Point_Header\" class=\"anchor\"></div>\r\n            <h5>How common is mental illness?</h5>\r\n            <p>Mental illnesses are among the most common health\r\n            conditions in the United States. \r\n                <ul>   \r\n                    <li>More than 50% of Americans will be diagnosed\r\n                    with a mental illness or disorder at some point in\r\n                    their lives. </li>\r\n                    <li>1 in 5 Americans will experience a mental\r\n                    illness in a given year.</li>\r\n                    <li>1 in 5 children, either currently or at some\r\n                    point during their lives, have had a seriously\r\n                    debilitating mental illness.</li>\r\n                    <li>1 in 25 Americans lives with a serious mental\r\n                    illness, such as schizophrenia, bipolar disorder, or\r\n                    major depression.</li>\r\n                   While a mental illness can feel isolating or lonely,\r\n                   it is important to understand that you are not alone\r\n                   in your experiences. Millions of Americans deal with\r\n                   different kinds of mental illnesses throughout their\r\n                   lifetimes. Seeking support and guidance can help you\r\n                   make sense of your thoughts and emotions and lead a\r\n                   more fulfilling life. \r\n                    </ul>\r\n            </p>\r\n\r\n            <div id=\"Fourth_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Importance of Mental Health</h5>\r\n            <p>Overall, well-being involves having a healthy body and a\r\n            healthy state of mind. Taking care of your mental health can\r\n            lead to less feelings of anxiety and stress and higher\r\n            levels of self-esteem and confidence. Allowing yourself to\r\n            feel what you feel, actively choosing healthy foods over\r\n            less healthy alternatives, and sleeping well are some\r\n            strategies that can help you feel better and improve your\r\n            state of mind. Below are a few more strategies that could\r\n            also improve your mental health and reduce stress. \r\n            </p>\r\n\r\n            <div id=\"Fifth_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Self-Care Strategies</h5>\r\n            <p>Overall, well-being involves having a healthy body and a\r\n            healthy state of mind. Taking care of your mental health can\r\n            lead to less feelings of anxiety and stress and higher\r\n            levels of self-esteem and confidence. Allowing yourself to\r\n            feel what you feel, actively choosing healthy foods over\r\n            less healthy alternatives, and sleeping well are some\r\n            strategies that can help you feel better and improve your\r\n            state of mind. Below are a few more strategies that could\r\n            also improve your mental health and reduce stress. \r\n            </p>\r\n\r\n                <div class=\"subheading\">\r\n\r\n                    <div id=\"Fifth_Sub_Point_1\" class=\"anchor\"></div>\r\n                    <h5>1) Getting the right amount of sleep</h5>\r\n                    <p>It is recommended that you get between 9 to 9.5\r\n                    hours of sleep every night. Depending on your body\r\n                    and your circumstances, that number might vary\r\n                    slightly. What matters most is that you’re sleeping\r\n                    enough without waking up with feelings of fatigue,\r\n                    headaches, or general tiredness. Getting enough\r\n                    sleep for you will improve your learning,\r\n                    concentration, memory, mood, attitude, energy,\r\n                    digestion, and heart health. \r\n                    </p>\r\n                    \r\n                    <div id=\"Fifth_Sub_Point_2\" class=\"anchor\"></div>\r\n                    <h5>2) Getting the right kind of nutrition</h5>\r\n                    <p>Getting the right kind and amount of nutrition\r\n                    for your body can lead to improved physical and\r\n                    emotional health. The best nutrition for you depends\r\n                    on your body and lifestyle. Exercise often? You may\r\n                    benefit from a diet with more protein. Vegetarian or\r\n                    vegan? You may benefit from foods supplemented with\r\n                    nutrients vegetarians or vegans find harder to get\r\n                    (such as vitamin B12 and vitamin D). Regardless of\r\n                    your lifestyle and circumstances, all diets benefit\r\n                    from finding balance: getting good amounts of\r\n                    fruits, veggies, and protein while limiting caffeine\r\n                    and sugar. \r\n                    <a href=\"#\">Hyperlink to more nutrition\r\n                    resources</a>\r\n                    </p>\r\n                    \r\n                    <div id=\"Fifth_Sub_Point_3\" class=\"anchor\"></div>\r\n                    <h5>3) Exercising</h5>\r\n                    <p>Just like your body needs rest and relaxation to\r\n                    repair itself, your body also needs to be used\r\n                    regularly to work as efficiently as it can.\r\n                    Exercising works your muscles, your heart, and your\r\n                    lungs when you do it for a period of time (known as\r\n                    “cardio”). Exercising can also strengthen your\r\n                    bones, make your brain work more efficiently, and\r\n                    improve your energy levels and stamina. By releasing\r\n                    “feel good” hormones known as endorphins, exercise\r\n                    can improve your mood, reduce stress, and take your\r\n                    mind off of your problems. Working out as many\r\n                    different parts of your body regularly and\r\n                    consistently (for 20-60 minutes several times every\r\n                    week), can help you feel the benefits of exercising\r\n                    for your physical and mental health.\r\n                    </p>\r\n\r\n\r\n                    <div id=\"Fifth_Sub_Point_4\" class=\"anchor\"></div>\r\n                    <h5>4) Look after your health</h5>\r\n                    <p>As you get older, mental illness can lead to\r\n                    other physical conditions, such as heart disease,\r\n                    stroke, and diabetes. Looking after your mental\r\n                    health indirectly looks after your physical health.\r\n                    The two are tied and equally important. \r\n                    </p>\r\n\r\n                    <div id=\"Fifth_Sub_Point_5\" class=\"anchor\"></div>\r\n                    <h5>5) Living a Balanced Life</h5>\r\n                    <p>If you’re feeling overwhelmed by a particular\r\n                    aspect of your life (whether that’s school, work, or\r\n                    anything in between), it can be helpful to find\r\n                    balance. Making time for yourself, whether that’s\r\n                    through a hobby, an activity, or simply relaxing,\r\n                    can help reduce your stress. Being productive is\r\n                    important, but taking care of yourself and your\r\n                    needs is important as well. It could be helpful to\r\n                    schedule a section of your day or week as “me-time”,\r\n                    taking a few naps when tired, or safely spending\r\n                    time with friends and family. Find what brings you\r\n                    joy and pursue it every so often. Using an online\r\n                    scheduling platform (such as Google Calendar), can\r\n                    help you organize all your activities and\r\n                    responsibilities as well.\r\n                    </p>\r\n\r\n                </div>\r\n\r\n            <div id=\"Sixth_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Mindfulness Strategies</h5>\r\n            <p>The following strategies can help reduce your stress,\r\n            feel less overwhelmed, and improve your mental health.\r\n            </p>\r\n            <div class=\"subheading\">\r\n            <div id=\"Sixth_Sub_Point_1\" class=\"anchor\"></div>\r\n                    <h5>1) Breathing exercises </h5>\r\n                    <p>Studies have shown that slowing our breathing or\r\n                    doing breathing exercises in times of stress can\r\n                    help you relax, cope with stress, and make more\r\n                    thoughtful, rational decisions. Start by stepping\r\n                    away from the situation and taking a deep breath\r\n                    when you feel anxious or overwhelmed. Begin with a\r\n                    normal breath. Then try a deep breath. Breathe in\r\n                    slowly through your nose, letting your chest and\r\n                    lower belly rise as you fill your lungs and letting\r\n                    your abdomen expand fully. Now breathe slowly\r\n                    through your mouth or nose, whichever feels more\r\n                    comfortable for you. Focus your thoughts and energy\r\n                    on your breathing instead of what’s stressing you\r\n                    out. You can do this by timing your breathing\r\n                    (counting to 6 every time you breathe in and to 6\r\n                    every time you breathe out). Focus on your counting\r\n                    until you feel less overwhelmed by the situation.\r\n                    Don’t rush yourself, and allow yourself to feel what\r\n                    you feel. Sometimes you’ll feel less stressed in a\r\n                    few seconds, other times it can take minutes.\r\n                    Everybody’s stress is different and equally valid. \r\n                    </p>\r\n\r\n                    <div id=\"Sixth_Sub_Point_2\" class=\"anchor\"></div>\r\n                    <h5>2) Move around</h5>\r\n                    <p>The simple acts of getting up, getting out, and\r\n                    moving your body around has been scientifically\r\n                    proven to reduce stress and improve our perspective.\r\n                    In a moment of anxiety, stress, or anger, it can be\r\n                    hard to think clearly. Physically removing yourself\r\n                    from the stressful situation, maybe by going for a\r\n                    walk, can help you breathe, collect your thoughts,\r\n                    and reduce feelings of anxiety. While you move\r\n                    around, you can try counting (counting to 6 every\r\n                    time you breathe in and to 6 every time you breathe\r\n                    out), to help you shift your energy and thoughts\r\n                    away from the stressful circumstance. \r\n                    </p>\r\n\r\n                    <div id=\"Sixth_Sub_Point_3\" class=\"anchor\"></div>\r\n                    <h5>3) Let yourself feel what you feel</h5>\r\n                    <p>Allow yourself to feel whatever you’re feeling,\r\n                    whether that’s sadness or frustration. Your feelings\r\n                    are valid, even when they seem irrational. Let\r\n                    yourself cry or mourn, and don’t let your feelings\r\n                    bottle up inside. If you feel safe doing so, you can\r\n                    try talking about your feelings with a trusted\r\n                    friend, family member, or even a professional. Talk\r\n                    through your emotions, your experiences, and your\r\n                    worries. If you don’t feel comfortable sharing your\r\n                    emotions, don’t rush yourself. Everybody’s mental\r\n                    health journey is different. You could try writing\r\n                    what you’re feeling in a private journal, or\r\n                    expressing yourself indirectly through art, poetry,\r\n                    or creativity. Find an outlet that lets you express\r\n                    your emotions in a safe, healthy, and supportive\r\n                    way. \r\n                    </p>\r\n\r\n                    <div id=\"Sixth_Sub_Point_4\" class=\"anchor\"></div>\r\n                    <h5>4) List things you\'re grateful for</h5>\r\n                    <p>Remembering things you’re grateful for can help\r\n                    shift your thoughts from what’s stressing you out to\r\n                    what brings you joy. An easy way to get started is\r\n                    to keep a Gratitude Journal. You can use an actual\r\n                    journal, a writing pad, or the notes app in your\r\n                    phone or tablet. If you’re feeling stressed or\r\n                    overwhelmed, pull out your list of things that\r\n                    you’re grateful for to remind yourself of the joy in\r\n                    your life. \r\n                    </p>\r\n\r\n                    <div id=\"Sixth_Sub_Point_5\" class=\"anchor\"></div>\r\n                    <h5>5) Make lists and schedules to prioritize\r\n                    activities</h5>\r\n                    <p>If you’re feeling overwhelmed or like you have a\r\n                    lot of things to do, it can be helpful to visualize\r\n                    your tasks and write them down in a concrete list.\r\n                    You can use an agenda or an online scheduling tool\r\n                    (such as Google Calendar). Making a list of the\r\n                    things you need to do for the day, or keeping track\r\n                    of tasks in a concrete schedule, can help reduce\r\n                    feelings of panic or anxiety. If thoughts of panic\r\n                    and anxiety start to swirl around, and the things\r\n                    you have to do start to seem impossible, look at\r\n                    your list and focus on what’s written down. Thoughts\r\n                    can sometimes make even simple tasks seem\r\n                    complicated. \r\n                    </p>\r\n                \r\n                    <div id=\"Sixth_Sub_Point_6\" class=\"anchor\"></div>\r\n                    <h5>6) Meditate</h5>\r\n                    <ol>\r\n                        <li>Find a spot to sit (or lie) comfortably</li>\r\n                        <li>Close your eyes</li>\r\n                        <li>Breathe naturally. Try not to control your\r\n                        breathing.</li>\r\n                        <li>Spend 6-5 minutes focusing on your breath\r\n                        and how your body moves as you inhale and\r\n                        exhale.</li>\r\n                        <li>If you mind wanders, return your focus back\r\n                        to your breath/body movements.</li>\r\n                    </ol>\r\n\r\n                    <div id=\"Sixth_Sub_Point_7\" class=\"anchor\"></div>\r\n                    <h5>7) Talk to a trusted friend, family member, or\r\n                    professional\r\n                    </h5>\r\n                    <p>Anxiety, stress, and frustration can make you\r\n                    feel alone or isolated. In times of loneliness, it\r\n                    can be helpful to talk about your feelings with a\r\n                    trusted friend, family member, or a licensed\r\n                    professional. Doing so can give you a new\r\n                    perspective on the situation and help you feel less\r\n                    lonely. In any conversation you have, make sure your\r\n                    feelings are respected, understood, and heard. Your\r\n                    feelings are not “your fault” or the result of any\r\n                    of your actions, and it’s important that your\r\n                    conversation reflects that, that you feel safe,\r\n                    supported, and understood. \r\n                    </p>\r\n\r\n                    <div id=\"Sixth_Sub_Point_8\" class=\"anchor\"></div>\r\n                    <h5>8) Call a National Suicide Prevention Lifeline\r\n                    </h5>\r\n                    <ul>\r\n                        <li>If you’re thinking about suicide, are\r\n                        worried about a friend or loved one, or would\r\n                        like somebody to talk to about your emotions and\r\n                        experiences, it might be helpful to call the\r\n                        Lifeline network (available 24/7 across the\r\n                        United States at 1-800-272-8255). These\r\n                        lifelines are a good option if you don’t feel\r\n                        comfortable sharing your emotions with friends\r\n                        or family members. </li>\r\n                        <li>In any conversation you have, make sure your\r\n                        feelings are respected, understood, and heard.\r\n                        Your feelings are not “your fault” or the result\r\n                        of any of your actions, and it’s important that\r\n                        your conversation reflects that. It’s important\r\n                        that you feel safe, supported, and understood. \r\n                        </li>\r\n                        <li>Every call is answered by a different\r\n                        volunteer, so if one call doesn’t go well,\r\n                        another one might be more fulfilling. \r\n                        </li>\r\n                    </ul>\r\n                </div>\r\n            <p>Information from: \r\n                <br>\r\n                <a href=\"https://www.commonlit.org/en/texts/self-care\">https://www.commonlit.org/en/texts/self-care</a>\r\n                <br>\r\n                <a href =\"https://www.cdc.gov/mentalhealth/learn/index.htm\">https://www.cdc.gov/mentalhealth/learn/index.htm</a> </p>\r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('26','23','Rental Assistance/Mediation','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Rental</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=27\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 Rental Assistance\r\n                </a>\r\n                <li><a href=\"#Second_Point_Header\">2 Steps to Consider\r\n                When Applying for Rental Assistance</a>\r\n                    <ul>\r\n                        <li><a href=\"#Second_Sub_Point_1\">2.1 Review\r\n                        your budget</a></li>\r\n                        <li><a href=\"#Second_Sub_Point_2\">2.2 Check your\r\n                        eligibility for different programs\r\n                        </a></li>\r\n                        <li><a href=\"#Second_Sub_Point_3\">2.3 Apply for\r\n                        the programs you’ve chosen.\r\n                        </a></li>\r\n                    </ul>\r\n                <li><a href=\"#Third_Point_Header\">3 Landlord Mediation\r\n                </a>\r\n                <li><a href=\"#Fourth_Point_Header\">4 Steps to Consider\r\n                When Contacting a Mediation Service\r\n                </a>\r\n                        <ul>\r\n                            <li><a href=\"#Fourth_Sub_Point_1\">4.1 Make a\r\n                            list of needs and wants\r\n                            </a></li>\r\n                            <li><a href=\"#Fourth_Sub_Point_2\">4.2\r\n                            Communicate calmly\r\n                            </a></li>\r\n                            <li><a href=\"#Fourth_Sub_Point_3\">4.3\r\n                            Consider mediation\r\n                            </a></li>\r\n                            <li><a href=\"#Fourth_Sub_Point_4\">4.4 Find a\r\n                            mediation service near you\r\n                            </a></li>\r\n                            <li><a href=\"#Fourth_Sub_Point_5\">4.5 Be\r\n                            open to your mediator’s suggestions\r\n                            </a></li>\r\n                        </ul>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n\r\n        \r\n\r\n            <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Rental Assistance</h5>\r\n            <p>If you need help paying your rent, there are several\r\n            federal, state, and local programs available for support,\r\n            counseling, and guidance. Before applying for rental\r\n            assistance, it’s important to check if you qualify for a\r\n            given program, which can depend on your income, location,\r\n            and the type of program.\r\n                </p>\r\n\r\n            <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Steps to Consider When Applying for Rental Assistance\r\n            </h5>\r\n            <div class=\"subheading\">\r\n\r\n                <div id=\"Second_Sub_Point_1\" class=\"anchor\"></div>\r\n                <h5>1) Review your budget</h5>\r\n                <p>What are your daily expenses? What do you spend on\r\n                utilities? What are your sources of income and\r\n                residential needs? Organizing all of this information\r\n                can help you determine which programs to apply for and\r\n                the kind of assistance that would be the most helpful. \r\n                </p>\r\n                \r\n                <div id=\"Second_Sub_Point_2\" class=\"anchor\"></div>\r\n                <h5>2) Check your eligibility for different\r\n                programs</h5>\r\n                <p>Not all rental assistance programs are the same. Some\r\n                programs require your household income to not exceed 80%\r\n                of the median income where you live, while others\r\n                require your income to be at most 50% of the local\r\n                median income. Compare your household income with the\r\n                requirements of different programs, and narrow your\r\n                search to the programs you’re eligible for. It may be\r\n                helpful to make a list, or even to contact a housing\r\n                counselor (one approved by a US Department of Housing),\r\n                to help you work through all of your options.\r\n                </p>\r\n                \r\n                <div id=\"Second_Sub_Point_3\" class=\"anchor\"></div>\r\n                <h5>3) Apply for the programs you’ve chosen</h5>\r\n                <p>Once you’ve made a list of programs you are eligible\r\n                for, it’s important to contact the programs as soon as\r\n                possible. Because of funding limitations, a lot of these\r\n                programs can’t give funds to everyone who is eligible.\r\n                Applying to multiple programs can help increase your\r\n                chances of getting the support you need. For example, if\r\n                a federal program (such as Housing Choice Vouchers),\r\n                doesn’t have availability, perhaps a state-run program\r\n                will. \r\n                </p>\r\n\r\n            </div>\r\n            <p>Information from:\r\n                <br>\r\n                <a\r\n                href=\"https://www.cbpp.org/research/housing/policy-basics-federal-rental-assistance#:~:text=Who%20Is%20Eligible%3F,percent%20of%20the%20local%20median.\">https://www.cbpp.org/research/housing/policy-basics-federal-rental-assistance#:~:text=Who%20Is%20Eligible%3F,percent%20of%20the%20local%20median</a>\"\r\n            </p>\r\n\r\n            <div id=\"Third_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Landlord Mediation\r\n            </h5>\r\n            <p>If you and your landlord are having trouble coming to an\r\n            agreement regarding rent, payments, or any other housing\r\n            concerns, you can consider contacting a tenant’s rights\r\n            association or a landlord mediation service to help you work\r\n            through the dispute. Contacting a mediation service can help\r\n            you reach a resolution faster or potentially avoid a court\r\n            battle. \r\n            </p>\r\n            <div id=\"Fourth_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Steps to Consider When Contacting a Mediation Service\r\n            </h5>\r\n            <div class=\"subheading\">\r\n\r\n                <div id=\"Fourth_Sub_Point_1\" class=\"anchor\"></div>\r\n                <h5>1) Make a list of needs and wants</h5>\r\n                <p>Make a list of the things you want. Do you want to\r\n                leave your lease early? Ask for a lower rent? Writing\r\n                down the things you want can help keep your meeting\r\n                concise and to the point. \r\n                </p>\r\n                \r\n                <div id=\"Fourth_Sub_Point_2\" class=\"anchor\"></div>\r\n                <h5>2) Communicate calmly\r\n                </h5>\r\n                <p>Calmly and respectfully communicate what you want\r\n                with your landlord. Understand their point of view, and\r\n                avoid making any hostile comments. This situation can be\r\n                stressful for you both, and making sure you communicate\r\n                calmly and respectfully, while still emphasizing what\r\n                you need, can help you both reach an agreement. \r\n                </p>\r\n                \r\n                <div id=\"Fourth_Sub_Point_3\" class=\"anchor\"></div>\r\n                <h5>3) Consider mediation\r\n                </h5>\r\n                <p>Unable to reach an agreement? In that situation, it\r\n                can be helpful to consider contacting a mediation\r\n                service.\r\n                </p>\r\n\r\n                <div id=\"Fourth_Sub_Point_4\" class=\"anchor\"></div>\r\n                <h5>4) Find a mediation service near you\r\n                </h5>\r\n                <p>There are several low-cost or even free mediation\r\n                services that can help you and your landlord reach an\r\n                agreement. Call your mayor’s office or your city\r\n                manager’s office and ask for information on such\r\n                community groups. Colleges, the American Arbitrage\r\n                Association, and several other groups also offer access\r\n                to mediation services. It’s important to explore these\r\n                different options depending on your needs, urgency, and\r\n                your location.\r\n                </p>\r\n                <div id=\"Fourth_Sub_Point_5\" class=\"anchor\"></div>\r\n                <h5>5) Be open to your mediator’s suggestions\r\n                </h5>\r\n                <p>A mediator’s purpose is to help you and your landlord\r\n                reach an agreement. It’s important to be open to your\r\n                mediator’s suggestions. They may suggest discussing\r\n                issues in separate rooms before coming together,\r\n                listening to the landlord’s issues again, and various\r\n                other mediation techniques. So long as your thoughts are\r\n                heard, being open to these techniques can help you come\r\n                to an agreement faster, one that both you and your\r\n                landlord can agree upon. \r\n                </p>\r\n            </div>\r\n            <p>Information from:\r\n                <br>\r\n                <a\r\n                href=\"https://www.nolo.com/legal-encyclopedia/free-books/renters-rights-book/chapter13-2.html#:~:text=Many%20cities%20offer%20free%20or,that%20handle%20landlord%2Dtenant%20disputes.&text=That%20person%20should%20refer%20you,they%20reach%20the%20court%20stage.\">https://www.nolo.com/legal-encyclopedia/free-books/renters-rights-book/chapter13-2.html#:~:text=Many%20cities%20offer%20free%20or,that%20handle%20landlord%2Dtenant%20disputes.&text=That%20person%20should%20refer%20you,they%20reach%20the%20court%20stage.\r\n            </a>\r\n            </p>\r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('27','23','Rental','','','','<!DOCTYPE html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>Rental</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n        href=\"index.php?module=ext/ipages/view&id=14\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr>\r\n    <div class=\"category-wrapper\">\r\n        <ul class=\"resource-grid\">\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=26\">\r\n                    <h4>Rental Assistance/Mediation</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=28\">\r\n                    <h4>Renting a Home</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('28','23','Renting a Home','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Renting a Home</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=27\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 Steps to Consider\r\n                When Renting a House\r\n                </a>\r\n                    <ul>\r\n                        <li><a href=\"#First_Sub_Point_1\">1.1 Review your\r\n                        budget</a></li>\r\n                        <li><a href=\"#First_Sub_Point_2\">1.2 Decide on\r\n                        what you want in a house\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_3\">1.3 Consider\r\n                        your credit score\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_4\">1.4 Look at\r\n                        different houses\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_5\">1.5 Choose a\r\n                        house and finalize your lease\r\n                        </a></li>\r\n                    </ul>\r\n        </div>\r\n\r\n        <br>\r\n        <p>Thinking about renting a house? While the process can be\r\n        overwhelming at times, breaking it down into steps can help make\r\n        the process easier. \r\n                </p>\r\n        \r\n            <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Steps to Consider When Renting a House\r\n            </h5>\r\n\r\n            <div class=\"subheading\">\r\n                <div id=\"First_Sub_Point_1\" class=\"anchor\"></div>\r\n                <h5>1) Review your budget</h5>\r\n                <p>What are your daily expenses? Are you expecting any\r\n                changes to your future income? When renting a house,\r\n                you’ll also have to pay for utilities, moving fees, and\r\n                your other necessities. Based on these factors, come to\r\n                a decision regarding how much you want to spend on rent\r\n                itself. Organizing these numbers, and even discussing\r\n                them with a trusted friend, family member, or realtor\r\n                can help you make an informed decision.\r\n                </p>\r\n                \r\n                <div id=\"First_Sub_Point_2\" class=\"anchor\"></div>\r\n                <h5>2) Decide on what you want in a house\r\n                </h5>\r\n                <p>After you’ve decided on a budget, decide on what you\r\n                want in a house. Do you want a backyard, a certain\r\n                school district, or a certain number of rooms? All of\r\n                these things are helpful to keep in mind when meeting\r\n                with a realtor or considering a particular house. \r\n                </p>\r\n                \r\n                <div id=\"First_Sub_Point_3\" class=\"anchor\"></div>\r\n                <h5>3) Consider your credit score</h5>\r\n                <p>Consider using a trusted resource to find your credit\r\n                score. Higher scores can make it easier for you to\r\n                secure a rental property. You could even consider\r\n                scheduling an appointment at the bank to review your\r\n                financial history and have as much information as\r\n                possible. \r\n                </p>\r\n\r\n                <div id=\"First_Sub_Point_4\" class=\"anchor\"></div>\r\n                <h5>4) Look at different houses\r\n                </h5>\r\n                <p>Once your financial information is in order, you\r\n                could begin to look at houses. You can look at different\r\n                websites online, or you could contact a realtor. Compare\r\n                the houses you find to your budget and the things you\r\n                want from the place you live. You could contact the\r\n                owner to visit the house and see its features in-person.\r\n                Seeing the house beyond pictures posted online, whether\r\n                through a video chat or an in-person visit, can help\r\n                make you make an informed decision. \r\n                </p>\r\n\r\n                <div id=\"First_Sub_Point_5\" class=\"anchor\"></div>\r\n                <h5>5) Choose a house and finalize your lease\r\n                </h5>\r\n                <p>Once you’ve chosen a property within your budget that\r\n                matches your priorities, contact the owner and consider\r\n                the lease. Make sure you read its terms and conditions\r\n                carefully, and don’t be afraid to ask questions. Look up\r\n                your state’s laws and regulations if any part of the\r\n                lease is unclear, and don’t be afraid to contact a\r\n                housing counselor or lawyer for guidance or help. Ask\r\n                the owner about any security deposits, visitor policies,\r\n                etc. Clarify any doubts you have with the owner\r\n                beforehand, and make sure you communicate your needs.\r\n                Renting a house can be stressful, but having more\r\n                information can make the process easier and experience\r\n                more enjoyable.\r\n                </p>\r\n\r\n\r\n\r\n            </div>\r\n            \r\n            <p>Information from:\r\n                <br>\r\n                <a\r\n                href=\"https://www.apartments.com/blog/how-to-rent-a-house\">https://www.apartments.com/blog/how-to-rent-a-house\r\n            </a>\r\n            </p>\r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('29','11','Education','','fa-folder-o','','','0,13,6,12,5,4','','0','1',''),
('30','23','Home Ownership','','','','<!DOCTYPE html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>Ownership</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n        href=\"index.php?module=ext/ipages/view&id=14\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr>\r\n    <div class=\"category-wrapper\">\r\n        <ul class=\"resource-grid\">\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=32#First_Point_Header\">\r\n                    <h4>Mortgage Assistance/Restructuring</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=36\">\r\n                    <h4>Buying a Home</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('32','23','Mortgage Assistance/Restructuring','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Mortgage</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=30\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 Steps to Consider\r\n                When Applying for Mortgage Assistance or Restructuring\r\n                </a>\r\n                    <ul>\r\n                        <li><a href=\"#First_Sub_Point_1\">1.1 Review your\r\n                        budget</a></li>\r\n                        <li><a href=\"#First_Sub_Point_2\">1.2 Check that\r\n                        you meet the requirements\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_3\">1.3 Contact\r\n                        your mortgage servicer (the company you pay\r\n                        every month, etc)\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_4\">1.4 Seek\r\n                        support from friends, family, and trusted\r\n                        associates\r\n                        </a></li>\r\n                    </ul>\r\n        </div>\r\n\r\n        <br>\r\n    \r\n            <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Steps to Consider When Applying for Mortgage Assistance\r\n            or Restructuring\r\n            </h5>\r\n\r\n            <div class=\"subheading\">\r\n                <div id=\"First_Sub_Point_1\" class=\"anchor\"></div>\r\n                <h5>1) Review your budget</h5>\r\n                <p>What are your daily expenses? What do you spend on\r\n                utilities? What are your sources of income and\r\n                residential needs? Organizing all of this information\r\n                can help you determine which programs to apply for and\r\n                the kind of assistance or restructuring that would be\r\n                the most helpful. \r\n                </p>\r\n                \r\n                <div id=\"First_Sub_Point_2\" class=\"anchor\"></div>\r\n                <h5>2) Check that you meet the requirements\r\n                </h5>\r\n                <p>Some federally-run mortgage assistance programs have\r\n                certain requirements. For example, the Home Affordable\r\n                Modification Program requires a certain principal amount\r\n                and loan origination date. It can be helpful to research\r\n                different programs and their requirements. \r\n                </p>\r\n                \r\n                <div id=\"First_Sub_Point_3\" class=\"anchor\"></div>\r\n                <h5>3) Contact your mortgage servicer (the company you\r\n                pay every month, etc)\r\n                </h5>\r\n                <p>If you’re having trouble paying your mortgage, it’s\r\n                important to communicate your situation with your\r\n                mortgage servicer. They’ll be able to give the best\r\n                suggestions for your circumstances, whether that’s a\r\n                repayment plan or refinancing the loan (paying off your\r\n                current mortgage and then taking out a new mortgage with\r\n                different terms, such as a lower interest rate). \r\n                </p>\r\n\r\n                <div id=\"First_Sub_Point_4\" class=\"anchor\"></div>\r\n                <h5>4) Seek support from friends, family, and trusted\r\n                associates\r\n                </h5>\r\n                <p>Applying for mortgage assistance can be a stressful\r\n                process. Discussing your circumstances with a trusted\r\n                friend, family member, or associate (perhaps even\r\n                scheduling an appointment with a financial advisor), can\r\n                help you consider all of your options and make a\r\n                well-informed decision. \r\n                </p>\r\n\r\n\r\n            </div>\r\n            \r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('33','29','My School','My School','','','<!DOCTYPE html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>My School</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n        href=\"index.php?module=ext/ipages/view&id=13\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr>\r\n    <div class=\"category-wrapper\">\r\n        <ul class=\"resource-grid\">\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=41\">\r\n                    <h4>School Types</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=43\">\r\n                    <h4>Enjoying Schools & Study Skills</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,13,6,12,5,4','','0','0',''),
('35','29','Children\'s Learning','Children\'s Learning','','','','0,13,6,12,5,4','','0','0',''),
('36','23','Buying a House','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Mortgage</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=30\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 Steps to Consider\r\n                When Applying for Mortgage Assistance or Restructuring\r\n                </a>\r\n                    <ul>\r\n                        <li><a href=\"#First_Sub_Point_1\">1.1 Review your\r\n                        budget</a></li>\r\n                        <li><a href=\"#First_Sub_Point_2\">1.2 Check your\r\n                        savings\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_3\">1.3 Consider\r\n                        your credit score\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_4\">1.4 Decide on\r\n                        what you want in a house\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_5\">1.5 Get\r\n                        mortgage pre-approval\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_6\">1.6 Choose a\r\n                        real-estate agent and begin looking at houses\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_7\">1.7 With your\r\n                        realtor’s help, make an offer on the house\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_8\">1.8 Discuss\r\n                        next steps with your realtor\r\n                        </a></li>\r\n                    </ul>\r\n        </div>\r\n\r\n        <br>\r\n    \r\n            <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Steps to Consider When Buying a House\r\n            </h5>\r\n\r\n            <div class=\"subheading\">\r\n                <div id=\"First_Sub_Point_1\" class=\"anchor\"></div>\r\n                <h5>1) Review your budget</h5>\r\n                <p>What are your daily expenses? Are you expecting any\r\n                changes to your future income? When buying a house,\r\n                you’ll also have to pay for utilities, moving fees, and\r\n                your other necessities. Based on these factors, come to\r\n                a decision regarding how much you want to spend on the\r\n                house itself. Organizing these numbers, and even\r\n                discussing them with a trusted friend, family member, or\r\n                realtor can help you make an informed decision.\r\n                </p>\r\n                \r\n                <div id=\"First_Sub_Point_2\" class=\"anchor\"></div>\r\n                <h5>2) Check your savings\r\n                </h5>\r\n                <p>Does the house in question have a down payment you’d\r\n                need to pay? Any closing costs? Reviewing your budget,\r\n                check how much money you have in your savings for these\r\n                costs. Consider making an appointment at the bank to\r\n                review your savings and room for spending. \r\n                </p>\r\n                \r\n                <div id=\"First_Sub_Point_3\" class=\"anchor\"></div>\r\n                <h5>3) Consider your credit score\r\n                </h5>\r\n                <p>Consider using a trusted resource to find your credit\r\n                score. Higher scores can make it easier for you to\r\n                secure a rental property. You could even consider\r\n                scheduling an appointment at the bank to review your\r\n                financial history and have as much information as\r\n                possible. \r\n                </p>\r\n\r\n                <div id=\"First_Sub_Point_4\" class=\"anchor\"></div>\r\n                <h5>4) Decide on what you want in a house\r\n                </h5>\r\n                <p>After you’ve decided on a budget, decide on what you\r\n                want in a house. Do you want a backyard, a certain\r\n                school district, or a certain number of rooms? All of\r\n                these things are helpful to keep in mind when meeting\r\n                with a realtor or considering a particular house. \r\n\r\n                </p>\r\n                <div id=\"First_Sub_Point_5\" class=\"anchor\"></div>\r\n                <h5>5) Get mortgage pre-approval\r\n                </h5>\r\n                <p>Oftentimes, when buying a house, it’s essential to\r\n                get mortgage pre-approval. A pre-approval letter can\r\n                help your realtor find a house you like within your\r\n                budget. Buying a house can be an expensive process, and\r\n                getting a mortgage loan is often necessary to help make\r\n                the process more affordable. Consider making an\r\n                appointment with the bank to go over your options. There\r\n                are different kinds of loans available, from\r\n                conventional to USDA, depending on your credit score and\r\n                income level. Going through these options with a housing\r\n                counselor or banking official can make the process\r\n                easier. \r\n                </p>\r\n                \r\n                <div id=\"First_Sub_Point_6\" class=\"anchor\"></div>\r\n                <h5>6) Choose a real-estate agent and begin looking at\r\n                houses\r\n                </h5>\r\n                <p>A good real-estate agent can help make the buying\r\n                process easier and help you navigate the housing\r\n                process. You can ask trusted friends or family members\r\n                for a recommended realtor, or you can find one online.\r\n                Make sure you communicate your wants and budget clearly\r\n                to your realtor, so they can show you the best houses\r\n                for you in the area you want. It can be helpful to do\r\n                in-person visits of the houses your realtor suggests.\r\n                Seeing the house beyond pictures posted online, whether\r\n                through a video chat or an in-person visit, can help\r\n                make you make an informed decision. \r\n                </p>\r\n                \r\n                <div id=\"First_Sub_Point_7\" class=\"anchor\"></div>\r\n                <h5>7) With your realtor’s help, make an offer on the\r\n                house\r\n                </h5>\r\n                <p>Found a house you like? Consider making an offer\r\n                through your realtor, and be prepared for negotiations\r\n                with the seller of the house. It’s important that any\r\n                decision you and the seller make satisfies your needs\r\n                and requirements. Communicating these needs to your\r\n                realtor can be helpful. \r\n                </p>\r\n\r\n                <div id=\"First_Sub_Point_8\" class=\"anchor\"></div>\r\n                <h5>8) Discuss next steps with your realtor\r\n                </h5>\r\n                <p>Before you accept an offer, consider discussing next\r\n                steps with your realtor. Do you need to do a house\r\n                inspection, get an appraisal, or make repairs? These\r\n                final details are important to go over before closing on\r\n                an offer. Buying a house can be a complicated process,\r\n                but having as much information available to you can let\r\n                you make a more informed decision.\r\n                </p>\r\n\r\n                <p>Information from: \r\n                    <br>\r\n                    <a href=\"https://www.rocketmortgage.com/learn/how-to-buy-a-house\">https://www.rocketmortgage.com/learn/how-to-buy-a-house</a>\r\n                </p>\r\n\r\n            </div>\r\n            \r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('40','29','Money','Money','','','','0,13,6,12,5,4','','0','0',''),
('41','29','School Types','School Types','','','<!DOCTYPE html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>School Types</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n        href=\"index.php?module=ext/ipages/view&id=10\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr>\r\n    <div class=\"category-wrapper\">\r\n        <ul class=\"resource-grid\">\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=44\">\r\n                    <h4>High School / GED</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=50\">\r\n                    <h4>Community College / College / University </h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=46\">\r\n                    <h4>Trade School / Professional License</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=45\">\r\n                    <h4>Military (Active Duty or Reserves)</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,13,6,12,5,4','','0','0',''),
('42','23','Fair Housing Laws','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Fair Housing Laws</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=14\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 What is not allowed?\r\n                </a></li>\r\n                <li><a href=\"#Second_Point_Header\">2 What if you notice\r\n                a violation?\r\n                </a>\r\n                    <ul>\r\n                        <li><a href=\"#Second_Sub_Point_1\">2.1 Organize\r\n                        your information\r\n                        </a></li>\r\n                        <li><a href=\"#Second_Sub_Point_2\">2.2 File the\r\n                        complaint\r\n                        </a></li>\r\n                        <li><a href=\"#Second_Sub_Point_3\">2.3 Consider\r\n                        getting legal counsel or support\r\n                        </a></li>\r\n                        <li><a href=\"#Second_Sub_Point_4\">2.4 Understand\r\n                        the process\r\n                        </a></li>\r\n                    </ul>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n\r\n        <p>\r\n            When you’re going through the housing process, whether that\r\n            involves buying a home, renting a home, or applying for a\r\n            mortgage, it’s important that you feel safe and supported.\r\n            The Fair Housing Act was passed specifically for this\r\n            purpose, to make sure people are protected from\r\n            discrimination when participating in housing-related\r\n            activities. The FHA prohibits discrimination on the basis of\r\n            sex, race, disabilities, and more. Knowing your rights can\r\n            help make the housing process more equal and safe for\r\n            everyone involved. \r\n        </p>\r\n\r\n            <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n            <h5>What is not allowed?</h5>\r\n            <p>If you see any of the following actions done based on\r\n            somebody’s sex, religion, disability status, etc, it is a\r\n            violation of the Fair Housing Act.</p>\r\n            <ul>\r\n                <li>Refusing to rent a house or sell a house</li>\r\n                <li>Setting different terms and conditions for a sale or\r\n                a rental</li>\r\n                <li>Delaying maintenance or repairs</li>\r\n                <li>Deny purchase of a property or a rental</li>\r\n                <li>Refuse to make a mortgage loan or to provide\r\n                financial assistance</li>\r\n                <li>Refuse to purchase a loan</li>\r\n                <li>Impose different conditions on a loan</li>\r\n            </ul>\r\n            <p>There are more examples of violations of the Fair Housing\r\n            Act, similar to the ones above. \r\n            </p>\r\n                \r\n       \r\n            <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n            <h5>What if you notice a violation?</h5>\r\n            <p>If you’re going through the housing process and feel like\r\n            your rights are being violated, it is important that you\r\n            seek help. One way of doing so is filing a complaint with\r\n            the US Department of Housing.</p>\r\n            <div class=\"subheading\">\r\n                <div id=\"Second_Sub_Point_1\" class=\"anchor\"></div>\r\n                <h5>Organize your information\r\n                </h5>\r\n                <p>When filing a complaint, the Department of Housing\r\n                will ask for information regarding the incident at hand.\r\n                It’s important that you organize your information. Your\r\n                name, your address, the name and address of the person\r\n                the complaint is against, a description of the event,\r\n                and the date of the event, and more could be asked. It\r\n                may be helpful to write down everything you remember, or\r\n                to discuss the incident with a trusted friend or family\r\n                member. Not including any of the previous requested\r\n                information may delay your request from being processed\r\n                in a timely manner. \r\n                </p>\r\n                \r\n                <div id=\"Second_Sub_Point_2\" class=\"anchor\"></div>\r\n                <h5>File the complaint</h5>\r\n                <p>You can file your complaint online, through email, by\r\n                the phone, or through mail, depending on your\r\n                preference. You must file your complaint within 1 year\r\n                of the incident at hand.\r\n                </p>\r\n\r\n                <div id=\"Second_Sub_Point_3\" class=\"anchor\"></div>\r\n                <h5>Consider getting legal counsel or support\r\n                </h5>\r\n                <p>The process of filing a complaint can be stressful.\r\n                It could be helpful to seek legal advice from a lawyer\r\n                or trusted legal counsel. It could also be helpful to\r\n                discuss the incident at hand with a trusted friend or\r\n                family member. \r\n                </p>\r\n                \r\n                <div id=\"Second_Sub_Point_4\" class=\"anchor\"></div>\r\n                <h5>Understand the process\r\n                </h5>\r\n                <p>Once you file the complaint, the HUD will begin its\r\n                process. First, the alleged violater will be notified.\r\n                They’ll then investigate your complaint and determine if\r\n                the Fair Housing Act was violated. If they can’t\r\n                complete their investigation within a 100 days of filing\r\n                the complaint, they’ll notify you and the accused. If\r\n                they find that a violation occurred, the violator will\r\n                be charged a civil penalty fee. \r\n                </p>\r\n            </div>\r\n            <p>Information from: \r\n                <br>\r\n                <a href=\"https://www.hud.gov/program_offices/fair_housing_equal_opp/online-complaint\">https://www.hud.gov/program_offices/fair_housing_equal_opp/online-complaint</a>\r\n            </p>\r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('43','29','Enjoying Schools & Study Skills','Enjoying Schools & Study Skills','','','<!DOCTYPE html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n\r\n    <title>Enjoying School</title>\r\n    <!-- Source: http://www.prepbootstrap.com/bootstrap-template/faq-example -->\r\n    <link rel=\"stylesheet\" href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n        integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\" crossorigin=\"anonymous\">\r\n\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n        href=\"index.php?module=ext/ipages/view&id=33\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr>\r\n    <div class=\"category-wrapper\">\r\n        <ul class=\"resource-grid\">\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=48\">\r\n                    <h4>Increasing Enjoyment in School</h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n            <li>\r\n                <a href=\"index.php?module=ext/ipages/view&id=49\">\r\n                    <h4>Study Skills </h4>\r\n                    <img class=\"resource-thumb\" src=\"\">\r\n                </a>\r\n            </li>\r\n        </ul>\r\n    </div>\r\n\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,13,6,12,5,4','','0','0',''),
('44','29','High School & GED','High School & GED','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>High School / GED</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=41\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 High School Resources\r\n                </a>\r\n                    <ul>\r\n                        <li><a href=\"#First_Sub_Point_1\">1.1 Why should\r\n                        I go to and graduate high school?\r\n                        </a></li>\r\n                        <li><a href=\"#First_Sub_Point_2\">1.2 How can I\r\n                        graduate high school?</a></li>\r\n                        <li><a href=\"#First_Sub_Point_3\">1.3 What\r\n                        classes should I take?</a></li>\r\n                        <li><a href=\"#First_Sub_Point_4\">1.4 What if I’m\r\n                        feeling stressed or overwhelmed?</a></li>\r\n                        <li><a href=\"#First_Sub_Point_5\">1.5 What\r\n                        happens after I graduate high school?\r\n                        </a></li>\r\n                    </ul>\r\n                </li>\r\n                <li><a href=\"#Second_Point_Header\">2 GED Resources\r\n                </a>\r\n                    <ul>\r\n                        <li><a href=\"#Second_Sub_Point_1\">2.1 What is\r\n                        the GED?\r\n                        </a></li>\r\n                        <li><a href=\"#Second_Sub_Point_2\">2.2 Should I\r\n                        get my GED?\r\n                        </a></li>\r\n                        <li><a href=\"#Second_Sub_Point_3\">2.3 How should\r\n                        I study?\r\n                        </a></li>\r\n                        <li><a href=\"#Second_Sub_Point_4\">2.4 How can I\r\n                        take the test?\r\n                        </a></li>\r\n                        <li><a href=\"#Second_Sub_Point_5\">2.5  What\r\n                        score do I need to pass?\r\n                        </a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n\r\n            <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n            <h5>High School Resources</h5>\r\n\r\n                <div class=\"subheading\">                    \r\n                    <div id=\"First_Sub_Point_1\" class=\"anchor\"></div>\r\n                    <h5>Why should I go to and graduate high\r\n                    school?</h5>\r\n                    <p>Graduating high school is an important milestone\r\n                    in your educational career. It can pave the way for\r\n                    future educational opportunities (such as college,\r\n                    military school, or trade school) and future\r\n                    professional opportunities (such as becoming a\r\n                    doctor, engineer, lawyer, and more). Graduating high\r\n                    school can lead to higher future potential earnings\r\n                    in whatever career you choose and a sense of pride\r\n                    and accomplishment. While it may seem difficult and\r\n                    stressful at times, with the right resources by your\r\n                    side, this milestone is well within your reach. \r\n                    </p>\r\n\r\n                    <div id=\"First_Sub_Point_2\" class=\"anchor\"></div>\r\n                    <h5>How can I graduate high school?</h5>\r\n                    <p>This depends on whether you are homeschooled or\r\n                    go to a traditional high school. This can also\r\n                    depend on whether your specific school itself. In\r\n                    this case, it’s important to be familiar with your\r\n                    school’s resources. You can set up an appointment\r\n                    with your guidance counselor or a trusted teacher to\r\n                    ask specific questions. Most schools usually require\r\n                    you to pass a certain number of classes or attain a\r\n                    certain number of credits to get your diploma.\r\n                    </p>\r\n\r\n                    <div id=\"First_Sub_Point_3\" class=\"anchor\"></div>\r\n                    <h5>What classes should I take?</h5>\r\n                    <p>When choosing classes, there are two factors to\r\n                    consider: what do you want to learn and what do you\r\n                    need to take to graduate? \r\n                        <ul>\r\n                            <li>For example, if you’re interested in\r\n                            becoming a doctor, it could be helpful to\r\n                            take biology or anatomy classes to see if\r\n                            you enjoy the material. If you want to\r\n                            become an engineer, it could be useful to\r\n                            take a coding class or a math class (such as\r\n                            precalculus, calculus, or statistics). \r\n                            </li>\r\n                            <li>Make sure you’re meeting your school’s\r\n                            requirements to graduate! For example, if\r\n                            your school district requires you to take a\r\n                            semester of physical education or health,\r\n                            make sure you include those courses in your\r\n                            schedule. Meet with your guidance counselor\r\n                            to make sure you’re on track to graduate.\r\n                            </li>\r\n                        </ul>\r\n                    </p>\r\n\r\n                    <div id=\"First_Sub_Point_4\" class=\"anchor\"></div>\r\n                    <h5>What if I’m feeling stressed or\r\n                    overwhelmed?</h5>\r\n                    <p>Graduating high school can be a stressful or\r\n                    tiring process. If you’re feeling overwhelmed, it’s\r\n                    important to know that you’re not going through this\r\n                    educational journey alone and to focus on your\r\n                    mental health along with your academic progress. It\r\n                    can be helpful to reach out to a guidance counselor,\r\n                    trusted adult or school official, or friend for\r\n                    support. \r\n                        <ul>\r\n                            <li>If you’re having trouble with a\r\n                            particular class, you can schedule a meeting\r\n                            with your teacher to discuss the material,\r\n                            find a study group, or use online prep\r\n                            courses. \r\n                            </li>\r\n                            <li>If you’re having trouble with your\r\n                            overall schedule, don’t know what classes to\r\n                            take, or have questions about what it takes\r\n                            to graduate, your guidance counselor is a\r\n                            good, official source you can turn to for\r\n                            information specific to your school. An\r\n                            upperclassmen can also give you course\r\n                            recommendations based on their experiences.\r\n                            </li>\r\n                            <li>If you’re struggling with your mental\r\n                            health, it’s important to find balance in\r\n                            your schedule. If something particular is\r\n                            stressing you out, consulting the sources\r\n                            above can be helpful. If your mental health\r\n                            overall is deteriorating, confide in a\r\n                            trusted friend, family member, guidance\r\n                            counselor, or professional (such as a\r\n                            therapist). It’s important to make your\r\n                            mental health a priority. Making time for\r\n                            yourself, whether through a hobby or\r\n                            activity, can help you find balance. \r\n                            </li>\r\n                        </ul>\r\n                    </p>\r\n\r\n                    <div id=\"First_Sub_Point_5\" class=\"anchor\"></div>\r\n                        <h5>What happens after I graduate high\r\n                        school?</h5>\r\n                        <p>After you graduate high school, there are\r\n                        several options you can take both professionally\r\n                        and academically. You could enter the workforce\r\n                        directly, continue your education through\r\n                        college or university, go to trade school (for\r\n                        professions such as mechanic or electrician), go\r\n                        to military school and train to be in the armed\r\n                        forces, or take a gap year to pursue volunteer\r\n                        opportunities. After you accomplish this\r\n                        milestone, the opportunities available to you\r\n                        are widespread. It can be helpful to schedule a\r\n                        meeting with your guidance counselor or a\r\n                        trusted advisor or adult to work through your\r\n                        options and find the best path for you. \r\n                        </p>\r\n\r\n            </div>\r\n\r\n            <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n            <h5>GED Resources</h5>\r\n\r\n                <div class=\"subheading\">\r\n\r\n                    <div id=\"Second_Sub_Point_1\" class=\"anchor\"></div>\r\n                    <h5>What is the GED?</h5>\r\n                    <p>The GED is a certificate you can get by passing 4\r\n                    tests in the following subject areas: math, social\r\n                    sciences, science, and reasoning through language\r\n                    arts (RLA). Earning the GED certificate officially\r\n                    certifies that you have a set of educational\r\n                    knowledge and skills similar to a high school\r\n                    graduate’s.\r\n                    </p>\r\n                    \r\n                    <div id=\"Second_Sub_Point_2\" class=\"anchor\"></div>\r\n                    <h5>Should I get my GED?</h5>\r\n                    <p>If you didn’t finish high school, you might\r\n                    consider getting your GED. Getting your GED is an\r\n                    important educational milestone, and doing so can\r\n                    pave the way for future educational opportunities\r\n                    (such as trade school or college), higher future\r\n                    potential earnings, more employment opportunities,\r\n                    and a feeling of pride and accomplishment. While\r\n                    getting your GED may seem daunting at first, with\r\n                    the right study schedule, materials, and dedication,\r\n                    this milestone is well within your reach.\r\n                    </p>\r\n                    \r\n                    <div id=\"Second_Sub_Point_3\" class=\"anchor\"></div>\r\n                    <h5>How should I study?</h5>\r\n                    <p>\r\n                        <ul>\r\n                            <li>Everybody has a different learning\r\n                            style, and it’s important to find which one\r\n                            works for you. Making flashcards, finding a\r\n                            study group, watching videos, and noting\r\n                            down your weak areas are all potentially\r\n                            helpful strategies. There are a lot of\r\n                            online resources, such as videos and\r\n                            practice tests, to help you prepare. Your\r\n                            local library will often have free study\r\n                            materials as well. \r\n                            </li>\r\n                            <li>Make a plan that combines your favorite\r\n                            strategies, adjust the plan according to\r\n                            your availability, and follow it as best you\r\n                            can. Making a dedicated study plan early on\r\n                            can help you maximize your time and see the\r\n                            results you want. \r\n                            </li>\r\n                        </ul>\r\n                    </p>\r\n\r\n                    <div id=\"Second_Sub_Point_4\" class=\"anchor\"></div>\r\n                    <h5>How can I take the test?</h5>\r\n                    <p>\r\n                        <ul>\r\n                            <li>As long as you’re above 17 and not\r\n                            currently enrolled in high school, you’re\r\n                            eligible to take the GED test.\r\n                            </li>\r\n                            <li>Contact your state’s GED Testing\r\n                            Administrator to confirm your state’s\r\n                            testing fee. Usually, it costs around 120\r\n                            dollars to take the test. </li>\r\n                            <li>You can look up your state’s testing\r\n                            sites online. Register for a given time and\r\n                            place and record it in your calendar.\r\n                            </li>\r\n                            <li>You can take the test’s 4 sections all\r\n                            at once or separately, depending on what\r\n                            works best for you. \r\n                            </li>\r\n                        </ul>\r\n                    </p>\r\n\r\n                    <div id=\"Second_Sub_Point_5\" class=\"anchor\"></div>\r\n                    <h5>What score do I need to pass?</h5>\r\n                    <p>\r\n                        <ul>\r\n                            <li>Scores on the GED range from 100 to 200,\r\n                            with a score of 145 on any given section\r\n                            meaning you passed that section.\r\n                            </li>\r\n                            <li>To get the certificate, you must pass\r\n                            all 4 sections of the test. However, if you\r\n                            fail one section in particular (such as\r\n                            math), you don’t have to retake the other\r\n                            sections. Depending on your state, you can\r\n                            retake the test or any of its sections\r\n                            multiple times in a year. </li>\r\n                        </ul>\r\n                    </p>\r\n\r\n                </div>\r\n            \r\n            <div style=\"margin-top: 20px; width: 80%; word-wrap: break-word;\">\r\n                <p>Information from \r\n                    <a href=\"https://intellitec.edu/5-top-reasons-why-to-get-your-ged-certificate-and-how-to-do-it-quickly/#:~:text=GED%20training%20holds%20the%20key%20to%20a%20better%20future%2C%20for%20instance%3A&text=If%20you%20want%20to%20go,classes%20or%20trade%20school%20training.\">\r\n                        <em>https://intellitec.edu/5-top-reasons-why-to-get-your-ged-certificate-and-how-to-do-it-quickly/#:~:text=GED%20training%20holds%20the%20key%20to%20a%20better%20future%2C%20for%20instance%3A&text=If%20you%20want%20to%20go,classes%20or%20trade%20school%20training.</em>\r\n                    </a>\r\n                </p>\r\n            </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,13,6,12,5,4','','0','0',''),
('45','29','Military (Active Duty or Reserves)','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha684-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d6Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Military</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=41\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 What is a Military\r\n                College?\r\n                </a></li>\r\n                <li><a href=\"#Second_Point_Header\">2 What is it like to\r\n                go to a Military College?\r\n                </a></li>\r\n                <li><a href=\"#Third_Point_Header\">3 How do I pay for\r\n                Military College?\r\n                </a></li>\r\n                <li><a href=\"#Fourth_Point_Header\">4 How do I apply to a Military College? \r\n                </a></li>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n        <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n        <h5>What is a Military College?\r\n        </h5>\r\n        <ul>\r\n            <li>If you’re interested in serving in the military but\r\n            would still like to earn a college degree, going to military\r\n            college is an option that would let you pursue both of these\r\n            aims simultaneously. \r\n            </li>\r\n            <li>There are 3 types of military colleges: US Service\r\n            Academies, Senior Military Academies, and Military Junior\r\n            Colleges (two year institutions that offer Associate’s\r\n            Degrees). \r\n            </li>\r\n            <li>The 5 Service Academies in the USA (West Point, US Naval\r\n            Academy, US Merchant Marines, US Coast Guard, and US Air\r\n            Force), all train their students for service in different\r\n            branches of the US Military. Senior Military Colleges and\r\n            Military Junior Colleges are less selective in admissions. \r\n            </li>\r\n            <li>After graduation, many of these military colleges will\r\n            either offer you a job in the military or require you to\r\n            serve in the military for a certain number of years, making\r\n            the post-graduation job search less uncertain. For example,\r\n            the United States Military Academy (also known as West\r\n            Point), requires its students to serve in the military for\r\n            at least 5 years. \r\n            </li>\r\n        </ul>\r\n\r\n        <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n        <h5>What is it like to go to a Military College?\r\n        </h5>\r\n            <ul>   \r\n                <li>Alumni of these academies emphasize that their\r\n                undergraduate years were filled with discipline, rules,\r\n                and strict regulations. A typical day in a Service\r\n                Academy and other military colleges has mandatory\r\n                activities, homework time, and an emphasis on sports and\r\n                athletic activity. \r\n                </li>\r\n                <li>While the rigor of these colleges may be harsh, many\r\n                alumni appreciate the close relationships they’re able\r\n                to develop with fellow students and teachers through\r\n                their training.\r\n                </li>\r\n                </ul>\r\n\r\n            <div id=\"Third_Point_Header\" class=\"anchor\"></div>\r\n            <h5>How do I pay for Military College?            </h5>\r\n                <ul>   \r\n                    <li>Tuition, medical costs, and other costs are\r\n                    completely covered for all students by US Service\r\n                    Academies (such as West Point and the Air Force),\r\n                    making them a good option to consider financially.\r\n                    Your four years of undergraduate study would be\r\n                    covered, and employment is often guaranteed in the\r\n                    military following graduation. \r\n                    </li>\r\n                    <li>While other military colleges (such as Senior\r\n                    Military Colleges and Military Junior Colleges), may\r\n                    not be fully covered like Service Academies, many\r\n                    offer scholarships and financial aid. You can apply\r\n                    for a grant, need-based financial aid, or more\r\n                    specific programs, such as an ROTC scholarship. \r\n                    </li>\r\n                </ul>\r\n\r\n            <div id=\"Fourth_Point_Header\" class=\"anchor\"></div>\r\n            <h5>How do I apply to a Military College? \r\n            </h5>\r\n            <ul>   \r\n                <li>The 5 US Service Academies are very selective (with\r\n                the Naval Academy having an acceptance rate of 9%), and\r\n                their admission processes tend to be more rigorous than\r\n                other military colleges. \r\n                </li>\r\n                <li>For example, all US Service Academies (besides the\r\n                US Coast Guard), requires its applicants to submit a\r\n                congressional letter of recommendation (which can be\r\n                from a State Representative, Vice President, or even\r\n                President), along with transcripts, test scores (the ACT\r\n                or SAT), and essays. Students also have to pass a\r\n                physical and medical assessment. The physical assessment\r\n                will have a set of tasks, such as doing a certain number\r\n                of pushups.\r\n                </li>\r\n                <li>Senior Military Colleges and Military Junior\r\n                Colleges have a less rigorous admissions process and\r\n                higher acceptance rates, with applications similar to 4\r\n                year universities (asking for essays, transcripts, test\r\n                scores, etc). Some don’t require the ACT or SAT, and\r\n                some specific programs ask for a medical and physical\r\n                test.\r\n                </li>\r\n                <li>It can be helpful to visit a particular school’s\r\n                website to see specific admissions requirements and ask\r\n                specific questions about a school’s programs,\r\n                expectations, and degree programs. \r\n                </li>\r\n            </ul>\r\n           \r\n\r\n\r\n            <p>Information from: \r\n                <br>\r\n                <a\r\n                href=\" https://blog.prepscholar.com/us-military-colleges\"> https://blog.prepscholar.com/us-military-colleges</a>\r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('46','29','Trade School/Professional License','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha684-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d6Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Trade School</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=41\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 What is a trade\r\n                school?\r\n                </a></li>\r\n                <li><a href=\"#Second_Point_Header\">2 How do I apply for\r\n                a trade school program?\r\n                </a></li>\r\n                <li><a href=\"#Third_Point_Header\">3 Do I need\r\n                certifications?\r\n                </a></li>\r\n                <li><a href=\"#Fourth_Point_Header\">4 What are the top\r\n                professions for people without college degrees?\r\n                </a></li>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n        <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n        <h5>What is a trade school?\r\n        </h5>\r\n        <p>Some career paths (such as welder, blacksmith, car mechanic,\r\n        construction worker, medical assistant, and more), don’t always\r\n        require a college degree. Trade schools exist to train students\r\n        for these kinds of jobs, the ones that rely on technical,\r\n        mechanical, and hands-on skills. For example, an automotive\r\n        trade school focuses its curriculum around the mechanics of a\r\n        car, often providing students with opportunities to work\r\n        directly on car parts themselves.\r\n        </p>\r\n        <p>Trade school programs tend to be focused, flexible, and fast.\r\n        </p>\r\n        <ul>\r\n            <li>Focused: Students work with faculty from the field among\r\n            other students also interested in the field.\r\n            </li>\r\n            <li>Flexible: Many trade schools are flexible, letting you\r\n            work around family responsibilities or other jobs you have.\r\n            </li>\r\n            <li>Fast: Trade school programs can vary from a few months\r\n            to a few years in length, with an emphasis on teaching\r\n            students skills they would need to succeed in a job. Upon\r\n            graduation, a student would be prepared for an entry-level\r\n            position in the field. \r\n            </li>\r\n        </ul>\r\n\r\n        <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n        <h5>How do I apply for a trade school program?\r\n        </h5>\r\n        <p>While applying for a trade school, all of the following are\r\n        important factors to consider. \r\n        </p>\r\n            <ul>   \r\n                <li>All trade schools require either a high school\r\n                diploma or GED. \r\n                </li>\r\n                <li>Most trade schools don’t require any previous\r\n                experience in the field, and the applications tend to be\r\n                focused on your personal information (such as name,\r\n                physical limitations, address, and family) as well as\r\n                personal interest (why do you want to work in the\r\n                particular field the trade school trains you for? Is\r\n                there anything that would prevent you from succeeding in\r\n                that role? What skills do you have that would make you\r\n                well-suited for the role?)\r\n                </li>\r\n                <li>Does the school you’re interested in have an\r\n                application fee? What is the tuition fee? What\r\n                additional materials would you have to buy (textbooks,\r\n                equipment, etc)? Does the school have a financial aid\r\n                program? Knowing the answers to these questions is\r\n                important for you to make well-informed financial\r\n                decisions.\r\n                </li>\r\n                <li>If you have any questions about a specific trade\r\n                school program, you can contact the school directly.\r\n                Many of these programs have websites with helpful links,\r\n                FAQs, and other information to consider. \r\n                </li>\r\n                </ul>\r\n\r\n            <div id=\"Third_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Do I need certifications?\r\n            </h5>\r\n                <p>Depending on the career you choose, you might have to\r\n                get certain certifications. For example, to become a\r\n                dental assistant, you have to be certified in CPR. In\r\n                some states, to become a Home Health Aide (those who\r\n                help elderly patients with different tasks, such as\r\n                grocery shopping and hygiene needs), you must be\r\n                certified by either a trade school or nonprofit\r\n                organization. To know the specific requirements of the\r\n                career you choose, it can be helpful to contact your\r\n                academic advisor at the trade school you choose, or to\r\n                consult an online resource. \r\n                </p>\r\n\r\n            <div id=\"Fourth_Point_Header\" class=\"anchor\"></div>\r\n            <h5>What are the top professions for people without college\r\n            degrees?\r\n            </h5>\r\n            <ul>   \r\n                <li>There are a lot of fulfilling professions out there\r\n                that don’t require college degrees. \r\n                </li>\r\n                <li>Jobs such as medical assistant, dental assistant,\r\n                and Home Health Aide may require certifications given by\r\n                trade schools, but don’t need college degrees. Other job\r\n                fields that don’t require a college degree but are\r\n                projected to grow in the coming years include\r\n                electricians, plumbing, car mechanics, radiation\r\n                therapist, and plumbing. \r\n                </li>\r\n                <li>You can get any of these jobs with a trade school\r\n                certification instead of a traditional college degree.\r\n                In this way, trade schools provide an alternate path to\r\n                fulfilling careers without the traditional path of a 4\r\n                year degree. \r\n                </li>\r\n            </ul>\r\n           \r\n\r\n\r\n            <p>Information from: \r\n                <br>\r\n                <a\r\n                href=\"https://www.midwesttech.edu/resources/careers/what-is-a-trade-school/\r\n                \">\r\n                https://www.midwesttech.edu/resources/careers/what-is-a-trade-school/\r\n                \r\n            </a>\r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('48','29','Increasing Enjoyment in School','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha684-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d6Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Increasing Enjoyment in School</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=43\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 Take a varied course\r\n                load with different subjects\r\n                </a></li>\r\n                <li><a href=\"#Second_Point_Header\">2 Try new\r\n                extracurricular activities\r\n                </a></li>\r\n                <li><a href=\"#Third_Point_Header\">3 Make time for\r\n                yourself\r\n                </a></li>\r\n                <li><a href=\"#Fourth_Point_Header\">4 Give yourself\r\n                credit when you make mistakes\r\n                </a></li>\r\n                <li><a href=\"#Fifth_Point_Header\">5 Allow yourself to\r\n                feel what you feel and take care of your mental health\r\n                </a></li>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n        <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n        <h5>Take a varied course load with different subjects\r\n        </h5>\r\n        <ul>\r\n            <li>Depending on your major, graduation requirements, and\r\n            school, you might have to take a certain number of required\r\n            courses. \r\n            </li>\r\n            <li>However, most schools allow you a few classes (whether\r\n            electives, distributions, or other), that you can pick and\r\n            choose to your liking. For these classes, choosing subjects\r\n            that are different from your field of study can add variety\r\n            to your schedule. \r\n            </li>\r\n            <li>Is your major computer science? It might be fun to take\r\n            an art class, perhaps in photography or pottery, to use\r\n            skills you wouldn’t use in your more technical classes. Is\r\n            your major english? Try a class in astronomy or maybe a new\r\n            foreign language.\r\n            </li>\r\n            <li>Choose classes that you enjoy or classes you want to\r\n            explore simply for the sake of exploring. It’s okay to take\r\n            classes that aren’t directly related to your major, so long\r\n            as you enjoy them.  It’s okay to try something new or\r\n            explore something out of your comfort zone.\r\n            </li>\r\n            <li>Having a varied schedule, with some quantitative classes\r\n            and some qualitative classes, will help you find balance. \r\n            </li>\r\n        </ul>\r\n\r\n        <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n        <h5>Try new extracurricular activities\r\n        </h5>\r\n            <ul>   \r\n                <li>Joining a new extracurricular activity is a great\r\n                and fun way to explore an area outside your field of\r\n                study. These clubs don’t have to be academically\r\n                inclined (some clubs could be about baking, ultimate\r\n                frisbee, or even bird-watching)!\r\n                </li>\r\n                <li>These clubs can also be a great way to meet new\r\n                people that share your interests and make new friends.\r\n                Finding people who like what you like often makes the\r\n                college experience more enjoyable and less lonely. \r\n                </li>\r\n                <li>If there’s a subject you’re really interested in\r\n                (such as bird-watching), and your school doesn’t offer a\r\n                class in that area, an extracurricular activity is\r\n                another way to explore this interest. \r\n                </li>\r\n                <li>Don’t be afraid to try something new and explore\r\n                activities that your school offers. You could ask\r\n                upperclassmen or your advisors for recommendations.\r\n                </li>\r\n                </ul>\r\n\r\n            <div id=\"Third_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Make time for yourself            </h5>\r\n                <ul>   \r\n                    <li>School is a stressful time for students\r\n                    everywhere, and while you juggle all of your\r\n                    responsibilities, it can be easy to forget to take\r\n                    care of yourself and your mental health. It’s\r\n                    important though that you make time for yourself.\r\n                    Whether that’s through a hobby like baking or\r\n                    biking, or simply through watching TV, give yourself\r\n                    time to relax and breathe. It’s important to feel\r\n                    refreshed, and taking a break can help you focus\r\n                    more later.\r\n                    </li>\r\n                </ul>\r\n\r\n            <div id=\"Fourth_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Give yourself credit when you make mistakes\r\n            </h5>\r\n            <ul>   \r\n                <li>You’re doing an incredible thing, continuing your\r\n                educational journey and learning and growing. It’s okay\r\n                to make mistakes, to get a lower grade when you’ve\r\n                studied really hard or to not get into a certain club or\r\n                internship program. It’s okay to try your best and make\r\n                mistakes. Don’t consider these mistakes to be failures;\r\n                instead, consider them as steps in your educational\r\n                journey. Some steps will be high, others low, but\r\n                eventually, you will reach your goal, and your efforts\r\n                will pay off. It can be helpful, when you’re feeling bad\r\n                or frustrated, to match a positive with a negative. For\r\n                example, “I know I didn’t get into this internship, but\r\n                going through this application process forced me to\r\n                write a better resume, which can help me with the next\r\n                program I apply to”.  \r\n                </li>\r\n            </ul>\r\n\r\n\r\n            <div id=\"Fifth_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Allow yourself to feel what you feel and take care of\r\n            your mental health\r\n            </h5>\r\n            <ul>   \r\n                <li>It can be frustrating to make mistakes, to not get\r\n                into a club you wanted to get into, or to be rejected\r\n                from a program you were passionate about. Allow yourself\r\n                to feel whatever you’re feeling, whether that’s sadness\r\n                or frustration. Your feelings are valid, even when they\r\n                seem irrational. Let yourself cry or mourn, and don’t\r\n                let your feelings bottle up inside. \r\n                </li>\r\n                <li>If your feelings are overwhelming and make it\r\n                difficult for you to go about your daily life, consider\r\n                confiding in a trusted friend, family member, or school\r\n                counselor. A lot of schools have mental health resources\r\n                for their students, and don’t be afraid to ask for help\r\n                if you want it. \r\n                </li>\r\n                <li>It’s important to take care of your mental health by\r\n                letting yourself feel what you feel. Don’t be afraid to\r\n                ask for help, ask questions, and actively try to better\r\n                your mental health. Doing so can make your educational\r\n                experience more enjoyable and less stressful. \r\n            </ul>\r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('49','29','Study Skills','','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha684-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d6Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Study Skills</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=43\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 Identify how you\r\n                learn\r\n                </a></li>\r\n                <li><a href=\"#Second_Point_Header\">2 Identify your class\r\n                and situation\r\n                </a></li>\r\n                <li><a href=\"#Third_Point_Header\">3 Explore different\r\n                strategies and find what works best for you through\r\n                trial and error\r\n                </a></li>\r\n                <li><a href=\"#Fourth_Point_Header\">4 Make a plan and\r\n                schedule\r\n                </a></li>\r\n                <li><a href=\"#Fifth_Point_Header\">5 Breathe!\r\n                </a></li>\r\n            </ul>\r\n        </div>\r\n\r\n        <br>\r\n        <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n        <h5>Identify how you learn\r\n        </h5>\r\n        <ul>\r\n            <li>Different types of learners have different study\r\n            strategies that work best for them. \r\n            </li>\r\n            <li>If you’re an auditory learner and learn best through\r\n            sound, it could be helpful to (with permission), record your\r\n            teacher’s lectures and listen to them again before a test,\r\n            or to explain a concept verbally to yourself. \r\n            </li>\r\n            <li>If you’re a visual learner, it can be helpful to draw\r\n            diagrams of a process with arrows and pictures or to\r\n            color-code your notes.\r\n            </li>\r\n            <li>If you’re a more physical or hands on learner, you\r\n            probably like working with your hands and tangible objects.\r\n            It could be helpful to move around while you study or use 3D\r\n            models to visualize concepts. \r\n            </li>\r\n            <li>If you’re a social learner, you might like learning in\r\n            groups. It could be helpful to form a study group with your\r\n            classmates to go through important concepts before tests and\r\n            quizzes. \r\n            </li>\r\n            <li>If you’re a solitary learner, you learn best when you work alone instead of in groups. In this case, it could be helpful to make a designated study spot for yourself that’s free from distractions and away from others, such as at a desk or library. \r\n            </li>\r\n        </ul>\r\n\r\n        <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n        <h5>Identify your class and situation\r\n        </h5>\r\n            <ul>   \r\n                <li>Different classes require different types and kinds of study strategies.\r\n                </li>\r\n                <li>For example, math classes may require you to do more practice problems, while biology classes may require more memorization.\r\n                </li>\r\n                <li>Identify your class: is it more qualitative (english) or quantitative (math or science)? This will help you find the best set of study strategies for your situation.\r\n                </li>\r\n                </ul>\r\n\r\n            <div id=\"Third_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Explore different strategies and find what works best for you through trial and error.\r\n            </h5>\r\n            <p>Sometimes, the best way to learn is through trial and error. For example, if making flashcards helps you study for a psychology exam, it’s likely to help with other psychology exams. Consider the strategies below (and others), and pick and choose the combination that works best for the specific class and situation.\r\n            </p>\r\n                <ul>   \r\n                    <li>Make flashcards (physical paper or online)\r\n                    </li>\r\n                    <li>Work through practice questions\r\n                    </li>\r\n                    <li>Read over your notes\r\n                    </li>\r\n                    <li>Read through the textbook\r\n                    </li>\r\n                    <li>Go to a professor’s office hours or help session to ask questions\r\n                    </li>\r\n                    <li>Go to a teacher’s review session\r\n                    </li>\r\n                    <li>Make a study group with friends\r\n                    </li>\r\n                    <li>Draw models, diagrams, and visuals\r\n                    </li>\r\n                    <li>Try pretending you are a teacher and your friend is a student. Can you teach the concept to your friend in a way that helps them understand? That often indicates you know the material well\r\n                    </li>\r\n                    <li>Work through practice exams or old exams if the teacher provides them to you\r\n                    </li>\r\n                    <li>Go to a tutor or school-approved help resource\r\n                    </li>\r\n                    <li>Watch online videos on specific concepts\r\n                    </li>\r\n                    <li>Go over old homework assignments\r\n                    </li>\r\n                    <li>Look at old quizzes and tests that you took before. What questions did you miss? Why did you miss them? Do you understand those concepts now?\r\n                    </li>\r\n                    <li>Test yourself on key terms (whether through flashcards) or otherwise. You can cover up the word and see if you can recall the word based on the definition, or you could cover up the definition and see if you can recall the definition based on the word. Making sure you can do both ways could be helpful. \r\n                    </li>\r\n                    <li>Take a timed test. Try taking any practice test you are given with a time limit and in a quiet space to see how you’d perform in real circumstances. \r\n                    </li>\r\n                </ul>\r\n\r\n            <div id=\"Fourth_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Make a plan and schedule\r\n            </h5>\r\n            <ul>   \r\n                <li>Once you’ve picked your favorite strategies based on your own personal learning style and the type of class/test, it’s important to make a schedule.\r\n                </li>\r\n                <li>How much time do you have to study, and how much do you want to study? If the test is in a week, consider setting aside an hour a day to study, focusing on a different section of material each day.\r\n                </li>\r\n                <li>You can use an online calendar and timers to help you stick to the strategy you outlined. \r\n                </li>\r\n            </ul>\r\n\r\n\r\n            <div id=\"Fifth_Point_Header\" class=\"anchor\"></div>\r\n            <h5>Breathe!\r\n            </h5>\r\n            <ul>   \r\n                <li>By the time the test comes around, you might be nervous or stressed. Take a deep breath. You’ve worked hard, studied hard, stuck to your plan, and learned the material to the best of your ability.\r\n                </li>\r\n                <li>Even if you don’t get the grade you wanted, you can learn from your study process and refine it for next time. For now, you’ve got this!\r\n                </li>\r\n            </ul>\r\n\r\n            <p>Information on Types of Learners from:\r\n                <br>\r\n                <a href=\"https://www.literacyplanet.com/au/news/engage-7-types-learners-classroom/\">https://www.literacyplanet.com/au/news/engage-7-types-learners-classroom/</a>\r\n                </p>\r\n        </div>\r\n\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,6,12,5,4','','0','0',''),
('50','29','Community College/College/University','Community College/College/University','','','<!doctype html>\r\n\r\n<html lang=\"en\">\r\n\r\n<head>\r\n    <meta charset=\"utf-8\">\r\n    <link rel=\"stylesheet\"\r\n    href=\"https://use.fontawesome.com/releases/v5.15.1/css/all.css\"\r\n    integrity=\"sha384-vp86vTRFVJgpjF9jiIGPEEqYqlDwgyBgEF109VFjmqGmIY/Y4HV4d3Gp2irVfcrp\"\r\n    crossorigin=\"anonymous\">\r\n    <title>Community College / College / University</title>\r\n</head>\r\n\r\n<body>\r\n    <a class=\"back-icon\"\r\n    href=\"index.php?module=ext/ipages/view&id=41\">\r\n        <i class=\"fas fa-angle-left\"></i> Back\r\n    </a>\r\n    <hr />\r\n    <div class=\"page-wrapper\">\r\n        <div id=\"toc_container\">\r\n            <p class=\"toc_title\">Contents</p>\r\n            <ul class=\"toc_list\">\r\n                <li><a href=\"#First_Point_Header\">1 Community\r\n                College</a></li>\r\n                <li><a href=\"#Second_Point_Header\">2 How do I apply to a\r\n                Community College?</a></li>\r\n                <li><a href=\"#Third_Point_Header\">3 Traditional\r\n                College</a>\r\n                <li><a href=\"#Fourth_Point_Header\">4 How do I apply to a\r\n                traditional college?</a>\r\n                    <ul>\r\n                        <li><a href=\"#Fourth_Sub_Point_1\">4.1 Make a\r\n                        list of what you want from a college\r\n                        </a></li>\r\n                        <li><a href=\"#Fourth_Sub_Point_2\">4.2 How do you\r\n                        apply to a particular college?\r\n                        </a></li>\r\n                        <li><a href=\"#Fourth_Sub_Point_3\">4.3 Gather\r\n                        your materials\r\n                        </a></li>\r\n                        <li><a href=\"#Fourth_Sub_Point_4\">4.4 Know\r\n                        deadlines and terminology</a></li>\r\n                        <li><a href=\"#Fourth_Sub_Point_5\">4.5 Ask for\r\n                        help if you need it!</a></li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n        </div>\r\n\r\n            <p>After graduating high school or getting your GED, you\r\n            might consider going further in your academic career, maybe\r\n            by attending community college or university. No matter\r\n            which option you choose, doing so can improve your\r\n            professional career in the future, leading to more\r\n            opportunities (such as the ability to become a doctor or\r\n            lawyer), higher pay, and more knowledge. Whether you go to\r\n            community college depends on your own circumstances and\r\n            needs. \r\n            </p>\r\n            <br>\r\n            <div id=\"First_Point_Header\" class=\"anchor\"></div>\r\n            <h2>Community College</h2>\r\n            <p>Community colleges are two-year institutions, and\r\n            different community colleges have different purposes. Some\r\n            prepare students to transfer to traditional four-year\r\n            institutions (such as colleges and universities), while\r\n            others prepare students directly for industry jobs.\r\n            Community colleges are usually significantly less expensive\r\n            than traditional universities, have smaller classes, and\r\n            more individualized attention. \r\n            </p>\r\n            <p>If any of the following apply to you, community college\r\n            might be a better option for you than traditional college.\r\n            </p>\r\n            <ul>\r\n                <li><em>Traditional college is too expensive for you\r\n                right now.</em>\r\n                    <ul>\r\n                        <li>Traditional colleges can cost tens of\r\n                        thousands of dollars. For many people, a more\r\n                        accessible way of getting a four year degree is\r\n                        attending a community college for the first\r\n                        couple of years and then transferring to a four\r\n                        year institution. \r\n                        </li>\r\n                    </ul>\r\n                </li>\r\n                <li><em>You want a flexible schedule.</em>\r\n                    <ul>\r\n                        <li>If you want to get a degree, but need to\r\n                        attend classes part-time (for example, because\r\n                        of family obligations), community college can be\r\n                        a good option for you. These institutions allow\r\n                        you to pursue a degree at your own pace and take\r\n                        classes depending on your availability, when\r\n                        compared to traditional colleges that often have\r\n                        stricter requirements. </li>\r\n                    </ul>\r\n                </li>\r\n                <li><em>You’re not sure about your GPA, extracurricular\r\n                activities, or test scores.</em>\r\n                    <ul>\r\n                        <li>If your GPA is lower than you’d like, or you\r\n                        believe your test scores aren’t high enough for\r\n                        a lot of traditional colleges, you could\r\n                        consider going to community college first,\r\n                        getting high grades in your classes, then\r\n                        transferring to a four-year institution with\r\n                        your new resume. </li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n            <div id=\"Second_Point_Header\" class=\"anchor\"></div>\r\n            <h2>How do I apply to a Community College?\r\n            </h2>\r\n            <p>While community colleges in different states have\r\n            different requirements, most ask for your name, address,\r\n            your citizenship status, proof of residency, and either high\r\n            school diploma or GED certificate. Many ask you for your\r\n            goal (transferring to a 4 year university, going straight\r\n            into the workforce, etc). Make a list of each college’s\r\n            requirements and read about the school itself before\r\n            applying. It’s important to make sure the school you choose\r\n            can give you what you want, whether that’s a certain degree,\r\n            flexibility, financial aid, etc. You can schedule a meeting\r\n            with a representative from the college if you have any\r\n            school-specific questions. \r\n            </p>\r\n            <p>Information from: <a\r\n                href=\"https://blog.prepscholar.com/how-to-apply-for-community-college\r\n                \">https://blog.prepscholar.com/how-to-apply-for-community-college</a></p>\r\n                \r\n            <div id=\"Third_Point_Header\" class=\"anchor\"></div>\r\n            <h2>Traditional College</h2>\r\n            <p>Traditional colleges and universities tend to be\r\n            four-year institutions that offer bachelor’s degrees in\r\n            various subjects, from biology to business. While\r\n            traditional colleges tend to be more expensive than\r\n            community colleges, traditional colleges tend to have a more\r\n            diverse variety of classes to choose from and a larger\r\n            network of alumni, professors, and fellow students. \r\n            </p>\r\n            <p>If any of the following apply to you, traditional college\r\n            might be a better option for you than community college.\r\n            </p>\r\n            <ul>\r\n                <li><em>You have a specific career path or degree in\r\n                mind.\r\n                </em>\r\n                    <ul>\r\n                        <li>Traditional colleges tend to have a wider\r\n                        offering of degrees and majors to choose from.\r\n                        If there’s a specific field you’d like to pursue\r\n                        (such as architecture), it might be helpful for\r\n                        you to attend a traditional college to \r\n\r\n                        </li>\r\n                    </ul>\r\n                </li>\r\n                <li><em>You want more school resources.\r\n                </em>\r\n                    <ul>\r\n                        <li>Because of larger student bodies, larger\r\n                        alumni networks, and having more professors,\r\n                        traditional universities tend to have more\r\n                        resources than community colleges. Resources\r\n                        include more advisors, a larger alumni network,\r\n                        more university-sponsored opportunities (such as\r\n                        internships), and more.</li>\r\n                    </ul>\r\n                </li>\r\n                <li><em>You want a close-knit community of students.\r\n                </em>\r\n                    <ul>\r\n                        <li>Many community college students commute from\r\n                        their homes to campus, or they live in\r\n                        apartments off-campus. Because community\r\n                        colleges tend to be more flexible regarding\r\n                        schedules, allowing students to complete course\r\n                        requirements at their own pace, most of their\r\n                        students aren’t on the same academic track. On\r\n                        the other hand, in traditional colleges, most\r\n                        freshmen students live in campus dorms and\r\n                        follow the same academic calendar (with finals\r\n                        during the same period, same vacations, etc),\r\n                        leading to a more tight knit student community. \r\n                        </li>\r\n                    </ul>\r\n                </li>\r\n            </ul>\r\n\r\n            <div id=\"Fourth_Point_Header\" class=\"anchor\"></div>\r\n            <h2>How do I apply to a traditional college?</h2>\r\n            <p>Traditional colleges tend to have stricter and more\r\n            varied requirements than community colleges. To apply to a\r\n            traditional college, below are a few steps to consider.\r\n            </p>\r\n                <div class=\"subheading\">\r\n\r\n                    <div id=\"Fourth_Sub_Point_1\" class=\"anchor\"></div>\r\n                    <h5>Make a list of what you want from a\r\n                    college.</h5>\r\n                    <p>Do you prefer a smaller or larger campus? A\r\n                    college close to home or in a different state? What\r\n                    do you want to major in, and does the school have a\r\n                    good program for it? Does the school offer good\r\n                    financial aid? Considering all of these questions\r\n                    can help you narrow your search down to a few\r\n                    colleges to apply to. \r\n\r\n                    </p>\r\n                    \r\n                    <div id=\"Fourth_Sub_Point_2\" class=\"anchor\"></div>\r\n                    <h5>How do you apply to a particular college?\r\n                    </h5>\r\n                    <p>Some colleges let you apply through the online\r\n                    platform CommonApp, while other colleges have their\r\n                    own admission portals. Some colleges just ask for\r\n                    transcripts, recommendations, and extracurricular\r\n                    activities, while others also ask you to answer\r\n                    essay questions. Knowing what a college is asking\r\n                    for gives you time to gather all the needed\r\n                    materials and apply before deadlines. \r\n\r\n                    </p>\r\n                    \r\n                    <div id=\"Fourth_Sub_Point_3\" class=\"anchor\"></div>\r\n                    <h5>Gather your materials.\r\n                    </h5>\r\n                    <p>\r\n                        Colleges can ask for a lot of information from\r\n                        you, and keeping track of all of the\r\n                        requirements will help organize the application\r\n                        process. Do you need to request your transcript?\r\n                        Ask a teacher for a recommendation letter? Take\r\n                        the SAT or ACT tests? Work on your essays? Know\r\n                        what materials the school is requesting and make\r\n                        sure you have them in your application. \r\n                    </p>\r\n\r\n                    <div id=\"Fourth_Sub_Point_4\" class=\"anchor\"></div>\r\n                    <h5>Know deadlines and terminology.\r\n                    </h5>\r\n                    <p>\r\n                        Some schools have early admission deadlines in\r\n                        October or November, while others have regular\r\n                        admission deadlines in December. Some colleges\r\n                        have early decision deadlines in October or\r\n                        November. While early action and regular\r\n                        decision are not binding, early decision results\r\n                        are. Make sure you keep track the kinds of\r\n                        applications you submit (early action, early\r\n                        decision, and other terminology), and their\r\n                        respective deadlines. \r\n                    </p>\r\n\r\n                    <div id=\"Fourth_Sub_Point_5\" class=\"anchor\"></div>\r\n                    <h5>Ask for help if you need it!\r\n                    </h5>\r\n                    <p>\r\n                        The college application process can be daunting,\r\n                        so don’t be afraid to ask for help if you need\r\n                        it! You could ask a school guidance counselor, a\r\n                        trusted teacher, a trusted adult, or a friend\r\n                        for advice if you’re feeling lost or\r\n                        overwhelmed. Every college has an email address\r\n                        or official you can talk to for school-specific\r\n                        questions as well. \r\n                    </p>\r\n                \r\n                </div>\r\n    <script>\r\n    </script>\r\n</body>\r\n\r\n</html>','0,13,6,12,5,4','','0','0','');

CREATE TABLE IF NOT EXISTS `app_ext_item_pivot_tables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `allowed_groups` text NOT NULL,
  `sort_order` int NOT NULL,
  `related_entities_id` int NOT NULL,
  `related_entities_fields` text NOT NULL,
  `position` varchar(16) NOT NULL,
  `rows_per_page` int NOT NULL,
  `fields_in_listing` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_related_entities_id` (`related_entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_item_pivot_tables_calcs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reports_id` int NOT NULL,
  `type` varchar(16) NOT NULL,
  `name` varchar(64) NOT NULL,
  `formula` text NOT NULL,
  `select_query` text NOT NULL,
  `where_query` text NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_items_export_templates_blocks` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int NOT NULL,
  `templates_id` int NOT NULL,
  `block_type` varchar(32) NOT NULL,
  `fields_id` int NOT NULL,
  `settings` text NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `templates_id` (`templates_id`),
  KEY `fields_id` (`fields_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_kanban` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `in_menu` tinyint(1) NOT NULL DEFAULT '0',
  `heading_template` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `group_by_field` int NOT NULL,
  `exclude_choices` text NOT NULL,
  `fields_in_listing` text NOT NULL,
  `sum_by_field` text NOT NULL,
  `width` int NOT NULL,
  `users_groups` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accounts_id` int NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  `is_new` tinyint(1) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `subject_cropped` varchar(255) NOT NULL,
  `groups_id` int NOT NULL,
  `is_new_group` tinyint(1) NOT NULL,
  `body` longtext NOT NULL,
  `body_text` longtext NOT NULL,
  `to_name` text NOT NULL,
  `to_email` text NOT NULL,
  `from_name` varchar(255) NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `reply_to_name` text NOT NULL,
  `reply_to_email` text NOT NULL,
  `cc_name` text NOT NULL,
  `cc_email` text NOT NULL,
  `bcc_name` text NOT NULL,
  `bcc_email` text NOT NULL,
  `attachments` text NOT NULL,
  `error_msg` tinytext NOT NULL,
  `is_sent` tinyint(1) NOT NULL,
  `is_star` tinyint(1) NOT NULL,
  `in_trash` tinyint(1) NOT NULL,
  `is_spam` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`),
  KEY `idx_groups_id` (`groups_id`),
  KEY `idx_to_email` (`to_email`(128)),
  KEY `idx_from_email` (`from_email`(128))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL,
  `name` varchar(64) NOT NULL,
  `is_default` tinyint(1) NOT NULL,
  `bg_color` varchar(16) NOT NULL,
  `imap_server` varchar(255) NOT NULL,
  `mailbox` varchar(64) NOT NULL,
  `login` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `delete_emails` tinyint(1) NOT NULL,
  `is_fetched` tinyint(1) NOT NULL,
  `use_smtp` tinyint(1) NOT NULL,
  `smtp_server` varchar(255) NOT NULL,
  `smtp_port` varchar(16) NOT NULL,
  `smtp_encryption` varchar(16) NOT NULL,
  `smtp_login` varchar(64) NOT NULL,
  `smtp_password` varchar(64) NOT NULL,
  `send_autoreply` tinyint(1) NOT NULL,
  `autoreply_msg` text NOT NULL,
  `not_group_by_subject` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts_entities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accounts_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `parent_item_id` int NOT NULL,
  `from_name` int NOT NULL,
  `from_email` int NOT NULL,
  `subject` int NOT NULL,
  `body` int NOT NULL,
  `attachments` int NOT NULL,
  `bind_to_sender` tinyint(1) NOT NULL,
  `auto_create` int NOT NULL,
  `title` varchar(64) NOT NULL,
  `hide_buttons` varchar(64) NOT NULL,
  `fields_in_listing` text NOT NULL,
  `fields_in_popup` text NOT NULL,
  `related_emails_position` varchar(16) NOT NULL,
  `sort_order` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_parent_item_id` (`parent_item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts_entities_fields` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `account_entities_id` int unsigned NOT NULL,
  `filters_id` int NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_account_entities_id` (`account_entities_id`) USING BTREE,
  KEY `idx_filters_id` (`filters_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts_entities_filters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_entities_id` int NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `has_words` text NOT NULL,
  `parent_item_id` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_account_entities_id` (`account_entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts_entities_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `account_entities_id` int NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `has_words` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_account_entities_id` (`account_entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_accounts_users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accounts_id` int NOT NULL,
  `users_id` int NOT NULL,
  `send_mail_as` varchar(128) NOT NULL,
  `signature` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_contacts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accounts_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`),
  KEY `idx_name` (`name`(128)),
  KEY `idx_email` (`email`(128))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_filters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accounts_id` int NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `has_words` text NOT NULL,
  `action` varchar(32) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_accounts_id` (`accounts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `accounts_id` int NOT NULL,
  `subject_cropped` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_check` (`accounts_id`,`subject_cropped`(191)) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mail_groups_from` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mail_groups_id` int NOT NULL,
  `from_email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_mail_groups_id` (`mail_groups_id`,`from_email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `app_ext_mail_to_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `mail_groups_id` int NOT NULL,
  `from_email` varchar(255) NOT NULL,
  `entities_id` int NOT NULL,
  `items_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_mail_groups_id` (`mail_groups_id`) USING BTREE,
  KEY `idx_from_email` (`from_email`(128))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_map_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `fields_id` int NOT NULL,
  `users_groups` text NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `background` int NOT NULL,
  `fields_in_popup` text NOT NULL,
  `zoom` tinyint(1) NOT NULL,
  `latlng` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_mind_map` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `fields_id` int NOT NULL,
  `users_groups` text NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `use_background` int NOT NULL,
  `icons` text NOT NULL,
  `fields_in_popup` text NOT NULL,
  `shape` varchar(16) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_modules` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(32) NOT NULL,
  `module` varchar(64) NOT NULL,
  `sort_order` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_modules VALUES
('1','1','smart_input','smartystreets','0'),
('2','1','sms','twilio','0');

CREATE TABLE IF NOT EXISTS `app_ext_modules_cfg` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `modules_id` int unsigned NOT NULL,
  `cfg_key` varchar(64) NOT NULL,
  `cfg_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_modules_id` (`modules_id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivot_calendars` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `default_view` varchar(16) NOT NULL,
  `view_modes` varchar(255) NOT NULL,
  `event_limit` smallint NOT NULL DEFAULT '6',
  `highlighting_weekends` varchar(64) NOT NULL,
  `min_time` varchar(5) NOT NULL,
  `max_time` varchar(5) NOT NULL,
  `time_slot_duration` varchar(8) NOT NULL,
  `display_legend` tinyint(1) NOT NULL DEFAULT '0',
  `in_menu` tinyint(1) NOT NULL,
  `users_groups` text NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_pivot_calendars VALUES
('2','Milestone Calendar','month','month,agendaWeek','6','','','','00:30:00','1','1','{\"13\":\"\",\"6\":\"view\",\"12\":\"full\",\"5\":\"full\",\"4\":\"full\"}','0');

CREATE TABLE IF NOT EXISTS `app_ext_pivot_calendars_entities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `calendars_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `bg_color` varchar(10) NOT NULL,
  `start_date` int NOT NULL,
  `end_date` int NOT NULL,
  `heading_template` varchar(64) NOT NULL,
  `fields_in_popup` text NOT NULL,
  `background` varchar(10) NOT NULL,
  `use_background` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_calendars_id` (`calendars_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_pivot_calendars_entities VALUES
('2','2','83','#f09300','995','996','[1002]','1022,1013','','1008');

CREATE TABLE IF NOT EXISTS `app_ext_pivot_map_reports` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `users_groups` text NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `zoom` tinyint(1) NOT NULL,
  `latlng` varchar(16) NOT NULL,
  `display_legend` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivot_map_reports_entities` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `reports_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `background` int NOT NULL,
  `fields_in_popup` text NOT NULL,
  `marker_color` varchar(16) NOT NULL,
  `marker_icon` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_reports_id` (`reports_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_pivot_tables` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `filters_panel` varchar(16) NOT NULL,
  `height` smallint NOT NULL,
  `users_groups` text NOT NULL,
  `sort_order` int NOT NULL,
  `chart_type` varchar(16) NOT NULL,
  `chart_position` varchar(16) NOT NULL,
  `chart_height` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_pivot_tables VALUES
('1','83','Milestone Progress','0','quick_filters','0','{\"13\":\"view\",\"6\":\"view\",\"12\":\"full\",\"5\":\"full\",\"4\":\"full\"}','0','pie','left','0'),
('4','83','Milestone Category Breakdown','0','quick_filters','0','{\"13\":\"\",\"6\":\"\",\"12\":\"\",\"5\":\"\",\"4\":\"\"}','0','pie','left','0'),
('5','1','User Age Distribution','0','quick_filters','0','{\"13\":\"\",\"6\":\"\",\"12\":\"\",\"5\":\"\",\"4\":\"\"}','0','pie','left','0'),
('6','1','User State Distribution','0','quick_filters','0','{\"13\":\"\",\"6\":\"\",\"12\":\"\",\"5\":\"\",\"4\":\"\"}','0','column','left','0');

CREATE TABLE IF NOT EXISTS `app_ext_pivot_tables_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reports_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `fields_name` varchar(64) NOT NULL,
  `cfg_date_format` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entitites_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `reports_id` (`reports_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_pivot_tables_fields VALUES
('2','1','83','1008','',''),
('7','5','1','617','',''),
('10','6','1','371','',''),
('11','6','1','379','',''),
('13','4','83','1065','','');

CREATE TABLE IF NOT EXISTS `app_ext_pivot_tables_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reports_id` int NOT NULL,
  `users_id` int NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_pivot_tables_settings VALUES
('1','1','0','{\"dataSource\":{\"dataSourceType\":\"csv\",\"filename\":\"https://54.197.88.140/ourreach/index.php?module=ext/pivot_tables/view&action=get_csv&id=1\"},\"slice\":{\"rows\":[{\"uniqueName\":\"Status\"}],\"columns\":[{\"uniqueName\":\"Measures\"}],\"measures\":[{\"uniqueName\":\"Status\",\"aggregation\":\"count\",\"availableAggregations\":[\"count\",\"distinctcount\"]}]}}'),
('2','4','0','{\"dataSource\":{\"dataSourceType\":\"csv\",\"filename\":\"https://54.197.88.140/ourreach/index.php?module=ext/pivot_tables/view&action=get_csv&id=4\"},\"slice\":{\"rows\":[{\"uniqueName\":\"Category\"}],\"columns\":[{\"uniqueName\":\"Measures\"}],\"measures\":[{\"uniqueName\":\"Category\",\"aggregation\":\"count\",\"availableAggregations\":[\"count\",\"distinctcount\"]}]}}'),
('3','5','0','{\"dataSource\":{\"dataSourceType\":\"csv\",\"filename\":\"https://54.197.88.140/ourreach/index.php?module=ext/pivot_tables/view&action=get_csv&id=5\"},\"slice\":{\"rows\":[{\"uniqueName\":\"Age\"}],\"columns\":[{\"uniqueName\":\"Measures\"}],\"measures\":[{\"uniqueName\":\"Age\",\"aggregation\":\"count\",\"availableAggregations\":[\"count\",\"distinctcount\"]}]}}'),
('4','6','0','{\"dataSource\":{\"dataSourceType\":\"csv\",\"filename\":\"https://54.197.88.140/ourreach/index.php?module=ext/pivot_tables/view&action=get_csv&id=6\"},\"slice\":{\"rows\":[{\"uniqueName\":\"State\"},{\"uniqueName\":\"Gender\"}],\"columns\":[{\"uniqueName\":\"Measures\"}],\"measures\":[{\"uniqueName\":\"State\",\"aggregation\":\"count\",\"availableAggregations\":[\"count\",\"distinctcount\"]}]}}');

CREATE TABLE IF NOT EXISTS `app_ext_pivotreports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `allowed_groups` text NOT NULL,
  `allow_edit` tinyint(1) NOT NULL,
  `cfg_numer_format` varchar(64) NOT NULL,
  `sort_order` int NOT NULL,
  `reports_settings` text NOT NULL,
  `view_mode` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_pivotreports VALUES
('15','1','User Demographics','12,5,4','0','','0','{\n  \\\"derivedAttributes\\\": {},\n  \\\"hiddenAttributes\\\": [],\n  \\\"menuLimit\\\": 200,\n  \\\"cols\\\": [\n    \\\"City\\\"\n  ],\n  \\\"rows\\\": [\n    \\\"Gender\\\"\n  ],\n  \\\"vals\\\": [],\n  \\\"exclusions\\\": {},\n  \\\"inclusions\\\": {},\n  \\\"unusedAttrsVertical\\\": 85,\n  \\\"autoSortUnusedAttrs\\\": false,\n  \\\"aggregatorName\\\": \\\"Count\\\",\n  \\\"rendererName\\\": \\\"Stacked Bar Chart\\\",\n  \\\"inclusionsInfo\\\": {}\n}','0');

CREATE TABLE IF NOT EXISTS `app_ext_pivotreports_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `pivotreports_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `fields_name` varchar(64) NOT NULL,
  `cfg_date_format` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_pivotreports_id` (`pivotreports_id`),
  KEY `idx_entitites_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_pivotreports_fields VALUES
('46','15','1','370','',''),
('47','15','1','379','',''),
('48','15','1','376','','');

CREATE TABLE IF NOT EXISTS `app_ext_pivotreports_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reports_id` int NOT NULL,
  `users_id` int NOT NULL,
  `reports_settings` text NOT NULL,
  `view_mode` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_processes` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `button_title` varchar(64) NOT NULL,
  `button_position` varchar(255) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `access_to_assigned` text NOT NULL,
  `confirmation_text` text NOT NULL,
  `allow_comments` tinyint unsigned NOT NULL,
  `preview_prcess_actions` tinyint unsigned NOT NULL,
  `notes` text NOT NULL,
  `payment_modules` varchar(64) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `apply_fields_access_rules` tinyint(1) NOT NULL DEFAULT '0',
  `apply_fields_display_rules` tinyint(1) NOT NULL,
  `hide_entity_name` tinyint(1) NOT NULL DEFAULT '0',
  `success_message` text NOT NULL,
  `redirect_to_items_listing` tinyint(1) NOT NULL DEFAULT '0',
  `disable_comments` tinyint(1) NOT NULL,
  `javascript_in_from` text NOT NULL,
  `javascript_onsubmit` text NOT NULL,
  `sort_order` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_processes VALUES
('1','46','Mark milestone as complete','Mark as complete','default','#0ae321','fa-check','0,6,12,5,4','','','Are you sure you want to mark this milestone as completed?','0','0','','','1','0','0','0','Congratulations on reaching your milestone!','0','0','','','0'),
('3','49','Mark goal as complete','Mark as complete','default,menu_with_selected','##0ae32','fa-check','0,6,12,5,4','','','Are you sure you want to mark this goal as completed?','0','0','','','1','0','0','0','Congratulations on reaching your goal!','0','0','','','0'),
('5','72','Complete Education Milestone','Mark as complete','default,menu_with_selected','#33b679','fa-check','0,6,12,5,4','','','Are you sure you want to mark this milestone as complete?','0','0','','','1','0','0','0','Congratulations on reaching your milestone!','0','0','','','0'),
('6','82','Complete Health Milestone','Mark as complete','default,menu_with_selected','#33b679','fa-check','0,6,12,5,4','','','Are you sure you want to mark this milestone as complete?','0','0','','','1','0','0','0','Congratulations on reaching your milestone!','0','0','','','0'),
('7','78','Complete Housing Milestone','Mark as complete','default,menu_with_selected','#33b679','fa-check','0,6,12,5,4','','','Are you sure you want to mark this milestone as complete?','0','0','','','1','0','0','0','Congratulations on reaching your milestone!','0','0','','','0'),
('8','79','Complete Jobs Milestone','Mark as complete','default,menu_with_selected','#33b679','fa-check','0,6,12,5,4','','','Are you sure you want to mark this milestone as complete?','0','0','','','1','0','0','0','Congratulations on reaching your milestone!','0','0','','','0'),
('9','80','Tips for Goals & Support Milestones','Mark as complete','default,menu_with_selected','#33b679','fa-check','0,6,12,5,4','','','Are you sure you want to mark this milestone as complete?','0','0','','','1','0','0','0','Congratulations on reaching your milestone!','0','0','','','0'),
('10','81','Complete Other Milestone','Mark as complete','default,menu_with_selected','#33b679','fa-check','0,6,12,5,4','','','Are you sure you want to mark this milestone as complete?','0','0','','','1','0','0','0','Congratulations on reaching your milestone!','0','0','','','0'),
('11','83','Complete Milestone','Mark as complete','default','#33b679','fa-check','0,6,12,5,4','','','Are you sure you want to mark this milestone as complete?','0','0','','','1','0','0','0','Congratulations on reaching your milestone!','0','0','','','0'),
('12','84','Complete Recurring Goal','Mark as complete','default,in_listing','#33b679','fa-check','0,6,12,5,4','','','Are you sure you want to mark this recurring goal as complete?','0','0','','','1','0','0','0','Congratulations on reaching your goal!','0','0','','','0');

CREATE TABLE IF NOT EXISTS `app_ext_processes_actions` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `process_id` int unsigned NOT NULL,
  `type` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `sort_order` smallint NOT NULL,
  `settings` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_process_id` (`process_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_processes_actions VALUES
('1','1','edit_item_entity_46','','1',''),
('3','3','edit_item_entity_49','','1',''),
('6','5','edit_item_entity_72','','1',''),
('8','6','edit_item_entity_82','','1',''),
('11','7','edit_item_entity_78','','1',''),
('12','8','edit_item_entity_79','','1',''),
('14','9','edit_item_entity_80','','1',''),
('16','10','edit_item_entity_81','','1',''),
('18','11','edit_item_entity_83','','1',''),
('19','12','edit_item_entity_84','','1','');

CREATE TABLE IF NOT EXISTS `app_ext_processes_actions_fields` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `actions_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `value` text NOT NULL,
  `enter_manually` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_actions_id` (`actions_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_processes_actions_fields VALUES
('1','1','510','86','0'),
('4','3','528','true','0'),
('7','6','791','91','0'),
('9','8','856','93','0'),
('12','11','885','95','0'),
('13','12','914','97','0'),
('15','14','943','99','0'),
('17','16','972','101','0'),
('19','18','1008','103','0'),
('20','19','1043','true','0');

CREATE TABLE IF NOT EXISTS `app_ext_processes_buttons_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `button_position` varchar(64) NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_processes_clone_subitems` (
  `id` int NOT NULL AUTO_INCREMENT,
  `actions_id` int NOT NULL,
  `parent_id` int NOT NULL,
  `from_entity_id` int NOT NULL,
  `to_entity_id` int NOT NULL,
  `fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_from_entity_id` (`from_entity_id`),
  KEY `idx_to_entity_id` (`to_entity_id`),
  KEY `idx_actions_id` (`actions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_public_forms` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int unsigned NOT NULL,
  `parent_item_id` int NOT NULL,
  `hide_parent_item` tinyint(1) NOT NULL,
  `name` varchar(64) NOT NULL,
  `notes` text NOT NULL,
  `page_title` varchar(255) NOT NULL,
  `button_save_title` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `successful_sending_message` text NOT NULL,
  `after_submit_action` varchar(32) NOT NULL,
  `after_submit_redirect` varchar(255) NOT NULL,
  `user_agreement` text NOT NULL,
  `hidden_fields` text NOT NULL,
  `customer_name` varchar(64) NOT NULL,
  `customer_email` int NOT NULL,
  `customer_message_title` varchar(255) NOT NULL,
  `customer_message` text NOT NULL,
  `admin_name` varchar(64) NOT NULL,
  `admin_email` varchar(64) NOT NULL,
  `admin_notification` tinyint(1) NOT NULL,
  `check_enquiry` tinyint(1) NOT NULL,
  `disable_submit_form` tinyint(1) NOT NULL,
  `check_page_title` varchar(255) NOT NULL,
  `check_page_description` text NOT NULL,
  `check_button_title` varchar(64) NOT NULL,
  `check_page_fields` text NOT NULL,
  `check_page_comments` tinyint(1) NOT NULL,
  `check_page_comments_heading` varchar(255) NOT NULL,
  `check_page_comments_fields` text NOT NULL,
  `notify_field_change` int unsigned NOT NULL,
  `notify_message_title` varchar(255) NOT NULL,
  `notify_message_body` text NOT NULL,
  `check_enquiry_fields` varchar(255) NOT NULL,
  `form_css` text NOT NULL,
  `form_js` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_recurring_tasks` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_by` int NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  `entities_id` int NOT NULL,
  `items_id` int NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `repeat_type` varchar(16) NOT NULL,
  `repeat_interval` int NOT NULL,
  `repeat_days` varchar(16) NOT NULL,
  `repeat_start` bigint unsigned NOT NULL,
  `repeat_end` bigint unsigned NOT NULL,
  `repeat_limit` int NOT NULL,
  `repeat_time` tinyint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_recurring_tasks VALUES
('12','29','1610216126','59','8','1','daily','1','','1610082000','1611378000','0','6'),
('13','31','1610382609','60','1','1','daily','1','','1610082000','1610686800','0','0'),
('14','27','1610387918','60','2','1','daily','1','','1610082000','0','0','0'),
('15','29','1610394005','60','8','1','daily','1','','1610341200','1622865600','0','0'),
('16','29','1610395390','60','5','1','daily','1','','1610082000','1610600400','2','0'),
('22','45','1611025370','84','33','1','daily','1','','1610946000','1614229200','0','0'),
('26','45','1611068239','84','36','1','daily','1','','1611032400','0','0','0'),
('27','45','1611102568','84','41','1','daily','1','','1611032400','0','0','0'),
('28','1','1611102768','84','35','1','daily','1','','1611032400','0','0','0'),
('29','45','1611105262','84','42','1','weekly','1','1,2,3','1611032400','0','0','0');

CREATE TABLE IF NOT EXISTS `app_ext_recurring_tasks_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `tasks_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tasks_id` (`tasks_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_signed_items` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `items_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `users_id` int NOT NULL,
  `date_added` bigint NOT NULL,
  `name` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `position` varchar(64) NOT NULL,
  `inn` varchar(64) NOT NULL,
  `ogrn` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `items_id` (`items_id`),
  KEY `users_id` (`users_id`),
  KEY `fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_signed_items_signatures` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `signed_items_id` int NOT NULL,
  `signed_text` text NOT NULL,
  `singed_filename` varchar(255) NOT NULL,
  `signature` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `signed_items_id` (`signed_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_smart_input_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `modules_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `type` varchar(64) NOT NULL,
  `fields_id` int NOT NULL,
  `rules` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_modules_id` (`modules_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_smart_input_rules VALUES
('1','1','1','SINGLE_ADDRESS_US','0','address1: [368]\r\naddress2: [369]\r\nlocality: [370]\r\nadministrative_area: [371]\r\npostal_code: [374]');

CREATE TABLE IF NOT EXISTS `app_ext_sms_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `modules_id` int NOT NULL,
  `action_type` varchar(64) NOT NULL,
  `fields_id` int NOT NULL,
  `monitor_fields_id` int NOT NULL,
  `monitor_choices` text NOT NULL,
  `phone` varchar(255) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_modules_id` (`modules_id`),
  KEY `idx_monitor_fields_id` (`monitor_fields_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_sms_rules VALUES
('1','46','2','edit_send_to_number','0','510','86','+14409039463','You\'ve completed a milestone! '),
('2','46','2','insert_send_to_number','0','510','86','+14409039463','You\'ve completed a milestone!'),
('3','52','2','insert_send_to_user_number','529','551','','','[550]');

CREATE TABLE IF NOT EXISTS `app_ext_subscribe_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `modules_id` int NOT NULL,
  `contact_list_id` varchar(255) NOT NULL,
  `contact_email_field_id` int NOT NULL,
  `contact_fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_modules_id` (`modules_id`),
  KEY `idx_fields_id` (`contact_email_field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_timeline_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `in_menu` tinyint unsigned NOT NULL DEFAULT '0',
  `name` varchar(64) NOT NULL,
  `start_date` int NOT NULL,
  `end_date` int NOT NULL,
  `heading_template` varchar(64) NOT NULL,
  `allowed_groups` text NOT NULL,
  `use_background` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_timeline_reports VALUES
('4','46','1','Milestone Timeline','465','466','','6','0');

CREATE TABLE IF NOT EXISTS `app_ext_timer` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `items_id` int NOT NULL,
  `seconds` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_timer_configuration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `users_groups` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_timer_configuration VALUES
('1','49',''),
('2','35','');

CREATE TABLE IF NOT EXISTS `app_ext_track_changes` (
  `id` int NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL,
  `name` varchar(64) NOT NULL,
  `position` varchar(255) NOT NULL,
  `menu_icon` varchar(64) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `color_insert` varchar(7) NOT NULL,
  `color_update` varchar(7) NOT NULL,
  `color_comment` varchar(7) NOT NULL,
  `color_delete` varchar(7) NOT NULL,
  `rows_per_page` smallint NOT NULL,
  `keep_history` smallint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_track_changes VALUES
('3','1','Activity Log','in_reports_menu,in_header_menu','fa-file-text-o','0,12,5,4','','#5cb85c','#f0ad4e','#5bc0de','#ababab','20','30');

CREATE TABLE IF NOT EXISTS `app_ext_track_changes_entities` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reports_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `track_fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_track_changes_entities VALUES
('2','3','83','');

CREATE TABLE IF NOT EXISTS `app_ext_track_changes_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reports_id` int NOT NULL,
  `type` varchar(16) NOT NULL,
  `entities_id` int NOT NULL,
  `items_id` int NOT NULL,
  `comments_id` int NOT NULL,
  `items_name` varchar(255) NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  `created_by` int NOT NULL,
  `is_cron` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_comments_id` (`comments_id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=272 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_ext_track_changes_log VALUES
('267','3','insert','83','68','0','','1611102101','1','0');

CREATE TABLE IF NOT EXISTS `app_ext_track_changes_log_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `log_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_log_id` (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_xml_export_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `button_title` varchar(64) NOT NULL,
  `button_position` varchar(64) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `is_public` tinyint(1) NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `template_header` text NOT NULL,
  `template_body` text NOT NULL,
  `template_footer` text NOT NULL,
  `template_filename` varchar(255) NOT NULL,
  `transliterate_filename` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_ext_xml_import_templates` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `button_title` varchar(64) NOT NULL,
  `button_position` varchar(64) NOT NULL,
  `button_color` varchar(7) NOT NULL,
  `button_icon` varchar(64) NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `data_path` varchar(255) NOT NULL,
  `import_fields` text NOT NULL,
  `import_fields_path` text NOT NULL,
  `import_action` varchar(16) NOT NULL,
  `update_by_field` int NOT NULL,
  `update_by_field_path` varchar(255) NOT NULL,
  `filepath` varchar(255) NOT NULL,
  `parent_item_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `forms_tabs_id` int NOT NULL,
  `comments_forms_tabs_id` int NOT NULL DEFAULT '0',
  `forms_rows_position` varchar(255) NOT NULL,
  `type` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `short_name` varchar(64) NOT NULL,
  `is_heading` tinyint(1) DEFAULT '0',
  `tooltip` text NOT NULL,
  `tooltip_display_as` varchar(16) NOT NULL,
  `tooltip_in_item_page` tinyint(1) NOT NULL DEFAULT '0',
  `tooltip_item_page` text NOT NULL,
  `notes` text NOT NULL,
  `is_required` tinyint(1) DEFAULT '0',
  `required_message` text NOT NULL,
  `configuration` text NOT NULL,
  `sort_order` int DEFAULT '0',
  `listing_status` tinyint NOT NULL DEFAULT '0',
  `listing_sort_order` int NOT NULL DEFAULT '0',
  `comments_status` tinyint(1) NOT NULL DEFAULT '0',
  `comments_sort_order` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_form_tabs_id` (`forms_tabs_id`),
  KEY `idx_comments_forms_tabs_id` (`comments_forms_tabs_id`),
  KEY `idx_type` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=1074 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_fields VALUES
('1','1','1','0','','fieldtype_action','','',NULL,'','','0','','',NULL,'','',NULL,'1','8','0','0'),
('2','1','1','0','','fieldtype_id','','',NULL,'','','0','','',NULL,'','',NULL,'0','0','0','0'),
('3','1','1','0','','fieldtype_date_added','','',NULL,'','','0','','',NULL,'','',NULL,'0','0','0','0'),
('4','1','1','0','','fieldtype_created_by','','',NULL,'','','0','','',NULL,'','',NULL,'0','0','0','0'),
('5','1','1','0','','fieldtype_user_status','','',NULL,'','','0','','',NULL,'','','0','1','4','0','0'),
('6','1','1','0','','fieldtype_user_accessgroups','','',NULL,'','','0','','',NULL,'','','4','1','5','0','0'),
('7','1','1','0','','fieldtype_user_firstname','','',NULL,'','','0','','',NULL,'','{\"allow_search\":\"1\"}','2','1','1','0','0'),
('8','1','1','0','','fieldtype_user_lastname','','',NULL,'','','0','','',NULL,'','{\"allow_search\":\"1\"}','3','1','2','0','0'),
('9','1','1','0','','fieldtype_user_email','','',NULL,'','','0','','',NULL,'','{\"allow_search\":\"1\"}','5','1','3','0','0'),
('10','1','1','0','','fieldtype_user_photo','','',NULL,'','','0','','',NULL,'','','8','0','0','0','0'),
('12','1','1','0','','fieldtype_user_username','','','1','','','0','','',NULL,'','{\"allow_search\":\"1\"}','1','1','0','0','0'),
('13','1','1','0','','fieldtype_user_language','','','0','','','0','','','0','','','7','0','0','0','0'),
('14','1','1','0','','fieldtype_user_skin','Theme Color','Theme','0','','','0','','','0','','','9','0','0','0','0'),
('196','1','1','0','','fieldtype_parent_item_id','','',NULL,'','','0','','',NULL,'','',NULL,'1','100','0','0'),
('201','1','1','0','','fieldtype_user_last_login_date','','','0','','','0','','','0','','','10','0','0','0','0'),
('202','1','1','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','0','0','0','0'),
('304','35','40','0','','fieldtype_action','','','0','','','0','','','0','','','0','1','1','0','0'),
('305','35','40','0','','fieldtype_id','','','0','','','0','','','0','','','1','0','0','0','0'),
('306','35','40','0','','fieldtype_date_added','','','0','','','0','','','0','','','2','0','0','0','0'),
('307','35','40','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','0','0','0','0'),
('308','35','40','0','','fieldtype_created_by','','','0','','','0','','','0','','','4','0','0','0','0'),
('309','35','40','0','','fieldtype_parent_item_id','','','0','','','0','','','0','','','5','1','2','0','0'),
('320','35','40','0','','fieldtype_input','Name','','1','What is the name of the resource?','','1','','','1','','{\"width\":\"input-large\",\"unique_error_msg\":\"\"}','0','1','0','0','0'),
('338','35','40','0','','fieldtype_textarea','Description','','0','','','0','','','0','','{\"width\":\"input-medium\",\"allow_search\":\"1\",\"hide_field_if_empty\":\"1\"}','1','0','0','0','0'),
('544','52','60','0','','fieldtype_action','','','0','','','0','','','0','','','0','0','0','0','0'),
('545','52','60','0','','fieldtype_id','','','0','','','0','','','0','','','1','1','0','0','0'),
('546','52','60','0','','fieldtype_date_added','','','0','','','0','','','0','','','2','1','4','0','0'),
('547','52','60','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','1','5','0','0'),
('548','52','60','0','','fieldtype_created_by','From User','','0','','','0','','','0','','','4','1','1','0','0'),
('549','52','60','0','','fieldtype_parent_item_id','','','0','','','0','','','0','','','5','1','5','0','0'),
('550','52','60','0','','fieldtype_textarea','Message','Message','1','','','0','','','1','','{\"width\":\"input-xlarge\"}','6','1','3','0','0'),
('551','52','60','0','','fieldtype_users','To User','','0','','','0','','','1','','{\"display_as\":\"dropdown_muliple\",\"disable_notification\":\"1\",\"use_groups\":[\"13\",\"6\",\"12\",\"5\",\"4\"]}','7','1','2','0','0'),
('586','57','65','0','','fieldtype_action','','','0','','','0','','','0','','','0','0','0','0','0'),
('587','57','65','0','','fieldtype_id','','','0','','','0','','','0','','','1','1','0','0','0'),
('588','57','65','0','','fieldtype_date_added','','','0','','','0','','','0','','','2','1','5','0','0'),
('589','57','65','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','1','6','0','0'),
('590','57','65','0','','fieldtype_created_by','From User','','0','','','0','','','0','','','4','1','1','0','0'),
('591','57','65','0','','fieldtype_parent_item_id','','','0','','','0','','','0','','','5','1','5','0','0'),
('592','57','65','0','','fieldtype_textarea','Message','','0','','','0','','','1','','{\"width\":\"input-xlarge\"}','2','1','4','0','0'),
('593','57','65','0','','fieldtype_users','To User','','0','','','0','','','1','','{\"display_as\":\"dropdown_muliple\",\"disable_notification\":\"1\",\"use_groups\":[\"13\",\"6\",\"12\",\"5\",\"4\"]}','0','1','2','0','0'),
('594','57','65','0','','fieldtype_input','Subject','','0','','','0','','','1','','{\"width\":\"input-medium\",\"unique_error_msg\":\"\"}','1','1','3','0','0'),
('988','83','93','0','','fieldtype_action','','','0','','','0','','','0','','','0','1','0','0','0'),
('989','83','93','0','','fieldtype_id','','','0','','','0','','','0','','','1','1','2','0','0'),
('990','83','93','0','','fieldtype_date_added','','','0','','','0','','','0','','','2','1','3','0','0'),
('991','83','93','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','1','5','0','0'),
('992','83','93','0','','fieldtype_created_by','','','0','','','0','','','0','','','4','1','7','0','0'),
('993','83','93','0','','fieldtype_parent_item_id','','','0','','','0','','','0','','','5','1','5','0','0'),
('995','83','93','0','2:1','fieldtype_input_date','Start Date','Start','0','','','0','','','0','','{\"date_format\":\"\",\"default_value\":\"\",\"min_date\":\"\",\"max_date\":\"\",\"unique_error_msg\":\"\",\"background\":\"\",\"day_before_date\":\"\",\"day_before_date_color\":\"\",\"day_before_date2\":\"\",\"day_before_date2_color\":\"\",\"disable_color_by_field\":\"\"}','0','0','0','0','0'),
('996','83','93','0','2:2','fieldtype_input_date','End Date','End','0','','','0','','','0','','{\"date_format\":\"\",\"default_value\":\"\",\"min_date\":\"\",\"max_date\":\"\",\"unique_error_msg\":\"\",\"background\":\"#ff0000\",\"day_before_date\":\"\",\"day_before_date_color\":\"\",\"day_before_date2\":\"\",\"day_before_date2_color\":\"\",\"disable_color_by_field\":\"\"}','0','0','0','0','0'),
('997','83','93','0','4:2','fieldtype_textarea','Recurring Goal Suggestions','','0','','','0','','','0','','{\"width\":\"input-large\",\"hide_field_if_empty\":\"1\"}','0','0','0','1','0'),
('998','83','94','0','','fieldtype_textarea','Vision','','0','What does it look like when you reach this goal?','','1','','','0','','{\"width\":\"input-large\"}','0','0','0','0','0'),
('999','83','94','0','','fieldtype_textarea','Purpose','','0','Why do you want to achieve this goal?','','1','','','0','','{\"width\":\"input-large\"}','1','0','0','0','0'),
('1000','83','94','0','','fieldtype_textarea','Obstacles','','0','What is currently stopping you from reaching this goal?','','1','','','0','','{\"width\":\"input-large\"}','2','0','0','0','0'),
('1001','83','94','0','','fieldtype_textarea','Resources','','0','What help do you need to achieve this goal?','','1','','','0','','{\"width\":\"input-large\"}','3','0','0','0','0'),
('1002','83','93','0','','fieldtype_input','Milestone Name','','1','','','0','','','1','','{\"allow_search\":\"1\",\"width\":\"input-large\",\"unique_error_msg\":\"\"}','4','1','1','0','0'),
('1003','83','93','0','4:1','fieldtype_todo_list','Non-recurring Goals','','0','','','0','','','0','','{\"width\":\"input-large\",\"use_comments\":\"\",\"text_check\":\"\",\"text_unckeck\":\"\"}','0','0','0','0','0'),
('1004','83','93','0','','fieldtype_boolean_checkbox','Private','','0','','','0','','','0','','{\"default_value\":\"false\",\"text_boolean_true\":\"\",\"text_boolean_false\":\"\"}','6','1','6','0','0'),
('1005','83','93','0','','fieldtype_image','Inspirational Image','','0','','','0','','','0','','{\"width\":\"150\",\"width_in_listing\":\"50\",\"allowed_extensions\":\"gif,jpg,png\"}','5','1','4','0','0'),
('1006','83','93','0','1:1','fieldtype_input','Measure at Start','','0','','','0','','','0','','{\"width\":\"input-medium\",\"unique_error_msg\":\"\"}','1','0','0','0','0'),
('1007','83','93','0','1:2','fieldtype_input','Measure at End','','0','','','0','','','0','','{\"width\":\"input-medium\",\"unique_error_msg\":\"\"}','1','0','0','0','0'),
('1008','83','93','0','','fieldtype_dropdown','Status','','0','','','0','','','1','','{\"notify_when_changed\":\"1\",\"default_text\":\"\",\"width\":\"input-small\",\"use_search\":\"0\",\"use_global_list\":\"\"}','7','0','0','0','0'),
('1013','83','93','0','3:1','fieldtype_users_ajax','Client','','0','','','0','','','0','','{\"display_as\":\"dropdown\",\"default_text\":\"\",\"disable_notification\":\"1\",\"authorized_user_by_default\":\"1\",\"heading_template\":\"[current_user_id]\",\"mysql_query_where\":\"[current_user_name]\",\"heading_template_display\":\"\"}','0','0','0','0','0'),
('1017','83','93','0','7:1','fieldtype_section','Goals','','0','','','0','','','0','','{\"description\":\"\"}','0','0','0','0','0'),
('1018','83','93','0','','fieldtype_section','Milestone Information','','0','','','0','','','0','','{\"description\":\"\"}','3','0','0','0','0'),
('1019','83','93','0','6:1','fieldtype_section','Metrics','','0','','','0','','','0','','{\"description\":\"\"}','0','0','0','0','0'),
('1022','83','93','0','3:2','fieldtype_users','Case Manager','','0','','','0','','','0','','{\"display_as\":\"dropdown\",\"hide_field_name\":\"1\",\"disable_notification\":\"1\",\"hide_admin\":\"1\",\"hide_access_group\":\"1\",\"use_groups\":[\"12\",\"5\",\"4\"]}','0','0','0','0','0'),
('1029','83','93','0','','fieldtype_dropdown_multilevel','Template/Category Select','','0','','','0','','','0','','{\"use_global_list\":\"13\",\"width\":\"input-large\",\"use_search\":\"0\",\"value_displya_own_column\":\"1\",\"level_settings\":\"Category (Required)\\r\\nSubcategory (Required)\\r\\nTemplate (Optional)\"}','1','0','0','0','0'),
('1030','83','93','0','','fieldtype_section','Category','','0','','','0','','','0','','{\"description\":\"\"}','0','0','0','0','0'),
('1031','83','93','0','','fieldtype_formula','Total Number of Goals','','0','','','0','','','0','','{\"formula\":\"IF(LENGTH([1003])<1, 0, 1+LENGTH([1003]) - LENGTH(REPLACE([1003], \\\"\\\\n\\\", \\\"\\\")))\",\"number_format\":\"\",\"prefix\":\"\",\"suffix\":\"\"}','8','0','0','0','0'),
('1032','83','93','0','','fieldtype_formula','Number of Completed Goals','','0','','','0','','','0','','{\"formula\":\"LENGTH([1003]) - LENGTH(REPLACE([1003], \\\"*\\\", \\\"\\\"))\\r\\n\",\"number_format\":\"\",\"prefix\":\"\",\"suffix\":\"\"}','9','0','0','0','0'),
('1033','83','93','0','','fieldtype_formula','Goal Progress','','0','','','0','','','0','','{\"formula\":\"CONCAT(FLOOR([1032]\\/[1031] * 100), \\\"% (\\\", [1032], \\\" out of \\\", [1031], \\\" goals complete)\\\")\",\"number_format\":\"\",\"prefix\":\"\",\"suffix\":\"\"}','10','0','0','0','0'),
('1035','84','95','0','','fieldtype_action','','','0','','','0','','','0','','','0','1','1','0','0'),
('1036','84','95','0','','fieldtype_id','','','0','','','0','','','0','','','1','0','0','0','0'),
('1037','84','95','0','','fieldtype_date_added','','','0','','','0','','','0','','','2','0','0','0','0'),
('1038','84','95','0','','fieldtype_date_updated','','','0','','','0','','','0','','','3','0','0','0','0'),
('1039','84','95','0','','fieldtype_created_by','','','0','','','0','','','0','','','4','0','0','0','0'),
('1040','84','95','0','','fieldtype_parent_item_id','','','0','','','0','','','0','','','5','1','5','0','0'),
('1041','83','93','0','','fieldtype_related_records','Recurring Goals','','0','','','0','','','0','','{\"entity_id\":\"84\",\"display_in_main_column\":\"1\",\"display_in_listing\":\"list\",\"fields_in_listing\":\"\",\"fields_in_popup\":\"\",\"create_related_comment\":\"\",\"create_related_comment_text\":\"\",\"delete_related_comment\":\"\",\"delete_related_comment_text\":\"\",\"create_related_comment_to\":\"\",\"create_related_comment_to_text\":\"\",\"delete_related_comment_to\":\"\",\"delete_related_comment_to_text\":\"\",\"heading_template\":\"\"}','11','0','0','0','0'),
('1043','84','95','0','','fieldtype_boolean_checkbox','Completed?','','0','','','0','','','0','','{\"default_value\":\"false\",\"text_boolean_true\":\"\",\"text_boolean_false\":\"\"}','6','1','2','0','0'),
('1044','84','95','0','','fieldtype_related_records','Related Milestone','','0','','','0','','','0','','{\"entity_id\":\"83\",\"hide_controls\":[\"with_selected\"],\"display_in_listing\":\"count\",\"fields_in_listing\":\"\",\"fields_in_popup\":\"\",\"create_related_comment\":\"\",\"create_related_comment_text\":\"\",\"delete_related_comment\":\"\",\"delete_related_comment_text\":\"\",\"create_related_comment_to\":\"\",\"create_related_comment_to_text\":\"\",\"delete_related_comment_to\":\"\",\"delete_related_comment_to_text\":\"\",\"heading_template\":\"\"}','4','0','0','0','0'),
('1045','84','95','0','','fieldtype_users_ajax','Client','','0','','','0','','','0','','{\"display_as\":\"dropdown\",\"default_text\":\"\",\"hide_field_name\":\"1\",\"disable_notification\":\"1\",\"authorized_user_by_default\":\"1\",\"heading_template\":\"[current_user_id]\",\"mysql_query_where\":\"get_value([current_user_id])\",\"heading_template_display\":\"\"}','5','0','0','0','0'),
('1047','84','95','0','','fieldtype_users','Case Manager','','0','','','0','','','0','','{\"display_as\":\"dropdown\",\"hide_field_name\":\"1\",\"hide_admin\":\"1\",\"hide_access_group\":\"1\",\"use_groups\":[\"12\",\"5\",\"4\"]}','3','0','0','0','0'),
('1048','84','95','0','','fieldtype_process_button','Mark as Complete','','0','','','0','','','0','','{\"process_button\":[\"12\"],\"display_as\":\"inline\"}','7','1','3','0','0'),
('1049','83','93','0','','fieldtype_process_button','Mark as complete','','0','','','0','','','0','','{\"process_button\":[\"11\"],\"display_as\":\"inline\"}','12','0','0','0','0'),
('1052','83','93','0','1:1','fieldtype_dropdown_multilevel','Measure at Start','','0','','','0','','','0','','{\"use_global_list\":\"13\",\"width\":\"input-medium\",\"use_search\":\"0\",\"value_displya_own_column\":\"0\",\"level_settings\":\"Category\\r\\nSubcategory\\r\\nTemplates\\r\\nMeasure at Start\"}','0','0','0','0','0'),
('1053','83','93','0','1:2','fieldtype_dropdown_multilevel','Measure at End','','0','','','0','','','0','','{\"use_global_list\":\"13\",\"width\":\"input-medium\",\"use_search\":\"0\",\"value_displya_own_column\":\"0\",\"level_settings\":\"Category\\r\\nSubcategory\\r\\nTemplates\\r\\nMeasure at End\"}','0','0','0','0','0'),
('1054','83','93','0','','fieldtype_progress','Milestone Progress Bar','','0','','','0','','','0','','{\"step\":\"1\",\"display_progress_bar\":\"1\",\"bar_min_width\":\"\",\"bar_color\":\"#bf7113\"}','2','0','0','0','0'),
('1056','83','93','0','','fieldtype_input','Template Measures Type','','0','','','0','','','0','','{\"width\":\"input-small\",\"unique_error_msg\":\"\"}','13','0','0','0','0'),
('1061','84','95','0','','fieldtype_dropdown','Suggested Recurring Goals','','0','','','0','','','0','','{\"default_text\":\"\",\"width\":\"input-xlarge\",\"use_search\":\"1\",\"use_global_list\":\"16\"}','2','0','0','0','0'),
('1062','84','95','0','','fieldtype_input','Recurring Goal','','1','','','0','','','0','','{\"width\":\"input-medium\",\"unique_error_msg\":\"\"}','8','1','0','0','0'),
('1063','84','95','0','','fieldtype_input','Custom Recurring Goal','','0','','','0','','','0','','{\"width\":\"input-xlarge\",\"unique_error_msg\":\"\"}','1','0','0','0','0'),
('1064','84','95','0','','fieldtype_dropdown','Create Custom Recurring Goal?','','0','','','0','','','0','','{\"default_text\":\"\",\"width\":\"input-medium\",\"use_search\":\"0\",\"use_global_list\":\"\"}','0','0','0','0','0'),
('1065','83','93','0','','fieldtype_input','Category','','0','','','0','','','0','','{\"width\":\"input-small\",\"unique_error_msg\":\"\"}','14','0','0','0','0'),
('1066','83','93','0','','fieldtype_input','Subcategory','','0','','','0','','','0','','{\"width\":\"input-small\",\"unique_error_msg\":\"\"}','15','0','0','0','0'),
('1067','84','95','0','','fieldtype_input','Type','','0','','','0','','','0','','{\"width\":\"input-small\",\"unique_error_msg\":\"\"}','9','0','0','0','0'),
('1068','35','40','0','','fieldtype_dropdown','Category','','0','','','0','','','0','','{\"default_text\":\"\",\"width\":\"input-small\",\"use_search\":\"1\",\"use_global_list\":\"17\"}','5','0','0','0','0'),
('1070','35','40','0','','fieldtype_input_url','URL','','0','URL to the resource','','1','','','0','','{\"preview_text\":\"Click here to view link\",\"prefix\":\"\",\"hide_field_if_empty\":\"1\",\"unique_error_msg\":\"\"}','2','0','0','0','0'),
('1071','35','40','0','','fieldtype_attachments','Attachment','','0','Attach a file','icon','0','Attached file to download','','0','','{\"use_image_preview\":\"1\",\"upload_limit\":\"\",\"upload_size_limit\":\"\",\"allowed_extensions\":\"\",\"confirm_delation\":\"1\"}','3','0','0','0','0'),
('1072','35','40','0','','fieldtype_iframe','iFrame','','0','','','0','','','0','','{\"input_width\":\"input-xlarge\",\"hide_field_if_empty\":\"1\",\"width\":\"100%\",\"height\":\"500px\",\"scrolling\":\"auto\",\"extra_params\":\"\"}','4','0','0','0','0'),
('1073','35','40','0','','fieldtype_input_file','PDF','','0','','','0','','','0','','{\"allowed_extensions\":\"\"}','6','0','0','0','0');

CREATE TABLE IF NOT EXISTS `app_fields_access` (
  `id` int NOT NULL AUTO_INCREMENT,
  `access_groups_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `access_schema` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_access_groups_id` (`access_groups_id`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_fields_access VALUES
('24','13','1','212','hide'),
('25','6','1','212','hide'),
('26','12','1','212','hide'),
('27','13','1','211','hide'),
('28','6','1','211','hide'),
('29','13','1','213','hide'),
('30','12','1','213','hide'),
('31','5','1','213','hide'),
('32','4','1','213','hide'),
('33','13','1','375','hide'),
('34','6','1','375','hide'),
('35','6','46','454','hide'),
('36','6','46','455','hide'),
('37','6','46','456','hide'),
('38','6','46','457','hide'),
('39','13','46','486','hide'),
('40','12','46','486','hide'),
('41','5','46','486','hide'),
('42','4','46','486','hide'),
('43','13','1','376','hide'),
('44','13','1','377','hide'),
('45','12','1','361','hide'),
('46','5','1','361','hide'),
('47','4','1','361','hide'),
('48','13','1','542','hide'),
('49','6','1','542','hide'),
('50','13','1','543','hide'),
('51','6','1','543','hide'),
('52','13','52','549','hide'),
('55','6','52','549','hide'),
('60','6','52','547','hide'),
('63','13','52','547','hide'),
('73','13','57','591','hide'),
('81','6','57','591','hide'),
('82','6','83','1054','view'),
('83','12','83','1054','view'),
('84','5','83','1054','view'),
('85','4','83','1054','view'),
('86','6','35','305','hide'),
('87','6','35','306','hide'),
('88','6','35','307','hide'),
('89','6','35','308','hide'),
('90','6','35','309','hide'),
('91','6','35','1068','hide');

CREATE TABLE IF NOT EXISTS `app_fields_choices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int NOT NULL DEFAULT '0',
  `fields_id` int NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `bg_color` varchar(16) NOT NULL,
  `sort_order` int DEFAULT NULL,
  `users` text NOT NULL,
  `value` varchar(64) NOT NULL,
  `filename` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_fields_choices VALUES
('103','0','1008','1','Complete','0','','1','','',''),
('104','0','1008','1','In progress','1','','0','','',''),
('105','0','1064','1','Create custom recurring goal','0','','0','','',''),
('106','0','1064','1','Search suggested recurring goals','0','','0','','','');

CREATE TABLE IF NOT EXISTS `app_filters_panels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `type` varchar(64) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_active_filters` tinyint(1) NOT NULL,
  `position` varchar(16) NOT NULL,
  `users_groups` text NOT NULL,
  `width` tinyint(1) NOT NULL,
  `sort_order` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_filters_panels VALUES
('3','46','item_pivot_tables_2_603','1','1','horizontal','','0','0'),
('5','83','pivot_tables1','1','1','horizontal','','0','0'),
('6','83','pivot_tables4','1','1','horizontal','','0','0'),
('7','1','pivot_tables5','1','1','horizontal','','0','0'),
('8','1','pivot_tables6','1','1','horizontal','','0','0'),
('9','83','calendar_report_2','1','1','horizontal','','0','0'),
('10','83','calendar_report_3','1','1','horizontal','','0','0'),
('11','35','','1','1','horizontal','6','1','0');

CREATE TABLE IF NOT EXISTS `app_filters_panels_fields` (
  `id` int NOT NULL AUTO_INCREMENT,
  `panels_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `title` varchar(64) NOT NULL,
  `width` varchar(16) NOT NULL,
  `height` varchar(16) NOT NULL,
  `display_type` varchar(32) NOT NULL,
  `search_type_match` tinyint(1) NOT NULL,
  `exclude_values` text NOT NULL,
  `sort_order` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_panels_id` (`panels_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_filters_panels_fields VALUES
('3','5','83','1013','','input-medium','','dropdown','0','','1'),
('4','5','83','1029','','input-medium','','dropdown','0','','2'),
('5','7','1','379','','input-small','','dropdown','0','','1');

CREATE TABLE IF NOT EXISTS `app_forms_fields_rules` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int unsigned NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `choices` text NOT NULL,
  `visible_fields` text NOT NULL,
  `hidden_fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_forms_fields_rules VALUES
('1','1','6','0,12,5,4','375,376,377','361,368,369,370,371,374,372,379,380,381,382'),
('2','1','6','13,6','361,368,369,370,371,374,372,379,380,381,382','375,376,377'),
('3','38','404','0','340','403'),
('4','38','404','1','403','340'),
('5','46','482','305','520,523','499,500'),
('6','46','482','275,282,283,281,284,280,277,279','499,500','523,520,525,524'),
('7','46','482','276','525,524','499,500,523,520');

CREATE TABLE IF NOT EXISTS `app_forms_rows` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `forms_tabs_id` int NOT NULL,
  `columns` tinyint NOT NULL,
  `column1_width` tinyint NOT NULL,
  `column2_width` tinyint NOT NULL,
  `column3_width` tinyint NOT NULL,
  `column4_width` tinyint NOT NULL,
  `field_name_new_row` tinyint(1) NOT NULL,
  `sort_order` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `entities_id` (`entities_id`),
  KEY `forms_tabs_id` (`forms_tabs_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_forms_rows VALUES
('1','83','93','2','6','6','3','3','1','9'),
('2','83','93','2','6','6','3','3','1','3'),
('3','83','93','2','6','6','3','3','1','4'),
('4','83','93','2','6','6','3','3','1','7'),
('6','83','93','1','12','6','3','3','1','8'),
('7','83','93','1','12','6','3','3','1','6');

CREATE TABLE IF NOT EXISTS `app_forms_tabs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `description` text NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_forms_tabs VALUES
('1','1','Info','','0'),
('40','35','Info','','0'),
('60','52','Info','','0'),
('65','57','Info','','0'),
('93','83','Info','','0'),
('94','83','Milestone Reflection','','1'),
('95','84','Info','','0');

CREATE TABLE IF NOT EXISTS `app_global_lists` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_global_lists VALUES
('1','State',''),
('2','Gender',''),
('3','Height (ft)',''),
('4','Height (in.)',''),
('5','Units of Measure',''),
('6','Categories',''),
('7','Education Level',''),
('8','Housing Situation',''),
('9','Health - js',''),
('10','Education - js',''),
('11','Mental Health Templates - js',''),
('12','College Templates',''),
('13','Category',''),
('14','Main Templates - js',''),
('15','Measures',''),
('16','Recurring Goals',''),
('17','Provider\'s Corner Categories','Category for the different groups for the Provider\'s Corner Resources (for more info, talk with Kevin)');

CREATE TABLE IF NOT EXISTS `app_global_lists_choices` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int NOT NULL DEFAULT '0',
  `lists_id` int NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `name` varchar(255) NOT NULL,
  `is_default` tinyint(1) DEFAULT NULL,
  `bg_color` varchar(16) NOT NULL,
  `sort_order` int DEFAULT NULL,
  `users` text NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_lists_id` (`lists_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=588 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_global_lists_choices VALUES
('103','0','1','1','Alabama','0','','0','',''),
('104','0','1','1','Alaska','0','','0','',''),
('105','0','1','1','Arizona','0','','0','',''),
('106','0','1','1','Arkansas','0','','0','',''),
('107','0','1','1','California','0','','0','',''),
('108','0','1','1','Colorado','0','','0','',''),
('109','0','1','1','Connecticut','0','','0','',''),
('110','0','1','1','Delaware','0','','0','',''),
('111','0','1','1','District of Columbia','0','','0','',''),
('112','0','1','1','Florida','0','','0','',''),
('113','0','1','1','Georgia','0','','0','',''),
('114','0','1','1','Hawaii','0','','0','',''),
('115','0','1','1','Idaho','0','','0','',''),
('116','0','1','1','Illinois','0','','0','',''),
('117','0','1','1','Indiana','0','','0','',''),
('118','0','1','1','Iowa','0','','0','',''),
('119','0','1','1','Kansas','0','','0','',''),
('120','0','1','1','Kentucky','0','','0','',''),
('121','0','1','1','Louisiana','0','','0','',''),
('122','0','1','1','Maine','0','','0','',''),
('123','0','1','1','Montana','0','','0','',''),
('124','0','1','1','Nebraska','0','','0','',''),
('125','0','1','1','Nevada','0','','0','',''),
('126','0','1','1','New Hampshire','0','','0','',''),
('127','0','1','1','New Jersey','0','','0','',''),
('128','0','1','1','New Mexico','0','','0','',''),
('129','0','1','1','New York','0','','0','',''),
('130','0','1','1','North Carolina','0','','0','',''),
('131','0','1','1','North Dakota','0','','0','',''),
('132','0','1','1','Ohio','0','','0','',''),
('133','0','1','1','Oklahoma','0','','0','',''),
('134','0','1','1','Oregon','0','','0','',''),
('135','0','1','1','Maryland','0','','0','',''),
('136','0','1','1','Massachusetts','0','','0','',''),
('137','0','1','1','Michigan','0','','0','',''),
('138','0','1','1','Minnesota','0','','0','',''),
('139','0','1','1','Mississippi','0','','0','',''),
('140','0','1','1','Missouri','0','','0','',''),
('141','0','1','1','Pennsylvania','0','','0','',''),
('142','0','1','1','Rhode Island','0','','0','',''),
('143','0','1','1','South Carolina','0','','0','',''),
('144','0','1','1','South Dakota','0','','0','',''),
('145','0','1','1','Tennessee','0','','0','',''),
('146','0','1','1','Texas','0','','0','',''),
('147','0','1','1','Utah','0','','0','',''),
('148','0','1','1','Vermont','0','','0','',''),
('149','0','1','1','Virginia','0','','0','',''),
('150','0','1','1','Washington','0','','0','',''),
('151','0','1','1','West Virginia','0','','0','',''),
('152','0','1','1','Wisconsin','0','','0','',''),
('153','0','1','1','Wyoming','0','','0','',''),
('154','0','2','1','Female','0','','0','',''),
('155','0','2','1','Male','0','','0','',''),
('156','0','2','1','Decline to State','0','','0','',''),
('157','0','3','1','5’0”','0','','0','',''),
('158','0','3','1','5’1”','0','','1','',''),
('159','0','3','1','5’2”','0','','2','',''),
('160','0','3','1','5’3”','0','','3','',''),
('161','0','3','1','5’4”','0','','4','',''),
('162','0','3','1','5’5”','0','','5','',''),
('163','0','3','1','5’6”','0','','6','',''),
('164','0','3','1','5’7”','0','','7','',''),
('165','0','3','1','5’8”','0','','8','',''),
('166','0','3','1','5’9”','0','','9','',''),
('167','0','3','1','5’10”','0','','10','',''),
('168','0','3','1','5’11”','0','','11','',''),
('169','0','3','1','6’0”','0','','12','',''),
('170','0','3','1','6’1”','0','','13','',''),
('171','0','3','1','6’2”','0','','14','',''),
('172','0','3','1','6’3”','0','','15','',''),
('173','0','3','1','6’4”','0','','16','',''),
('174','0','3','1','6’5”','0','','17','',''),
('175','0','3','1','6’6”','0','','18','',''),
('176','0','3','1','6’7”','0','','19','',''),
('177','0','3','1','6’8”','0','','20','',''),
('178','0','3','1','6’9”','0','','21','',''),
('179','0','3','1','6’10”','0','','22','',''),
('180','0','3','1','6’11”','0','','23','',''),
('181','0','3','1','7’0”','0','','24','',''),
('182','0','3','1','7’1”','0','','25','',''),
('183','0','3','1','7’2”','0','','26','',''),
('184','0','4','1','10','0','','0','',''),
('185','0','4','1','11','0','','1','',''),
('186','0','4','1','12','0','','2','',''),
('187','0','4','1','13','0','','3','',''),
('188','0','4','1','14','0','','4','',''),
('189','0','4','1','15','0','','5','',''),
('190','0','4','1','16','0','','6','',''),
('191','0','4','1','17','0','','7','',''),
('192','0','4','1','18','0','','8','',''),
('193','0','4','1','19','0','','9','',''),
('194','0','4','1','20','0','','10','',''),
('195','0','4','1','21','0','','11','',''),
('196','0','4','1','22','0','','12','',''),
('197','0','4','1','23','0','','13','',''),
('198','0','4','1','24','0','','14','',''),
('199','0','4','1','25','0','','15','',''),
('200','0','4','1','26','0','','16','',''),
('201','0','4','1','27','0','','17','',''),
('202','0','4','1','28','0','','18','',''),
('203','0','4','1','29','0','','19','',''),
('204','0','4','1','30','0','','20','',''),
('205','0','4','1','31','0','','21','',''),
('206','0','4','1','32','0','','22','',''),
('207','0','4','1','33','0','','23','',''),
('208','0','4','1','34','0','','24','',''),
('209','0','4','1','35','0','','25','',''),
('210','0','4','1','36','0','','26','',''),
('211','0','4','1','37','0','','27','',''),
('212','0','4','1','38','0','','28','',''),
('213','0','4','1','39','0','','29','',''),
('214','0','4','1','40','0','','30','',''),
('215','0','4','1','41','0','','31','',''),
('216','0','4','1','42','0','','32','',''),
('217','0','4','1','43','0','','33','',''),
('218','0','4','1','44','0','','34','',''),
('219','0','4','1','45','0','','35','',''),
('220','0','4','1','46','0','','36','',''),
('221','0','4','1','47','0','','37','',''),
('222','0','4','1','48','0','','38','',''),
('223','0','4','1','49','0','','39','',''),
('224','0','4','1','50','0','','40','',''),
('225','0','4','1','51','0','','41','',''),
('226','0','4','1','52','0','','42','',''),
('227','0','4','1','53','0','','43','',''),
('228','0','4','1','54','0','','44','',''),
('229','0','4','1','55','0','','45','',''),
('230','0','4','1','56','0','','46','',''),
('231','0','4','1','57','0','','47','',''),
('232','0','4','1','58','0','','48','',''),
('233','0','4','1','59','0','','49','',''),
('234','0','4','1','60','0','','50','',''),
('235','0','4','1','61','0','','51','',''),
('236','0','4','1','62','0','','52','',''),
('237','0','4','1','63','0','','53','',''),
('238','0','4','1','64','0','','54','',''),
('239','0','4','1','65','0','','55','',''),
('240','0','4','1','66','0','','56','',''),
('241','0','4','1','67','0','','57','',''),
('242','0','4','1','68','0','','58','',''),
('243','0','4','1','69','0','','59','',''),
('244','0','4','1','70','0','','60','',''),
('245','0','4','1','71','0','','61','',''),
('246','0','4','1','72','0','','62','',''),
('247','0','4','1','73','0','','63','',''),
('248','0','4','1','74','0','','64','',''),
('249','0','4','1','75','0','','65','',''),
('250','0','4','1','76','0','','66','',''),
('251','0','4','1','77','0','','67','',''),
('252','0','4','1','78','0','','68','',''),
('253','0','4','1','79','0','','69','',''),
('254','0','4','1','80','0','','70','',''),
('255','0','4','1','81','0','','71','',''),
('256','0','4','1','82','0','','72','',''),
('257','0','4','1','83','0','','73','',''),
('258','0','4','1','84','0','','74','',''),
('259','0','4','1','85','0','','75','',''),
('260','0','4','1','86','0','','76','',''),
('261','0','4','1','87','0','','77','',''),
('262','0','4','1','88','0','','78','',''),
('263','0','4','1','89','0','','79','',''),
('264','0','4','1','90','0','','80','',''),
('265','0','4','1','91','0','','81','',''),
('266','0','4','1','92','0','','82','',''),
('267','0','4','1','93','0','','83','',''),
('268','0','4','1','94','0','','84','',''),
('269','0','4','1','95','0','','85','',''),
('270','0','4','1','96','0','','86','',''),
('271','0','5','1','Pounds (lbs.)','0','','0','',''),
('272','0','5','1','Money ($)','0','','0','',''),
('273','0','5','1','Completed (Yes/No)','0','','0','',''),
('274','0','5','1','Peace level','0','','0','',''),
('275','0','6','1','Health','0','','1','',''),
('276','0','6','1','Housing','0','','2','',''),
('277','0','6','1','Jobs','0','','3','',''),
('278','0','6','1','Education','0','','0','',''),
('279','0','6','1','Children','0','','4','',''),
('280','275','6','1','Main','0','','4','',''),
('283','275','6','1','Mental Health','0','','1','',''),
('285','0','5','1','Scale (1 to 10)','0','','0','',''),
('286','0','5','1','Education Level','0','','0','',''),
('287','0','5','1','Education Location','0','','0','',''),
('288','0','5','1','Education Schedule','0','','0','',''),
('289','0','5','1','Housing','0','','0','',''),
('296','0','7','1','No high school completed','0','','1','',''),
('297','0','7','1','Completed some high school, no diploma yet','0','','2','',''),
('298','0','7','1','High School Diploma or GED','0','','3','',''),
('299','0','7','1','Completed some college, no degree yet','0','','4','',''),
('300','0','7','1','Associate\'s Degree','0','','5','',''),
('301','0','7','1','Bachelor\'s Degree','0','','6','',''),
('302','0','7','1','Military with related training','0','','7','',''),
('303','0','7','1','Trade/technical/vocational training','0','','8','',''),
('304','0','7','1','Postgraduate Degree','0','','9','',''),
('306','0','8','1','Living on street','0','','1','',''),
('307','0','8','1','Living in vehicle','0','','2','',''),
('308','0','8','1','Living with friend or family','0','','3','',''),
('309','0','8','1','Living in shelter','0','','4','',''),
('310','0','8','1','Transitional Housing - government assisted','0','','5','',''),
('311','0','8','1','Transitional Housing - non-government assisted','0','','6','',''),
('312','0','8','1','Permanent Housing - government assisted','0','','7','',''),
('313','0','8','1','Apartment or rental house (rented)','0','','8','',''),
('314','0','8','1','House (mortgage)','0','','9','',''),
('315','0','8','1','Medical Access Housing','0','','10','',''),
('316','276','6','1','Emergency Shelter','0','','0','',''),
('317','276','6','1','Transitional Housing','0','','0','',''),
('318','276','6','1','Stay in Current Home','0','','0','',''),
('319','276','6','1','Permanent Housing','0','','0','',''),
('320','278','6','1','School','0','','0','',''),
('322','277','6','1','Location','0','','0','',''),
('323','277','6','1','Income & Benefits','0','','0','',''),
('324','277','6','1','Schedule','0','','0','',''),
('325','277','6','1','Enjoyment','0','','0','',''),
('326','279','6','1','Prenatal Specific','0','','0','',''),
('327','279','6','1','From Birth Onward','0','','0','',''),
('328','0','10','1','High School','0','','0','',''),
('329','0','10','1','College','0','','0','',''),
('330','0','9','1','Prenatal','0','','0','',''),
('331','0','9','1','Mental Health','0','','0','',''),
('332','0','11','1','Therapy','0','','0','',''),
('333','0','11','1','Meditate','0','','0','',''),
('334','0','12','1','Study','0','','0','',''),
('335','0','12','1','SAT','0','','0','',''),
('336','0','13','1','Education','0','','0','',''),
('337','0','13','1','Health','0','','0','',''),
('338','0','13','1','Housing','0','','0','',''),
('339','0','13','1','Jobs','0','','0','',''),
('340','0','13','1','Money Management','0','','0','',''),
('341','0','13','1','Other','0','','0','',''),
('342','0','12','1','Graduate','0','','0','',''),
('343','0','9','1','Main','0','','0','',''),
('349','337','13','1','Mental Health','0','','0','',''),
('351','0','13','1','Choose a category...','0','','-1','',''),
('360','339','13','1','Location','0','','0','',''),
('361','360','13','1','Close to home','0','','0','',''),
('362','0','15','1','SAT','0','','0','',''),
('363','0','15','1','Study','0','','0','',''),
('364','0','15','1','Graduate','0','','0','',''),
('365','364','15','1','Some high school','0','','0','',''),
('366','364','15','1','High school','0','','0','',''),
('367','364','15','1','College','0','','0','',''),
('368','362','15','1','1400','0','','0','',''),
('369','362','15','1','1500','0','','0','',''),
('370','362','15','1','1600','0','','0','',''),
('371','0','15','1',' ','0','','-1','',''),
('378','337','13','1','Main','0','','0','',''),
('379','378','13','1','HbA1c','0','','0','',''),
('380','0','6','1','Money Management','0','','0','',''),
('385','378','13','1','Custom Milestone ','0','','-1','',''),
('386','378','13','1','Preventative Care','0','','0','',''),
('387','378','13','1','Early Morning Fasting Blood Sugar Level','0','','0','',''),
('388','378','13','1','Blood Pressure','0','','0','',''),
('389','378','13','1','Weight','0','','0','',''),
('390','378','13','1','Height','0','','0','',''),
('391','378','13','1','BMI','0','','0','',''),
('392','349','13','1','Custom Milestone ','0','','-1','',''),
('393','349','13','1','Peace Level','0','','0','',''),
('395','360','13','1','Custom Milestone ','0','','-1','',''),
('396','360','13','1','Close to child/ren\'s school/s','0','','0','',''),
('398','360','13','1','Easy Commute','0','','0','',''),
('399','336','13','1','Education Level','0','','0','',''),
('400','399','13','1','Custom Milestone ','0','','-1','',''),
('401','399','13','1','High school diploma','0','','0','',''),
('403','401','13','1','Some high school completed','0','','1','',''),
('404','401','13','1','High school diploma','0','','2','',''),
('408','399','13','1','GED','0','','1','',''),
('410','408','13','1','Some high school completed','0','','1','',''),
('411','408','13','1','GED','0','','2','',''),
('412','399','13','1','Associate\'s degree','0','','2','',''),
('414','412','13','1','Some high school completed','0','','1','',''),
('415','412','13','1','High school diploma','0','','3','',''),
('416','412','13','1','GED','0','','2','',''),
('417','412','13','1','Associate\'s degree','0','','6','',''),
('419','399','13','1','Bachelor\'s degree','0','','3','',''),
('421','419','13','1','Some high school completed','0','','1','',''),
('422','419','13','1','High school diploma','0','','3','',''),
('423','419','13','1','Associate\'s degree','0','','5','',''),
('424','419','13','1','Bachelor\'s degree','0','','7','',''),
('425','419','13','1','GED','0','','2','',''),
('426','419','13','1','Military with related training','0','','6','',''),
('427','412','13','1','Military with related training','0','','5','',''),
('428','399','13','1','Military with related training','0','','4','',''),
('429','428','13','1','Some high school completed','0','','0','',''),
('430','428','13','1','GED','0','','1','',''),
('431','428','13','1','High school diploma','0','','2','',''),
('432','428','13','1','Associate\'s degree','0','','4','',''),
('433','428','13','1','Bachelor\'s degree','0','','5','',''),
('434','428','13','1','Military with related training','0','','7','',''),
('435','428','13','1','Trade/technical/vocational training','0','','3','',''),
('436','419','13','1','Trade/technical/vocational training','0','','4','',''),
('437','412','13','1','Trade/technical/vocational training','0','','4','',''),
('438','399','13','1','Trade/technical/vocational training','0','','5','',''),
('439','438','13','1','Some high school completed','0','','0','',''),
('440','438','13','1','GED','0','','1','',''),
('441','438','13','1','High school diploma','0','','2','',''),
('442','438','13','1','Associate\'s degree','0','','3','',''),
('443','438','13','1','Bachelor\'s degree','0','','4','',''),
('444','438','13','1','Military with related training','0','','5','',''),
('445','438','13','1','Trade/technical/vocational training','0','','7','',''),
('446','399','13','1','Postgraduate degree','0','','8','',''),
('447','446','13','1','Some high school completed','0','','0','',''),
('448','446','13','1','GED','0','','1','',''),
('449','446','13','1','High school diploma','0','','2','',''),
('450','446','13','1','Associate\'s degree','0','','4','',''),
('451','446','13','1','Bachelor\'s degree','0','','5','',''),
('452','446','13','1','Military with related training','0','','6','',''),
('453','446','13','1','Trade/technical/vocational training','0','','3','',''),
('454','446','13','1','Postgraduate degree','0','','8','',''),
('455','488','13','1','Close to home ','0','','10','',''),
('456','488','13','1','Close to child/ren\'s school/s ','0','','11','',''),
('457','488','13','1','Easy commute ','0','','12','',''),
('458','488','13','1','Virtual learning that is not self-paced ','0','','14','',''),
('459','489','13','1','Classes scheduled during time of day/night I want','0','','15','',''),
('460','489','13','1','Online courses I can do at my own pace','0','','16','',''),
('461','490','13','1','Workload somewhat manageable','0','','17','',''),
('462','490','13','1','Workload fully manageable','0','','18','',''),
('463','461','13','1','Workload not manageable','0','','0','',''),
('464','461','13','1','Workload somewhat manageable','0','','1','',''),
('465','462','13','1','Workload not manageable','0','','0','',''),
('466','462','13','1','Workload somewhat manageable','0','','1','',''),
('467','462','13','1','Workload fully manageable','0','','3','',''),
('468','490','13','1','Healthy school-rest-of-life balance','0','','20','',''),
('469','490','13','1','I like going to class','0','','21','',''),
('470','0','16','1','Plan 5 healthy recipes to cook this week','0','','0','',''),
('471','0','16','1','Walk/Exercise for 30 minutes','0','','0','',''),
('472','0','16','1','Make weekly shopping list for healthy meals','0','','0','',''),
('473','0','16','1','Drink less alcohol','0','','0','',''),
('474','0','16','1','Go grocery shopping','0','','0','',''),
('475','0','16','1','Sleep at least 6 hours total tonight','0','','0','',''),
('476','0','16','1','Look up new healthy recipe','0','','0','',''),
('477','0','16','1','Do monthly weigh-in','0','','0','',''),
('478','0','16','1','Take prescribed medication in AM','0','','0','',''),
('479','0','16','1','Take prescribed medication in PM','0','','0','',''),
('480','0','16','1','Drink 6 glasses of water','0','','0','',''),
('481','0','16','1','Eat 6 servings of fruits/vegetables','0','','0','',''),
('482','0','16','1','Write in my Gratitude Journal','0','','0','',''),
('483','0','16','1','Meditate/Do deep breathing','0','','0','',''),
('484','0','16','1','Check blood sugar levels according to doctor','0','','0','',''),
('485','0','16','1','Check feet daily','0','','0','',''),
('486','490','13','1','It challenges me to grow ','0','','22','',''),
('487','490','13','1','Class topics genuinely interest me','0','','25','',''),
('488','336','13','1','Location','0','','2','',''),
('489','336','13','1','Schedule','0','','3','',''),
('490','336','13','1','Enjoyment','0','','4','',''),
('491','488','13','1','Custom Milestone ','0','','-1','',''),
('492','489','13','1','Custom Milestone ','0','','-1','',''),
('493','490','13','1','Custom Milestone ','0','','-1','',''),
('494','339','13','1','Income & Benefits','0','','2','',''),
('495','494','13','1','Custom Milestone ','0','','-1','',''),
('496','494','13','1','Income is enough to support my family','0','','1','',''),
('497','494','13','1','Income is enough to live comfortably','0','','3','',''),
('498','494','13','1','Amount and type of benefits I want','0','','4','',''),
('499','339','13','1','Schedule','0','','4','',''),
('500','499','13','1','Custom Milestone','0','','-1','',''),
('501','499','13','1','Reliable work schedule similar each week','0','','1','',''),
('502','499','13','1','Work hours during time of day/night I want','0','','2','',''),
('503','499','13','1','Number of work hours I want','0','','4','',''),
('504','339','13','1','Enjoyment','0','','5','',''),
('505','504','13','1','Custom Milestone ','0','','-1','',''),
('506','504','13','1','I make a positive difference','0','','1','',''),
('507','504','13','1','I enjoy my coworkers','0','','2','',''),
('508','504','13','1','I feel appreciated & valued','0','','4','',''),
('509','504','13','1','I love what I do','0','','5','',''),
('510','504','13','1','It challenges me to grow','0','','7','',''),
('511','504','13','1','It fits my personality','0','','8','',''),
('512','338','13','1','Emergency Shelter','0','','0','',''),
('513','512','13','1','Custom Milestone ','0','','-1','',''),
('514','512','13','1','Move to shelter through faith congregation','0','','1','',''),
('515','514','13','1','Living on street','0','','0','',''),
('516','514','13','1','Traditional shelter','0','','2','',''),
('517','514','13','1','Faith congregation','0','','4','',''),
('518','514','13','1','Volunteer group shelter','0','','3','',''),
('519','512','13','1','Move to shelter through other volunteer group','0','','4','',''),
('520','519','13','1','Living on street','0','','0','',''),
('521','519','13','1','Traditional shelter','0','','5','',''),
('522','519','13','1','Faith congregation','0','','6','',''),
('523','519','13','1','Volunteer group shelter','0','','7','',''),
('524','512','13','1','Move to traditional shelter','0','','4','',''),
('525','524','13','1','Living on street','0','','1','',''),
('526','524','13','1','Volunteer group shelter','0','','2','',''),
('527','524','13','1','Faith congregation','0','','3','',''),
('528','524','13','1','Traditional shelter','0','','6','',''),
('529','512','13','1','Move to home through rapid rehousing program','0','','10','',''),
('530','529','13','1','Living on street','0','','0','',''),
('531','529','13','1','Traditional shelter','0','','1','',''),
('532','529','13','1','Volunteer group shelter','0','','2','',''),
('533','529','13','1','Rapid Rehousing program','0','','7','',''),
('534','529','13','1','Faith congregation','0','','4','',''),
('535','541','13','1','Move to transitional housing','0','','10','',''),
('536','535','13','1','Living on street','0','','0','',''),
('537','535','13','1','Traditional shelter','0','','1','',''),
('538','535','13','1','Volunteer group shelter','0','','3','',''),
('539','535','13','1','Faith congregation','0','','5','',''),
('540','535','13','1','Transitional housing','0','','7','',''),
('541','338','13','1','Transitional Housing','0','','7','',''),
('542','338','13','1','Stay in current home','0','','15','',''),
('543','542','13','1','Receive rental assistance','0','','0','',''),
('544','541','13','1','Custom Milestone ','0','','-1','',''),
('545','0','17','1','Events Info','0','','0','',''),
('546','542','13','1','Mediate rent with landlord','0','','3','',''),
('547','0','17','1','Program Info','0','','-1','',''),
('548','542','13','1','Receive mortgage assistance','0','','5','',''),
('549','542','13','1','Restructure mortgage','0','','10','',''),
('550','0','17','1','Other Resources','0','','0','',''),
('551','338','13','1','Permanent Housing','0','','20','',''),
('552','551','13','1','Rent a home','0','','1','',''),
('553','551','13','1','Buy a home','0','','3','',''),
('554','551','13','1','Find permanent supportive housing','0','','5','',''),
('555','558','13','1','Make a financial plan for the future','0','','0','',''),
('556','542','13','1','Custom Milestone ','0','','-1','',''),
('557','551','13','1','Custom Milestone ','0','','-1','',''),
('558','340','13','1','Budgeting','0','','0','',''),
('559','558','13','1','Custom Milestone ','0','','-1','',''),
('560','558','13','1','Create and stick to monthly and weekly budgets','0','','3','',''),
('561','558','13','1','Participate in financial child support','0','','4','',''),
('562','340','13','1','Personal Finance','0','','2','',''),
('563','562','13','1','Custom Milestone ','0','','-1','',''),
('564','562','13','1','Plan to reduce debt','0','','1','',''),
('565','562','13','1','Get out of OverDraft','0','','2','',''),
('566','562','13','1','Establish checking account at bank','0','','3','',''),
('567','562','13','1','Establish Emergency Fund','0','','5','',''),
('568','562','13','1','Establish good credit','0','','7','',''),
('569','340','13','1','Income Programs','0','','5','',''),
('570','569','13','1','Custom Milestone','0','','-1','',''),
('571','569','13','1','Establish necessary identification documents','0','','1','',''),
('572','569','13','1','Apply for SNAP','0','','3','',''),
('573','569','13','1','Apply for WIC','0','','5','',''),
('574','569','13','1','Participate in relevant income programs','0','','6','',''),
('576','0','16','1','Schedule annual physical','0','','0','',''),
('577','0','16','1','Have annual physical','0','','0','',''),
('578','0','16','1','Schedule dentist visit','0','','0','',''),
('579','0','16','1','Go to dentist','0','','0','',''),
('580','0','16','1','Enroll in a stop smoking program','0','','0','',''),
('581','0','16','1','Schedule mammogram','0','','0','',''),
('582','0','16','1','Have mammogram','0','','0','',''),
('583','0','16','1','Discuss contraceptive options with OB','0','','0','',''),
('584','0','16','1','Take contraceptive','0','','0','',''),
('585','0','16','1','Choose not to smoke today','0','','0','',''),
('586','0','16','1','Reduce alcohol intake','0','','0','',''),
('587','0','16','1','Attend diabetes support group','0','','0','','');

CREATE TABLE IF NOT EXISTS `app_help_pages` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `created_by` int NOT NULL,
  `type` varchar(16) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  `icon` varchar(64) NOT NULL,
  `start_date` int NOT NULL,
  `end_date` int NOT NULL,
  `description` text NOT NULL,
  `color` varchar(16) NOT NULL,
  `position` varchar(16) NOT NULL,
  `users_groups` text NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_holidays` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_image_map_labels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `map_id` int NOT NULL,
  `choices_id` int NOT NULL,
  `x` int NOT NULL,
  `y` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_map_id` (`map_id`),
  KEY `idx_choices_id` (`choices_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_image_map_markers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `items_id` int NOT NULL,
  `map_id` int NOT NULL,
  `x` int NOT NULL,
  `y` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_map_id` (`map_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_items_export_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `users_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `templates_fields` text NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `cidx` (`entities_id`,`users_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_listing_highlight_rules` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entities_id` int unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `fields_id` int unsigned NOT NULL,
  `fields_values` text NOT NULL,
  `bg_color` varchar(7) NOT NULL,
  `sort_order` int NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `entities_id` (`entities_id`),
  KEY `fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_listing_sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `listing_types_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `fields` text NOT NULL,
  `display_as` varchar(16) NOT NULL,
  `display_field_names` tinyint(1) NOT NULL,
  `text_align` varchar(16) NOT NULL,
  `width` varchar(16) NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_listing_types_id` (`listing_types_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_listing_sections VALUES
('1','22','Goal List','320','inline','0','left','','1'),
('2','35','','489,475,611,482','list','0','left','','1'),
('5','36','','489,475,482','list','0','left','','1'),
('6','35','Non-recurring Goals','479','list','0','left','','3'),
('7','36','Recurring Goals','467','list','0','left','','2'),
('8','36','Non-recurring Goals','479','list','0','left','','3'),
('10','15','','490,316,663','list','0','left','','1'),
('11','19','','318,319,666','list','0','left','','1'),
('12','42','','509,508,522','list','0','left','','1'),
('13','46','Goals','537,538','inline','0','left','','1'),
('14','52','','545,546,547,548,550,551','list','0','left','','1'),
('15','51','','545,546,547,548,550,551','list','1','left','','1'),
('17','16','','316,490','list','0','left','','1'),
('18','20','','318,319,298','list','1','left','','1'),
('19','24','','320','list','0','center','','1'),
('21','23','','320','list','0','center','','1'),
('23','63','','635,631,646','list','0','left','','1'),
('24','67','','656,657','list','0','left','','1'),
('25','63','Category','674','list','0','left','','2'),
('26','63','Non-recurring Goals','632','list','0','left','','3'),
('27','71','','723','list','0','left','','1'),
('28','64','','635,631,646','list','0','left','','1'),
('29','83','','788,785,799,786','list','0','left','','1'),
('30','79','','969,966,980,967','list','0','left','','1'),
('31','84','','788,785,799,786','list','0','left','','1'),
('32','80','','969,966,980,967','list','0','left','','1'),
('33','87','','853,850,864,851','list','0','left','','1'),
('34','91','','940,937,951,938','list','0','left','','1'),
('35','92','','940,937,951,938','list','0','left','','1'),
('36','88','','853,850,864,851','list','0','left','','1'),
('37','95','','911,908,922,909','list','0','left','','1'),
('38','99','','882,879,893,880','list','0','left','','1'),
('39','96','','911,908,922,909','list','0','left','','1'),
('40','100','','882,879,893,880','list','0','left','','1'),
('41','103','','1005','list','0','left','','1'),
('42','103','Category','1029','list','0','left','','4'),
('43','103','Non-recurring Goals','1003','list','0','left','','5'),
('44','108','','1062,1048','list','0','left','','1'),
('46','103','','1002,1008,1033','list','0','left','','3'),
('47','103','','1049,988','inline','0','left','','2'),
('48','104','','1005','list','1','left','','1'),
('49','72','','723','list','0','left','','1'),
('50','72','','725','list','0','left','','2'),
('51','72','','724','list','0','left','','3'),
('52','72','','726','list','0','left','','4'),
('53','71','','725','list','0','left','','2'),
('54','71','','724','list','0','left','','3'),
('55','71','','726','list','0','left','','4'),
('56','104','','1049,988','list','0','left','','2'),
('57','104','','1002,1008,1033','list','0','left','','3'),
('58','104','Category','1029','list','0','left','','4'),
('59','104','Non-recurring Goals','1003','list','0','left','','5'),
('62','23','','1071','list','0','center','','4'),
('63','23','','1070','list','0','center','','5'),
('64','23','','1072','list','0','center','','3'),
('65','23','','338','list','0','center','','2'),
('66','23','','304','list','0','center','','6'),
('71','24','','338','list','0','center','','2'),
('72','24','','1072','list','0','center','','3'),
('73','24','','1070','list','0','center','','4'),
('74','24','','1071','list','0','center','','5'),
('75','24','','304','list','0','center','','6');

CREATE TABLE IF NOT EXISTS `app_listing_types` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `type` varchar(16) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_default` tinyint NOT NULL,
  `width` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=109 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_listing_types VALUES
('1','37','table','1','1','0'),
('2','37','list','0','0','0'),
('3','37','grid','0','0','0'),
('4','37','mobile','0','0','0'),
('5','26','table','1','1','0'),
('6','26','list','0','0','0'),
('7','26','grid','0','0','0'),
('8','26','mobile','0','0','0'),
('9','1','table','1','1','0'),
('10','1','list','0','0','0'),
('11','1','grid','0','0','0'),
('12','1','mobile','0','0','0'),
('13','33','table','1','0','0'),
('14','33','list','0','0','0'),
('15','33','grid','1','1','300'),
('16','33','mobile','1','0','0'),
('17','34','table','1','0','0'),
('18','34','list','0','0','0'),
('19','34','grid','1','1','0'),
('20','34','mobile','1','0','0'),
('21','35','table','1','0','0'),
('22','35','list','0','0','0'),
('23','35','grid','1','1','400'),
('24','35','mobile','1','0','0'),
('25','38','table','1','1','0'),
('26','38','list','0','0','0'),
('27','38','grid','0','0','0'),
('28','38','mobile','0','0','0'),
('29','36','table','1','1','0'),
('30','36','list','0','0','0'),
('31','36','grid','0','0','0'),
('32','36','mobile','0','0','0'),
('33','46','table','1','0','0'),
('34','46','list','0','0','0'),
('35','46','grid','1','1','300'),
('36','46','mobile','1','0','0'),
('37','47','table','1','1','0'),
('38','47','list','0','0','0'),
('39','47','grid','0','0','0'),
('40','47','mobile','0','0','0'),
('41','49','table','1','1','0'),
('42','49','list','0','0','0'),
('43','49','grid','0','0','0'),
('44','49','mobile','0','0','0'),
('45','51','table','1','1','0'),
('46','51','list','0','0','0'),
('47','51','grid','0','0','0'),
('48','51','mobile','0','0','0'),
('49','52','table','1','1','0'),
('50','52','list','0','0','0'),
('51','52','grid','0','0','0'),
('52','52','mobile','1','0','0'),
('53','57','table','1','1','0'),
('54','57','list','0','0','0'),
('55','57','grid','0','0','0'),
('56','57','mobile','0','0','0'),
('57','58','table','1','1','0'),
('58','58','list','0','0','0'),
('59','58','grid','0','0','0'),
('60','58','mobile','0','0','0'),
('61','59','table','1','0','0'),
('62','59','list','0','0','0'),
('63','59','grid','1','1','300'),
('64','59','mobile','1','0','0'),
('65','60','table','1','1','0'),
('66','60','list','0','0','0'),
('67','60','grid','1','0','300'),
('68','60','mobile','0','0','0'),
('69','68','table','1','0','0'),
('70','68','list','0','0','0'),
('71','68','grid','1','1','250'),
('72','68','mobile','1','0','0'),
('73','69','table','1','1','0'),
('74','69','list','0','0','0'),
('75','69','grid','0','0','0'),
('76','69','mobile','0','0','0'),
('77','81','table','1','0','0'),
('78','81','list','0','0','0'),
('79','81','grid','1','1','0'),
('80','81','mobile','1','0','0'),
('81','72','table','1','0','0'),
('82','72','list','0','0','0'),
('83','72','grid','1','1','250'),
('84','72','mobile','1','0','0'),
('85','82','table','1','0','0'),
('86','82','list','0','0','0'),
('87','82','grid','1','1','0'),
('88','82','mobile','1','0','0'),
('89','80','table','1','0','0'),
('90','80','list','0','0','0'),
('91','80','grid','1','1','250'),
('92','80','mobile','1','0','0'),
('93','79','table','1','0','0'),
('94','79','list','0','0','0'),
('95','79','grid','1','1','250'),
('96','79','mobile','0','0','0'),
('97','78','table','1','0','0'),
('98','78','list','0','0','0'),
('99','78','grid','1','1','250'),
('100','78','mobile','1','0','0'),
('101','83','table','1','0','0'),
('102','83','list','0','0','0'),
('103','83','grid','1','1','300'),
('104','83','mobile','1','0','0'),
('105','84','table','1','1','0'),
('106','84','list','0','0','0'),
('107','84','grid','0','0','0'),
('108','84','mobile','1','0','0');

CREATE TABLE IF NOT EXISTS `app_mind_map` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `items_id` int DEFAULT NULL,
  `fields_id` int DEFAULT NULL,
  `reports_id` int DEFAULT NULL,
  `mm_id` varchar(64) NOT NULL,
  `mm_parent_id` varchar(64) NOT NULL,
  `mm_text` varchar(255) NOT NULL,
  `mm_layout` varchar(16) NOT NULL,
  `mm_shape` varchar(16) NOT NULL,
  `mm_side` varchar(16) NOT NULL,
  `mm_color` varchar(16) NOT NULL,
  `mm_icon` varchar(32) NOT NULL,
  `mm_collapsed` varchar(1) NOT NULL,
  `mm_value` varchar(64) NOT NULL,
  `mm_items_id` int DEFAULT '0',
  `parent_entity_item_id` int NOT NULL DEFAULT '0',
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_reports_id` (`reports_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_records_visibility_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `users_groups` text NOT NULL,
  `merged_fields` text NOT NULL,
  `merged_fields_empty_values` text NOT NULL,
  `notes` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_records_visibility_rules VALUES
('1','26','1','6','current_user-253','',''),
('2','28','1','12,5,4','current_user-256','',''),
('3','46','1','13,12,5,4','','',''),
('4','52','1','13,6,12,5,4','current_user-548','',''),
('6','52','1','13,6,12,5,4','current_user-551','',''),
('7','57','1','13,6,12,5,4','current_user-593','',''),
('8','57','1','13,6,12,5,4','current_user-590','',''),
('9','59','1','6,12,5,4','current_user-643','',''),
('10','59','1','6,12,5,4','current_user-675','','');

CREATE TABLE IF NOT EXISTS `app_related_items_1_83` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entity_1_items_id` int unsigned NOT NULL,
  `entity_83_items_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_1_items_id` (`entity_1_items_id`),
  KEY `idx_83_items_id` (`entity_83_items_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `app_related_items_83_84` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `entity_83_items_id` int unsigned NOT NULL,
  `entity_84_items_id` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_83_items_id` (`entity_83_items_id`),
  KEY `idx_84_items_id` (`entity_84_items_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;

INSERT INTO app_related_items_83_84 VALUES
('28','56','28'),
('29','56','31'),
('30','56','29'),
('31','56','32'),
('32','5','33'),
('33','12','34'),
('34','62','35'),
('35','61','36'),
('36','69','41'),
('37','23','42');

CREATE TABLE IF NOT EXISTS `app_reports` (
  `id` int NOT NULL AUTO_INCREMENT,
  `parent_id` int NOT NULL DEFAULT '0',
  `entities_id` int NOT NULL,
  `created_by` int NOT NULL,
  `reports_type` varchar(64) NOT NULL,
  `name` varchar(64) NOT NULL,
  `menu_icon` varchar(64) NOT NULL,
  `in_menu` tinyint(1) NOT NULL DEFAULT '0',
  `in_dashboard` tinyint NOT NULL DEFAULT '0',
  `in_dashboard_counter` tinyint(1) NOT NULL DEFAULT '0',
  `in_dashboard_icon` tinyint(1) NOT NULL,
  `in_dashboard_counter_color` varchar(16) NOT NULL,
  `in_dashboard_counter_fields` varchar(255) NOT NULL,
  `dashboard_counter_hide_count` tinyint(1) NOT NULL DEFAULT '0',
  `dashboard_counter_hide_zero_count` tinyint(1) NOT NULL,
  `dashboard_counter_sum_by_field` int NOT NULL,
  `in_header` tinyint(1) NOT NULL DEFAULT '0',
  `in_header_autoupdate` tinyint(1) NOT NULL,
  `dashboard_sort_order` int DEFAULT NULL,
  `header_sort_order` int NOT NULL DEFAULT '0',
  `dashboard_counter_sort_order` int NOT NULL DEFAULT '0',
  `listing_order_fields` text NOT NULL,
  `users_groups` text NOT NULL,
  `assigned_to` text NOT NULL,
  `displays_assigned_only` tinyint(1) NOT NULL DEFAULT '0',
  `parent_entity_id` int NOT NULL DEFAULT '0',
  `parent_item_id` int NOT NULL DEFAULT '0',
  `fields_in_listing` text NOT NULL,
  `rows_per_page` int NOT NULL DEFAULT '0',
  `notification_days` varchar(32) NOT NULL,
  `notification_time` varchar(255) NOT NULL,
  `listing_type` varchar(16) NOT NULL,
  `listing_col_width` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_created_by` (`created_by`),
  KEY `idx_parent_id` (`parent_id`),
  KEY `idx_parent_entity_id` (`parent_entity_id`),
  KEY `idx_parent_item_id` (`parent_item_id`),
  KEY `idx_reports_type` (`reports_type`),
  KEY `idx_in_dashboard` (`in_dashboard`),
  KEY `idx_in_dashboard_counter` (`in_dashboard_counter`)
) ENGINE=InnoDB AUTO_INCREMENT=816 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_reports VALUES
('66','0','1','0','entityfield212','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('67','0','1','1','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('88','0','35','0','entityfield340','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('278','0','52','1','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('559','0','57','1','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('706','0','57','43','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('708','0','83','39','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','9','','','',''),
('709','0','35','43','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('710','0','83','43','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','10','','','',''),
('712','0','1','43','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('713','0','52','43','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('715','0','83','39','common_filters','All','fa-tasks','0','0','1','1','#039be5','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('716','0','83','39','common_filters','Education','','0','0','0','1','','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('717','0','83','39','common_filters','Health','','0','0','0','1','','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('718','0','83','39','common_filters','Housing','','0','0','0','1','','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('719','0','83','39','common_filters','Jobs','','0','0','0','1','','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('720','0','83','39','common_filters','Money Management','','0','0','0','1','','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('721','0','83','39','common_filters','Other','','0','0','0','1','','','0','0','0','0','0','1','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('722','0','1','45','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('723','0','35','39','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('725','0','83','39','functions','Count Completed Milestones','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('726','0','83','39','functions','Total Milestones','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('727','0','1','39','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('728','0','83','0','related_items_1034','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','1002','0','','','',''),
('729','0','84','0','related_items_1041','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','1062_asc','','','0','0','0','','0','','','',''),
('730','0','83','0','related_items_1044','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','1002','0','','','',''),
('732','0','83','0','process11','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('733','0','84','0','process12','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('734','0','84','39','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('736','0','1','0','related_items_1013','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','12','0','','','',''),
('737','0','1','0','related_items_1051','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','12','0','','','',''),
('739','0','84','43','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('740','0','83','0','related_items_1050','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','1002','0','','','',''),
('741','0','83','42','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('744','0','83','43','default_pivot_tables1','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('746','0','83','43','pivot_table1','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('747','0','84','45','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','1042_desc','','','0','0','0','','0','','','',''),
('749','0','52','45','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('750','0','57','45','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('751','0','1','45','pivotreports15','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('758','0','83','45','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('766','0','83','39','common_filters','In progress','fa-spinner','0','0','1','1','#f09300','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('767','0','83','39','common_filters','Complete','fa-check-circle-o','0','0','1','1','#33b679','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('771','0','1','39','pivotreports15','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('773','0','84','42','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('774','0','83','44','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('775','0','1','44','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('776','0','84','44','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('777','0','83','39','pivot_table4','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('778','0','1','39','pivot_table5','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('779','0','1','39','pivot_table6','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('781','0','83','1','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('782','0','84','1','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('783','0','83','47','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('784','0','83','40','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('785','0','35','40','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('786','0','84','40','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('787','0','1','40','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('788','0','52','40','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('789','0','57','40','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('790','0','1','40','pivotreports15','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('791','0','83','40','calendarreport3','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('792','0','1','47','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('793','0','83','39','common','Upcoming Milestones','fa-spinner','0','1','1','1','#f09300','','0','0','0','0','0','0','0','0','','6,12,5,4','','1','0','0','','0','','','',''),
('794','0','83','39','common','Recurring Goals','fa-bars','0','1','1','1','#039be5','','0','0','0','0','0','0','0','0','','6,12,5,4','','1','0','0','','0','','','',''),
('795','0','83','39','calendarreport3','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('796','0','83','43','calendarreport3','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('797','0','1','43','pivotreports15','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('798','0','83','43','pivot_calendars2','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('799','0','35','45','entity','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('801','0','83','45','calendarreport3','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('807','0','35','0','hide_add_button_rules68','','','0','0','0','0','','','0','0','0','0','0',NULL,'0','0','','','','0','0','0','','0','','','',''),
('808','0','35','43','common_filters','Program Info','','0','0','0','1','','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('809','0','35','43','common_filters','Event Info','','0','0','0','1','','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('810','0','35','43','common_filters','Other Resources','','0','0','0','1','','','0','0','0','0','0','0','0','0','','0,6,12,5,4','','0','0','0','','0','','','',''),
('815','0','35','43','common_filters','All Resources','','0','0','0','1','#23317a','','0','0','0','0','0','-1','0','0','','0,6,12,5,4','','0','0','0','','0','','','','');

CREATE TABLE IF NOT EXISTS `app_reports_filters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reports_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `filters_values` text NOT NULL,
  `filters_condition` varchar(64) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=803 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_reports_filters VALUES
('491','715','1008','','not_empty_value','1'),
('492','716','1029','336','include','1'),
('493','717','1029','337','include','1'),
('494','718','1029','338','include','1'),
('495','719','1029','339','include','1'),
('496','720','1029','340','include','1'),
('497','721','1029','341','include','1'),
('498','725','1008','103','include','1'),
('500','732','1008','104','include','1'),
('501','733','1043','false','include','1'),
('507','741','1029','','not_empty_value','1'),
('520','766','1008','104','include','1'),
('521','767','1008','103','include','1'),
('624','784','1029','337','include','1'),
('627','783','1029','339','include','1'),
('634','708','1008','104','include','1'),
('645','798','1013','current_user_id','include','1'),
('646','798','1008','104','include','1'),
('647','798','1022','current_user_id','include','0'),
('649','808','1068','547','include','1'),
('650','809','1068','545','include','1'),
('663','810','1068','550','include','1'),
('664','774','1008','','not_empty_value','1'),
('676','723','1068','545','include','1'),
('694','815','1068','547,545,550','include','1'),
('788','710','1029','336','include','1'),
('790','709','1068','547','include','1'),
('798','799','1068','550','include','1'),
('802','758','1029','336','include','1');

CREATE TABLE IF NOT EXISTS `app_reports_filters_templates` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fields_id` int NOT NULL,
  `users_id` int NOT NULL,
  `filters_values` text NOT NULL,
  `filters_condition` varchar(64) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cidx` (`fields_id`,`users_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_reports_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `menu_icon` varchar(64) NOT NULL,
  `in_menu` tinyint(1) NOT NULL,
  `sort_order` smallint NOT NULL,
  `counters_list` text NOT NULL,
  `reports_list` text NOT NULL,
  `created_by` int NOT NULL,
  `is_common` tinyint(1) NOT NULL DEFAULT '0',
  `users_groups` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_reports_sections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `created_by` int NOT NULL,
  `count_columns` tinyint(1) NOT NULL DEFAULT '2',
  `reports_groups_id` int NOT NULL,
  `report_left` varchar(64) NOT NULL,
  `report_right` varchar(64) NOT NULL,
  `sort_order` smallint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_groups_id` (`reports_groups_id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_sessions` (
  `sesskey` varchar(32) NOT NULL,
  `expiry` bigint unsigned NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`sesskey`),
  KEY `idx_expiry` (`expiry`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_sessions VALUES
('5goln59ps90gncbr99mu43mmoe','1611150787','uploadify_attachments|a:0:{}uploadify_attachments_queue|a:0:{}alerts|O:6:\"alerts\":1:{s:8:\"messages\";a:2:{i:0;a:2:{s:6:\"params\";s:26:\"class=\"alert alert-danger\"\";s:4:\"text\";s:38:\"No match for Username and/or Password.\";}i:1;a:2:{s:6:\"params\";s:26:\"class=\"alert alert-danger\"\";s:4:\"text\";s:38:\"No match for Username and/or Password.\";}}}app_send_to|N;app_session_token|s:10:\"F(S05cIyIB\";app_current_users_filter|a:0:{}app_previously_logged_user|i:0;two_step_verification_info|a:1:{s:10:\"is_checked\";b:1;}app_email_verification_code|s:0:\"\";app_current_version|s:3:\"2.8\";app_selected_items|a:0:{}listing_page_keeper|a:0:{}user_roles_dropdown_change_holder|a:0:{}app_subentity_form_items|a:0:{}chat_all_unread_msg|s:1:\"0\";plugin_ext_current_version|s:0:\"\";'),
('8m1kgscgme2mtqb7dcc4je1d6f','1611148829','uploadify_attachments|a:0:{}uploadify_attachments_queue|a:0:{}alerts|N;app_send_to|N;app_session_token|s:10:\"a8BgW$%aT_\";app_current_users_filter|a:0:{}app_previously_logged_user|i:0;two_step_verification_info|a:0:{}app_email_verification_code|s:0:\"\";app_current_version|s:0:\"\";app_selected_items|a:0:{}listing_page_keeper|a:0:{}user_roles_dropdown_change_holder|a:0:{}app_subentity_form_items|a:0:{}chat_all_unread_msg|i:0;plugin_ext_current_version|s:0:\"\";'),
('o3vs9ji2vlrb4lmsv2i1hm2r53','1611151276','uploadify_attachments|a:0:{}uploadify_attachments_queue|a:0:{}alerts|O:6:\"alerts\":1:{s:8:\"messages\";a:0:{}}app_send_to|N;app_session_token|s:10:\"B+g0yYpSrP\";app_current_users_filter|a:0:{}app_previously_logged_user|i:0;two_step_verification_info|a:1:{s:10:\"is_checked\";b:1;}app_email_verification_code|s:0:\"\";app_logged_users_id|s:1:\"1\";app_current_version|s:3:\"2.8\";app_selected_items|a:1:{i:729;a:0:{}}listing_page_keeper|a:2:{i:67;s:1:\"1\";i:781;s:1:\"1\";}user_roles_dropdown_change_holder|a:0:{}app_subentity_form_items|a:0:{}chat_all_unread_msg|s:1:\"0\";plugin_ext_current_version|s:0:\"\";');

CREATE TABLE IF NOT EXISTS `app_user_filters_values` (
  `id` int NOT NULL AUTO_INCREMENT,
  `filters_id` int NOT NULL,
  `reports_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `filters_values` text NOT NULL,
  `filters_condition` varchar(64) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_filters_id` (`filters_id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_user_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `entities_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `sort_order` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_user_roles VALUES
('1','37','350','Case Manager','0'),
('2','37','350','Client','0'),
('3','37','350','Family','0');

CREATE TABLE IF NOT EXISTS `app_user_roles_access` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_roles_id` int NOT NULL,
  `fields_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `access_schema` varchar(255) NOT NULL,
  `comments_access` varchar(64) NOT NULL,
  `fields_access` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_fields_id` (`fields_id`),
  KEY `idx_user_roles_id` (`user_roles_id`),
  KEY `entities_id` (`entities_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_user_roles_access VALUES
('1','1','350','38','action_with_assigned,create,update,delete,view','',''),
('2','2','350','38','action_with_assigned,create,update,delete_creator,view,delete','',''),
('3','3','350','38','view','','');

CREATE TABLE IF NOT EXISTS `app_user_roles_to_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `fields_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `items_id` int NOT NULL,
  `users_id` int NOT NULL,
  `roles_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_roles_id` (`roles_id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_fields_id` (`fields_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_users_alerts` (
  `id` int NOT NULL AUTO_INCREMENT,
  `is_active` tinyint(1) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `type` varchar(16) NOT NULL,
  `location` varchar(16) NOT NULL,
  `start_date` bigint unsigned NOT NULL,
  `end_date` bigint unsigned NOT NULL,
  `assigned_to` text NOT NULL,
  `users_groups` text NOT NULL,
  `created_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_created_by` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_users_alerts VALUES
('1','0','Testing User Alerts','Big announcement coming up','info','all','1609131600','1612155600','','0,6','31'),
('2','0','Our site is getting a little tune up and some love.','Many of our customers have pointed out some bugs that need fixing. We apologize for any inconvenience, but we are performing some maintenance. If you have any questions, reach out to us at <a href=\"mailto:info@lambentdata.com\">info@lambentdata.com</a>. For more info about Lambent Data, visit our website at&nbsp;<a href=\"https://www.lambentdata.com/\">https://www.lambentdata.com</a>.','danger','dashboard','1610082000','1610427600','','0,13,6,12,5,4','45'),
('3','1','Updated LD Website','<b><i>We have updated the Interns Page on the <a href=\"http://www.lambentdata.com/interns\">Lambent Data Website.</a>&nbsp; You guys look great.</i></b>','info','dashboard','1610686800','1610773200','','','45');

CREATE TABLE IF NOT EXISTS `app_users_alerts_viewed` (
  `users_id` int NOT NULL,
  `alerts_id` int NOT NULL,
  KEY `idx_ueser_alerts` (`users_id`,`alerts_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_users_alerts_viewed VALUES
('1','1'),
('23','2'),
('29','1'),
('29','2'),
('31','2'),
('32','2'),
('45','3');

CREATE TABLE IF NOT EXISTS `app_users_configuration` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `configuration_name` varchar(255) NOT NULL,
  `configuration_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_users_configuration VALUES
('44','43','sidebar-status',''),
('45','45','app_chat_active_dialog',''),
('46','43','hidden_common_reports',''),
('47','44','app_chat_active_dialog',''),
('48','42','app_chat_active_dialog',''),
('49','45','app_chat_last_msg_id','92'),
('50','45','chat_sending_settings','enter'),
('51','45','chat_sound_notification','time-is-now'),
('52','45','chat_instant_notification','1'),
('53','45','disable_notification',''),
('54','45','disable_internal_notification',''),
('55','45','disable_highlight_unread',''),
('56','43','disable_notification',''),
('57','43','disable_internal_notification',''),
('58','43','disable_highlight_unread',''),
('59','40','app_chat_active_dialog',''),
('60','40','app_chat_last_msg_id','90'),
('61','39','sidebar-status','');

CREATE TABLE IF NOT EXISTS `app_users_filters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `reports_id` int NOT NULL,
  `users_id` int NOT NULL,
  `name` varchar(64) NOT NULL,
  `fields_in_listing` text NOT NULL,
  `listing_order_fields` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_reports_id` (`reports_id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

CREATE TABLE IF NOT EXISTS `app_users_login_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int DEFAULT NULL,
  `username` varchar(255) NOT NULL,
  `identifier` varchar(255) NOT NULL,
  `is_success` tinyint(1) NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`)
) ENGINE=InnoDB AUTO_INCREMENT=488 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_users_login_log VALUES
('368','1','admin','73.175.217.89','1','1610485157'),
('369','0','kevin.mcclarren@lambentdata.com','173.70.131.134','0','1610490585'),
('370','0','CMSally','173.70.131.134','0','1610490614'),
('371','1','admin','73.175.217.89','1','1610553611'),
('372','0','sophieli8723@gmail.com','99.87.200.243','0','1610555312'),
('373','0','sophieli8723@gmail.com','99.87.200.243','0','1610555333'),
('374','0','sophieli8723@gmail.com','99.87.200.243','0','1610555399'),
('379','0','byw2@princeton.edu','107.10.243.36','0','1610566999'),
('381','0','kevin.mcclarren@lambentdata.com','173.70.131.134','0','1610569407'),
('382','0','kevin.mcclarren@lambentdata.com','173.70.131.134','0','1610569433'),
('383','0','kevin.mcclarren@lambentdata.com','173.70.131.134','0','1610569469'),
('384','0','kevin.mcclarren@lambentdata.com','173.70.131.134','0','1610569503'),
('385','0','Kevinmcclarrenpersonal','173.70.131.134','0','1610569533'),
('387','0','kevin.mcclarren@lambentdata.com','173.70.131.134','0','1610569621'),
('393','1','admin','73.175.217.89','1','1610635899'),
('396','0','byw2@princeton.edu','107.10.243.36','0','1610649888'),
('398','0','chitluri@princeton.edu','99.29.80.167','0','1610653259'),
('399','0','chitluri@princeton.edu','99.29.80.167','0','1610653300'),
('400','0','chitluri@princeton.edu','99.29.80.167','0','1610653376'),
('401','0','chitluri@princeton.edu','99.29.80.167','0','1610653416'),
('402','0','chitluri@princeton.edu','99.29.80.167','0','1610653818'),
('403','0','chitluri@princeton.edu','99.29.80.167','0','1610653906'),
('409','0','byw2@princeton.edu','107.10.243.36','0','1610725730'),
('419','0','byw2@princeton.edu','107.77.192.66','0','1610741114'),
('422','0','sydneydubin@gmail.com','96.248.77.192','0','1610747114'),
('423','0','sydneydubin@gmail.com','96.248.77.192','0','1610747127'),
('424','0','sydneydubin@gmail.com','96.248.77.192','0','1610747131'),
('425','0','sydneydubin@gmail.com','96.248.77.192','0','1610747164'),
('426','0','sydneydubin@gmail.com','96.248.77.192','0','1610747176'),
('427','0','sydneydubin@gmail.com','96.248.77.192','0','1610747186'),
('429','0','sydneydubin@gmail.com','96.248.77.192','0','1610747289'),
('448','1','Admin','73.175.217.89','1','1610977405'),
('472','0','byw2@princeton.edu','107.10.243.36','0','1611084520'),
('479','0','sophieli8723@gmail.com','99.87.200.243','0','1611096545'),
('480','0','sophieli8723@gmail.com','99.87.200.243','0','1611096551'),
('481','0','sophieli8723@gmail.com','99.87.200.243','0','1611096560'),
('482','0','sophieli8723@gmail.com','99.87.200.243','0','1611098257'),
('483','1','Admin','99.87.200.243','1','1611099527'),
('485','0','Kmcclarrenpersonal','173.70.131.134','0','1611148746'),
('486','0','Kmcclarrenpersonal','173.70.131.134','0','1611149346'),
('487','0','Kmcclarrenpersonal','173.70.131.134','0','1611149347');

CREATE TABLE IF NOT EXISTS `app_users_notifications` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `entities_id` int NOT NULL,
  `items_id` int NOT NULL,
  `name` text NOT NULL,
  `type` varchar(16) NOT NULL,
  `date_added` bigint unsigned NOT NULL,
  `created_by` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_entities_id` (`entities_id`),
  KEY `idx_items_id` (`items_id`),
  KEY `idx_uei` (`users_id`,`entities_id`) USING BTREE,
  KEY `idx_created_by` (`created_by`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=210 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_users_notifications VALUES
('145','0','83','5','New Item: Graduate','new_item','1610588663','39'),
('147','0','83','5','New Item: Graduate','new_item','1610644762','39'),
('151','0','83','12','New Item: Prepare for the SAT','new_item','1610647241','39'),
('153','0','83','14','New Item: Prepare for the SAT','new_item','1610652385','39'),
('159','39','83','14','New Comment for: Prepare for the SAT','new_comment','1610729878','43'),
('173','47','83','54','New comment on Milestone:  Close to home','new_comment','1610985638','43'),
('174','47','83','54','You recieved a comment on Milestone: Close to home from ','new_comment','1610985639','43'),
('175','47','83','54','New comment on Milestone:  Close to home','new_comment','1610985953','43'),
('176','47','83','54','You recieved a comment on Milestone: Close to home from ','new_comment','1610985954','43'),
('177','47','83','54','New comment on Milestone: Close to home','new_comment','1610986362','43'),
('178','47','83','54','Item updated: Close to home [Status: In progress]','updated_item','1610986877','43'),
('179','47','83','54','Congrats!','updated_item','1610987207','43'),
('180','47','83','54','New comment on Milestone: Close to home','new_comment','1610987208','43'),
('181','47','83','54','New comment on Milestone: Close to home','new_comment','1610987376','43'),
('191','0','84','28','New Item: This is a custom goal','new_item','1611000426','39'),
('192','0','84','29','New Item: Look up new healthy recipe','new_item','1611000446','39'),
('194','0','84','31','New Item: Creating my own custom recuring goal','new_item','1611004873','45'),
('195','0','84','32','New Item: Check blood sugar levels according to doctor','new_item','1611005309','45'),
('197','0','84','33','New Item: Check feet daily','new_item','1611024888','45'),
('198','0','84','34','New Item: Check feet daily','new_item','1611026374','45'),
('199','0','84','35','New Item: my own custom goal','new_item','1611065213','45'),
('200','0','84','36','New Item: Check feet daily','new_item','1611068007','45'),
('202','0','84','38','New Item: Do monthly weigh-in','new_item','1611074494','39'),
('203','0','84','39','New Item: Testing edit','new_item','1611074573','39'),
('204','0','84','40','New Item: Write in my gratitude journal','new_item','1611074597','39'),
('205','0','84','41','New Item: Check feet daily','new_item','1611102229','45'),
('206','0','84','42','New Item: Check blood sugar levels according to doctor','new_item','1611105228','45'),
('207','39','83','5','New comment on Milestone: Graduate High School','new_comment','1611115698','45'),
('208','39','83','5','New comment on Milestone: Graduate High School','new_comment','1611115725','45'),
('209','39','83','5','New comment on Milestone: Graduate High School','new_comment','1611115769','45');

CREATE TABLE IF NOT EXISTS `app_users_search_settings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `users_id` int NOT NULL,
  `reports_id` int NOT NULL,
  `configuration_name` varchar(255) NOT NULL,
  `configuration_value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_users_id` (`users_id`),
  KEY `idx_users_reports_id` (`users_id`,`reports_id`),
  KEY `idx_reports_id` (`reports_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

INSERT INTO app_users_search_settings VALUES
('43','44','776','search_keywords',''),
('44','44','776','use_search_fields',''),
('45','44','776','search_in_comments','0'),
('46','44','776','search_in_all','false'),
('47','44','776','search_type_and','false'),
('48','44','776','search_type_match','false'),
('223','45','758','search_keywords',''),
('224','45','758','use_search_fields',''),
('225','45','758','search_in_comments','true'),
('226','45','758','search_in_all','false'),
('227','45','758','search_type_and','false'),
('228','45','758','search_type_match','false'),
('241','39','708','search_keywords',''),
('242','39','708','use_search_fields',''),
('243','39','708','search_in_comments','false'),
('244','39','708','search_in_all','false'),
('245','39','708','search_type_and','false'),
('246','39','708','search_type_match','false'),
('265','43','709','search_keywords',''),
('266','43','709','use_search_fields',''),
('267','43','709','search_in_comments','0'),
('268','43','709','search_in_all','false'),
('269','43','709','search_type_and','false'),
('270','43','709','search_type_match','false'),
('337','45','799','search_keywords',''),
('338','45','799','use_search_fields',''),
('339','45','799','search_in_comments','0'),
('340','45','799','search_in_all','false'),
('341','45','799','search_type_and','false'),
('342','45','799','search_type_match','false');

